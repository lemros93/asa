package sk.moja.enumerators;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

import static sk.moja.enumerators.Constants.*;

public class CustomProperties {
    private static Properties properties = new Properties();
    private static String destination;
    private static String featureLocation;
    private static String runFrom;
    private static String testType;
    private static Boolean dryRun;
    private static Boolean extractScenariosName;
    private static String reportsFolder;
    private static String timestampFolder;
    private static String buildPlan;
    private static String screenshotType;

    public static void setScreenshotType(String disableScreenshotCreation) {
        CustomProperties.screenshotType = disableScreenshotCreation.toUpperCase();
    }

    public static String getProperty(String key) {
       return properties.getProperty(key);
    }

    public static void setProperty() {
        try {
            FileInputStream in = new FileInputStream(getDestination() + "/temp/property.properties");
            properties.load(in);
            in.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void setDestination() {
        System.out.println("getRunFrom(): " + getRunFrom());
        if (getRunFrom().equals("server")) {
            CustomProperties.destination = SERVER_DESTINATION + DESTINATION;
        } else {
            CustomProperties.destination = LOCAL_DESTINATION + DESTINATION;
        }
    }

    public static void setFeatureLocation(String featureLocation) {
        CustomProperties.featureLocation = featureLocation;
    }

    public static void setRunFrom(String runFrom) {
        CustomProperties.runFrom = runFrom;
    }

    public static void setDryRun(Boolean dryRun) {
        CustomProperties.dryRun = dryRun;
    }

    public static void setExtractScenariosName(Boolean extractScenariosName) {
        CustomProperties.extractScenariosName = extractScenariosName;
    }

    public static void setTestType(String testType) {
        CustomProperties.testType = testType;
    }

    public static void setReportsFolder(String reportsFolder) {
        CustomProperties.reportsFolder = reportsFolder;
    }

    public static void setTimestampFolder(String timestampFolder) {
        CustomProperties.timestampFolder = timestampFolder;
        System.setProperty("timestampFolder", timestampFolder);
    }

    public static void setBuildPlan(String buildPlan) {
        CustomProperties.buildPlan = buildPlan;
    }

    public static String getDestination() {
        return destination;
    }

    public static String getFeatureLocation() {
        return featureLocation;
    }

    public static String getRunFrom() {
        return runFrom;
    }

    public static String getTestType() {
        return testType;
    }

    public static Boolean getDryRun() {
        return dryRun;
    }

    public static Boolean getExtractScenariosName() {
        return extractScenariosName;
    }

    public static String getReportsFolder() {
        return reportsFolder;
    }

    public static String getTimestampFolder() {
        return timestampFolder;
    }

    public static String getBuildPlan() {
        return buildPlan;
    }

    public static String getScreenshotType() {
        return screenshotType;
    }
}