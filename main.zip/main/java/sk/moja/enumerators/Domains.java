package sk.moja.enumerators;

public enum Domains {

    ACC_MOJA_PILOT("https://moja-pilot.acc.csob.sk"),
    ACC_MOJA_LIVE("https://moja-live.acc.csob.sk"),
    ACC_PRIVATE_SSO_BLUE("https://moja-b.acc.csob.sk"),
    ACC_PRIVATE_SSO_GREEN("https://moja-g.acc.csob.sk"),
    AVOKA("https://staging.csob.avoka-transact.com/amendments/secure/servlet/SmartForm.html?formCode=amendment"),

    DEV_PRIVATE_SSO("https://moja-b.dev.intapp.eu"),
    INT_PRIVATE_SSO_BLUE("https://moja-b-int.dev.intapp.eu"),
    INT_PRIVATE_SSO_GREEN("https://moja-g-int.dev.intapp.eu"),
    ACC_PUBLIC("https://spa-a.csob.sk"),
    PROD_PUBLIC("https://csob.sk"),

    ACC_CRM("crm9.sk.acc.intapp.eu");

    public final String value;

    Domains(String value) {
        this.value = value;
    }
}
