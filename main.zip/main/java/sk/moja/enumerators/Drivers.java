package sk.moja.enumerators;

public enum Drivers {
    CHROME("webdriver.chrome.driver"),
    FIREFOX("webdriver.gecko.driver"),
    EDGE("webdriver.edge.driver"),
    OPERA("webdriver.opera.driver"),
    SAFARI("webdriver.safari.driver"),
    IE("webdriver.ie.driver");

    public final String value;

    Drivers(String value) {
        this.value = value;
    }
}
