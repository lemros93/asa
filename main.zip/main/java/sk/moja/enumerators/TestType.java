package sk.moja.enumerators;

public enum TestType {
    REGRESSION("Regression Test"),
    ALL("All"),
    SMOKE("Smoke Test");

    public String value;

    TestType(String value) {
        this.value = value;
    }
}
