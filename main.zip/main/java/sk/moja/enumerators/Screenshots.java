package sk.moja.enumerators;

public enum Screenshots {
    DISABLED("Disabled"),
    FULLSCREEN("FullScreen"),
    ELEMENT("Element");

    public String value;

    Screenshots(String value) {
        this.value = value;
    }
}
