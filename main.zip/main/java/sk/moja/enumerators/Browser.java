package sk.moja.enumerators;

import com.codeborne.selenide.Browsers;

public enum Browser {
    EDGE(Browsers.EDGE),
    CHROME(Browsers.CHROME),
    FIREFOX(Browsers.FIREFOX),
    SAFARI(Browsers.SAFARI),
    EXPLORER(Browsers.IE);

    public String value;

    Browser(String value) {
        this.value = value;
    }
}
