package sk.moja.enumerators;

import lombok.Getter;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CustomDates {
    private static String dateInFuture;
    private static String actualDate;
    private static String actualDatePlain;
    private static String nextDate;
    private static String actualDay;
    private static String nextBankingDay;
    private static String nextBankingDatePlain;
    private static String actualMonth;
    private static String actualYear;
    private static String actualBankingDate;
    private static String nextBankingDate;
    private static String nextBankingDateShort;
    private static String nextNonBankingDate;
    private static String dateInPast;
    private static String dateInPastPlain;
    private static String dateInNextWeek;
    private static String dateInNextWeekPlain;
    private static String dateTooFarInFuture;
    private static String dateTooFarInPast;
    @Getter
    private static String timestamp;
    private static String dateInNextYear;

    static long dayInMilliseconds = 1000L * 60 * 60 * 24;
    static SimpleDateFormat formatterDdMmYyyy = new SimpleDateFormat("dd.MM.yyyy");
    static SimpleDateFormat formatterDMYyyy = new SimpleDateFormat("d.M.yyyy");
    static SimpleDateFormat formatterYyyyMmDd = new SimpleDateFormat("yyyy-MM-dd");
    static SimpleDateFormat formatterYyyy = new SimpleDateFormat("yyyy");
    static SimpleDateFormat formatterMm = new SimpleDateFormat("M");
    static SimpleDateFormat formatterDd = new SimpleDateFormat("d");
    static SimpleDateFormat formatterDdMmYyyyPlain = new SimpleDateFormat("ddMMyyyy");

    static {
        System.out.println("Set Dates");
        setDates();
        setTimestamp();
    }


    private static void setDates() {
        Date actualDate = new Date();
        Date nextDate = new Date(actualDate.getTime() + dayInMilliseconds);
        Date actualBankingDate = createBankingDateFromDate( new Date());
        Date nextBankingDate = createBankingDateFromDate( new Date(new Date().getTime() + dayInMilliseconds));
        Date nextNotBankingDate = nextBankingDate;
        Date nextMonthBankingDate = createBankingDateFromDate( new Date(new Date().getTime() + (dayInMilliseconds * 31)));
        Date nextYearBankingDate = createBankingDateFromDate( new Date(new Date().getTime() + (dayInMilliseconds * 365)));
        Date nextWeekBankingDate = createBankingDateFromDate( new Date(new Date().getTime() + (dayInMilliseconds * 7)));
        Date bankingDateTooFarInFuture = createBankingDateFromDate( new Date(new Date().getTime() + (dayInMilliseconds * 8036)));
        Date dateInPast = createBankingDateFromDate( new Date(new Date().getTime() - (dayInMilliseconds * 7)));
        Date dateTooFarInPast = createBankingDateFromDate( new Date(new Date().getTime() - (dayInMilliseconds * 3654)));

        CustomDates.actualDate = formatterDdMmYyyy.format(actualDate);
        actualDatePlain = formatterDdMmYyyyPlain.format(actualDate);
        CustomDates.nextDate = formatterDdMmYyyy.format(nextDate);
        actualDay = formatterDd.format(actualDate);
        actualYear = formatterYyyy.format(actualDate);
        actualMonth = formatterMm.format(actualDate);
        nextBankingDay = formatterDd.format(nextBankingDate);
        nextBankingDatePlain = formatterDdMmYyyyPlain.format(nextBankingDate);
        CustomDates.nextDate = formatterDdMmYyyy.format(nextDate);
        CustomDates.actualBankingDate = formatterDdMmYyyy.format(actualBankingDate);
        CustomDates.nextBankingDate = formatterDdMmYyyy.format(nextBankingDate);
        nextBankingDateShort = formatterDMYyyy.format(nextBankingDate);
        nextNonBankingDate = formatterDdMmYyyy.format(nextNotBankingDate);
        dateInFuture = formatterDdMmYyyy.format(nextMonthBankingDate);
        dateInNextYear = formatterDdMmYyyy.format(nextYearBankingDate);
        dateInNextWeek = formatterDdMmYyyy.format(nextWeekBankingDate);
        dateInNextWeekPlain = formatterDdMmYyyyPlain.format(nextWeekBankingDate);
        dateTooFarInFuture = formatterDdMmYyyy.format(bankingDateTooFarInFuture);
        CustomDates.dateInPast = formatterDdMmYyyy.format(dateInPast);
        dateInPastPlain = formatterDdMmYyyyPlain.format(dateInPast);
        CustomDates.dateTooFarInPast = formatterDdMmYyyy.format(dateTooFarInPast);
    }

    public static String getDates(String text) {
        String[] split = text.split("\\+");
        String key = split[0];

        switch (key) {
            case "actual_date":
                return actualDate;
            case "actual_date_plain":
                return actualDatePlain;
            case "next_banking_date_short":
                return nextBankingDateShort;
            case "next_date":
                return nextDate;
            case "actual_day":
                return actualDay;
            case "actual_month":
                return actualMonth;
            case "actual_year":
                return actualYear;
            case "date_in_future":
                return dateInFuture;
            case "date_in_next_year":
                return dateInNextYear;
            case "date_in_next_week":
                return dateInNextWeek;
            case "date_in_next_week_plain":
                return dateInNextWeekPlain;
            case "actual_banking_date":
                return actualBankingDate;
            case "next_banking_date":
                return nextBankingDate;
            case "next_banking_day":
                return nextBankingDay;
            case "next_banking_date_plain":
                return nextBankingDatePlain;
            case "next_non_banking_date":
                return nextNonBankingDate;
            case "date_in_past":
                return dateInPast;
            case "date_in_past_plain":
                return dateInPastPlain;
            case "date_too_far_in_future":
                return dateTooFarInFuture;
            case "date_too_far_in_past":
                return dateTooFarInPast;
            case "custom_banking_date":
                if (split.length > 1) {
                    int daysToAdd = Integer.parseInt(split[1]);
                    return formatterDdMmYyyy.format(createBankingDateFromDate(new Date(new Date().getTime() + (dayInMilliseconds * daysToAdd))));
                } else {
                    return null;
                }
            case "custom_non_banking_date":
                if (split.length > 1) {
                    int daysToAdd = Integer.parseInt(split[1]);
                    return formatterDdMmYyyy.format(createNonBankingDateFromDate(CustomProperties.getProperty("not_banking_dates"), new Date(new Date().getTime() + (dayInMilliseconds * daysToAdd))));
                } else {
                    return null;
                }
            default:
                return null;
        }
    }

    private static Date createBankingDateFromDate(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);

        return date;
    }

    private static Date createNonBankingDateFromDate(String nonBankingDates, Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        SimpleDateFormat formatterYyyyMmDd = new SimpleDateFormat("yyyy-MM-dd");

        if (!nonBankingDates.contains(formatterYyyyMmDd.format(date))) {
            int counter = 0;
            while (!nonBankingDates.contains(formatterYyyyMmDd.format(date)) && counter < 1000) {
                date = new Date(date.getTime() + (dayInMilliseconds));
                counter++;
            }
        }

        return date;
    }

    public static void setTimestamp() {
        Date actualBankingDate = new Date();
        SimpleDateFormat timestampFormatter = new SimpleDateFormat("yyyy_MM_dd-HH_mm_ss");
        CustomDates.timestamp = timestampFormatter.format(actualBankingDate);
    }

}