package sk.moja.enumerators;

public enum Links {
    SEPA_PAYMENT("/payment/sepa"),
    BULK_SEPA_PAYMENT("/payment/bulk-sepa"),
    FOREIGN_PAYMENT("/payment/foreign"),
    STANDING_ORDER("/standing-orders"),
    SEPA_PAYMENT_TEMPLATE("/payment-templates/sepa"),
    SEPA_BANK_CONNECTION("/payment-templates/sepa"),
    DIRECT_DEBIT("/direct-debit-authorizations"),
    CREDIT_CARD_PAYMENT("/credit-card-repayment"),
    SAVING_TRANSFER("/savings-transfer/"),
    BULK_SEPA_PAYMENT_TEMPLATE("/payment-templates/bulk-sepa"),
    FOREIGN_PAYMENT_TEMPLATE("/payment-templates/foreign"),
    FOREIGN_BANK_CONNECTION("/payment-templates/foreign"),
    STATEMENTS("/statements/products/"),
    CARDS("/cards"),
    DISPLAY_PIN("/cards"),
    BLOCK_CARD("/cards"),
    UNBLOCK_CARD("/cards"),
    CARD_LIMIT("/cards"),
    INTERNET_CARD_LIMIT("/cards"),
    DEALS("/deals"),
    PIN_CHANGE("https://sso-acc.csob.sk/auth/realms/customers/account/password"),
    PRODUCT_ORDER("/product/order"),
    NOTIFICATIONS("/notifications/product/"),
    USER_DETAIL("/user-detail"),
    CONTRACTS("/contracts"),
    DASHBOARD("/"),
    PRODUCT_DETAIL("/product/"),
    CREDIT_CARD("/sales/credit-card"),
    MORTGAGE_LOAN("/loans/hypotekarny-uver"),
    OVERDRAFT("/sales/overdraft"),
    LOAN("/loans/spotrebny-uver"),
    ACCOUNT("/moja-csob/balik-sluzieb"),
    SAVING_ACCOUNT("/moja-csob/sporiaci-ucet"),
    SERVICE_REQUEST("/client-service-requests"),
    SERVICE_REQUEST_FOREIGNER_ID_UPLOAD_DEEPLINK(SERVICE_REQUEST.value + "/FOREIGNER_ID_UPLOAD"),
    LOGIN("/prihlasenie/krok-1"),
    LOGIN_2_KROK("/prihlasenie/krok-2"),
    CONSUMER_LOAN("/loans/spotrebny-uver"),
    AMENDMENTS("https://staging.csob.avoka-transact.com/amendments/secure/servlet/SmartForm.html?formCode=amendment&channel=MOJACSOB&lang=sk"),
    OFFERPOINT("/offers"),
    OFFER_SMART_ACCOUNT("/account-sales/nakup-uctu"),
    TRANSPARENT_ACCOUNTS("/transparent-accounts/"),
    CRM_LOGIN("/CRMSKBANK9/");

    public final String value;
    Links(String value) {
        this.value = value;
    }
}
