package sk.moja.enumerators;

public enum BrowserSize {
    h1366w768("1366x768"),
    h1920w1080("1920x1080"),
    h1536w864("1536x864"),
    h1600w900("1600x900"),
    h1440w900("1440x900"),
    h1280w720("1280x720");

    public String value;

    BrowserSize(String value) {
        this.value = value;
    }
}
