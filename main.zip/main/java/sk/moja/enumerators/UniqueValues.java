package sk.moja.enumerators;


import java.text.SimpleDateFormat;
import java.util.*;
import sk.moja.utils.Functions;

public class UniqueValues {

    private static final ThreadLocal<Map<String, String>> uniqueIdentifier =
            ThreadLocal.withInitial(HashMap::new);

    private static final ThreadLocal<List<Double>> uniqueAmount =
            ThreadLocal.withInitial(ArrayList::new);

    public String getUniqueIdentifierValue(String key) {
        return uniqueIdentifier.get().get(key);
    }

    public void setUniqueIdentifier(String key) {
        uniqueIdentifier.get().put(key, getTimestamp());
    }

    public void setUniqueAmount(String key) {
        uniqueIdentifier.get().put(key, generateAmount());
    }

    public void setUniqueIdentifierWithText(String key, String value) {
        uniqueIdentifier.get().put(key, value);
    }

    public void setProvidedValue(String key, String value) {
        uniqueIdentifier.get().put(key, value);
    }

    private String generateAmount() {
        Calendar cal = Calendar.getInstance();

        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
        int month = cal.get(Calendar.MONTH) / 3;
        int hour = cal.get(Calendar.HOUR);
        int minute = cal.get(Calendar.MINUTE) / 2;

        int decimalValue = dayOfMonth + hour + minute;

        double amount = Double.parseDouble(month + "." + decimalValue);

        amount = Functions.round(checkUniqueAmount(amount), 2);

        uniqueAmount.get().add(amount);

        return Double.toString(amount).replace(".", ",");
    }

    private double checkUniqueAmount(double amount) {

        for (double item : uniqueAmount.get()) {
            if (Double.compare(amount, item) == 0) {
                amount += 0.01;
                return checkUniqueAmount(amount);
            }
        }

        return amount;
    }

    private String getTimestamp() {
        Date actualBankingDate = new Date();
        SimpleDateFormat timestampFormatter =
                new SimpleDateFormat("yyyyMMddHHmmss");

        return timestampFormatter.format(actualBankingDate);
    }

    public static void clear() {
        uniqueIdentifier.remove();
        uniqueAmount.remove();
    }
}
