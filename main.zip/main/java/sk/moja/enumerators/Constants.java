package sk.moja.enumerators;

public class Constants {

    public static final String SERVER_DESTINATION = "/app/data/e2e-tests/";
    public static final String SERVER_WEB_DESTINATION = "/app/data/www/html/e2e/mojacsob/";
    public static final String SERVER_DESTINATION_TEST_RESULTS = "/app/data/e2e-tests/results/";
    public static final String SERVER_DESTINATION_TEST_RESULTS_URL = "https://o7s-set.acc.intapp.eu/e2e/";
    public static final String LOCAL_DESTINATION = "C:/e2e-tests/";

    public static final String DESTINATION = "results/mojacsob";
    public static final String PASSED = "passed";
    public static final String FAILED = "failed";
    public static final String SKIPPED = "skipped";
}