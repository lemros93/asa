package sk.moja.enumerators;


import com.codeborne.selenide.WebElementCondition;

import static com.codeborne.selenide.Condition.*;

public enum Condition {
    APPEAR(appear),
    CHECKED(checked),
    DISABLED(disabled),
    DISAPPEAR(disappear),
    EMPTY(empty),
    ENABLED(enabled),
    EXIST(exist),
    FOCUSED(focused),
    HIDDEN(hidden),
    IMAGE(image),
    READONLY(readonly),
    SELECTED(selected),
    VISIBLE(visible);

    public final WebElementCondition value;
    Condition(WebElementCondition value) {
        this.value = value;
    }
}