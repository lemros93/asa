package sk.moja.utils;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ZipDirectory {
    public static void main(String[] args) throws IOException {
        copyFile();
        String sourceFile = "temp";
        FileOutputStream fos = new FileOutputStream("E2E_testing_automation.zip");
        ZipOutputStream zipOut = new ZipOutputStream(fos);
        File fileToZip = new File(sourceFile);

        zipFile(fileToZip, fileToZip.getName(), zipOut);
        zipOut.close();
        fos.close();
    }

    private static void zipFile(File fileToZip, String fileName, ZipOutputStream zipOut) throws IOException {
        if (fileToZip.isHidden()) {
            return;
        }
        if (fileToZip.isDirectory()) {
            if (fileName.endsWith("/")) {
                zipOut.putNextEntry(new ZipEntry(fileName));
                zipOut.closeEntry();
            } else {
                zipOut.putNextEntry(new ZipEntry(fileName + "/"));
                zipOut.closeEntry();
            }
            File[] children = fileToZip.listFiles();
            for (File childFile : children) {
                zipFile(childFile, fileName + "/" + childFile.getName(), zipOut);
            }
            return;
        }
        FileInputStream fis = new FileInputStream(fileToZip);
        ZipEntry zipEntry = new ZipEntry(fileName);
        zipOut.putNextEntry(zipEntry);
        byte[] bytes = new byte[1024];
        int length;
        while ((length = fis.read(bytes)) >= 0) {
            zipOut.write(bytes, 0, length);
        }
        fis.close();

    }

    private static void copyFile() throws IOException {
        List<String> listOfFile = new ArrayList<>();
        listOfFile.add("target/gui.jar");
        listOfFile.add("target/console.jar");
        listOfFile.add("src/test/resources/drivers/win/glow");
        listOfFile.add("src/test/resources/features");
        listOfFile.add("src/test/resources/properties");

        File f = new File("temp");
        if (f.exists()) {
            FileUtils.deleteDirectory(f);
        }
        f.mkdir();
        for (String fileName : listOfFile) {
            File srcFile = new File(fileName);  // path + filename
            File destDir = new File("temp"); // path only
            if (srcFile.isDirectory()) {
                if (srcFile.toString().endsWith("src\\test\\resources\\features") || srcFile.toString().endsWith("src/test/resources/features") )
                    FileUtils.copyDirectory(srcFile, new File("temp/features"));
                else if ( srcFile.toString().endsWith("src\\test\\resources\\properties") || srcFile.toString().endsWith("src/test/resources/properties"))
                    FileUtils.copyDirectory(srcFile, new File("temp/properties"));
                else if ( srcFile.toString().endsWith("src\\test\\resources\\drivers\\win\\glow") || srcFile.toString().endsWith("src/test/resources/drivers/win/glow"))
                    FileUtils.copyDirectory(srcFile, new File("temp/drivers"));
                else
                    FileUtils.copyDirectory(srcFile, destDir);
            } else if (srcFile.isFile()) {
                FileUtils.copyFileToDirectory(srcFile, destDir);
            }
        }
    }
}