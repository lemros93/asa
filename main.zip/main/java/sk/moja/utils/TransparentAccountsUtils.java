package sk.moja.utils;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import lombok.Getter;
import org.openqa.selenium.By;
import sk.moja.pages.Pages;

import java.text.NumberFormat;
import java.text.ParseException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static org.testng.Assert.assertTrue;

public class TransparentAccountsUtils {

    private final DateTimeFormatter ddMMyyyyFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private final DateTimeFormatter ddMMyyyyFormatterWithoutDots = DateTimeFormatter.ofPattern("ddMMyyyy");
    private final NumberFormat numberFormat = NumberFormat.getInstance(new Locale("sk", "SK"));

    private final Functions functions = new Functions();
    private final ElementsFunctions elementsFunctions = new ElementsFunctions();
    private final Pages transparentAccountsPage = new Pages("Transparent accounts");
    private final Pages productDetailPage = new Pages("Product detail");
    private CollectedTransactionsData collectedTransactionsData;
    private TransactionsDataStoredForLaterCheckInMoja transactionsDataStoredForLaterCheckInMoja;
    private TransactionsDataCollectedInMojaAccountDetail transactionsDataCollectedInMojaAccountDetail;

    public void checkThatDisplayedTransactionsAreFromTheLastThreeMonthsAndTheyArePositiveOrNegative(String positiveOrNegative) {
        checkDisplayedTransactions(positiveOrNegative);
    }

    private void checkDisplayedTransactions(String positiveOrNegative) {

        collectCurrentlyDisplayedTransactionData();

        assertTransactionAmounts(collectedTransactionsData.getCollectedAmounts(), positiveOrNegative);

        LocalDate today = LocalDate.now();
        LocalDate threeMonthsAgo = today.minusMonths(3);

        assertTransactionDates(collectedTransactionsData.getCollectedDates(), threeMonthsAgo, today);
    }

    public void setTransactionsDataStoredForLaterCheckInMoja() {
        transactionsDataStoredForLaterCheckInMoja =
            new TransactionsDataStoredForLaterCheckInMoja(
                collectedTransactionsData.getCollectedDates(),
                collectedTransactionsData.getCollectedAmounts()
            );
        transactionsDataStoredForLaterCheckInMoja.writeTransactionsDataToBeCheckInMojaToLog();
    }

    public void setDatesForLastThreeYearsInTransparentAccountsFilter() {
        LocalDate today = LocalDate.now();
        LocalDate threeYearsAgo = today.minusYears(3);

        setTransparentAccountsFilterDates(threeYearsAgo, today);
    }

    public void checkThatDisplayedTransactionsAreFromTheLastThreeYearsAndTheyArePositiveOrNegative(String positiveOrNegative) {

        collectCurrentlyDisplayedTransactionData();

        assertTransactionAmounts(collectedTransactionsData.getCollectedAmounts(), positiveOrNegative);

        LocalDate today = LocalDate.now();
        LocalDate threeYearsAgo = today.minusYears(3);

        assertTransactionDates(collectedTransactionsData.getCollectedDates(), threeYearsAgo, today);
    }

    public void setDatesPeriodLongerThanThreeYearsAgoInTransparentAccountsFilter() {
        LocalDate today = LocalDate.now();
        LocalDate moreThanThreeYearsAgo = today.minusYears(3).minusDays(1);

        setTransparentAccountsFilterDates(moreThanThreeYearsAgo, today);
    }

    public void setHigherDateFromThanDateToInTransparentAccountsFilter() {
        LocalDate today = LocalDate.now();
        LocalDate dateTo = today.minusMonths(1);
        LocalDate dateFromHigherThanDateTo = dateTo.plusDays(1);

        setTransparentAccountsFilterDates(dateFromHigherThanDateTo, dateTo);
    }

    public void setWeekendDatesInTransparentAccountsFilterAndCheckTransactions(String positiveOrNegative) {
        LocalDate today = LocalDate.now();
        LocalDate lastSaturday = today.with(TemporalAdjusters.previous(DayOfWeek.SATURDAY));
        LocalDate saturdayTwentyWeeksBeforeLastSaturday = lastSaturday.minusWeeks(20);

        setTransparentAccountsFilterDates(saturdayTwentyWeeksBeforeLastSaturday, lastSaturday);
        filterSelection();
        collectCurrentlyDisplayedTransactionData();

        assertTransactionAmounts(collectedTransactionsData.getCollectedAmounts(), positiveOrNegative);
        assertTransactionDates(collectedTransactionsData.getCollectedDates(), saturdayTwentyWeeksBeforeLastSaturday, lastSaturday);
    }

    public void setPublicHolidayDatesInTransparentAccountsFilterAndCheckTransactions(String positiveOrNegative) {
        LocalDate today = LocalDate.now();
        LocalDate firstJanuaryThisYear = LocalDate.of(today.getYear(), 1, 1);
        LocalDate firstJanuaryLastYear = LocalDate.of(today.getYear() - 1, 1, 1);

        setTransparentAccountsFilterDates(firstJanuaryLastYear, firstJanuaryThisYear);
        filterSelection();
        collectCurrentlyDisplayedTransactionData();

        assertTransactionAmounts(collectedTransactionsData.getCollectedAmounts(), positiveOrNegative);
        assertTransactionDates(collectedTransactionsData.getCollectedDates(), firstJanuaryLastYear, firstJanuaryThisYear);
    }

    private void setTransparentAccountsFilterDates(LocalDate dateFrom, LocalDate dateTo) {
        List<By> dateFromByObjects = transparentAccountsPage.getParameterList("TA detail - transactions - date from");
        List<By> dateToByObjects = transparentAccountsPage.getParameterList("TA detail - transactions - date to");

        String todayWithoutDotsString = dateFrom.format(ddMMyyyyFormatterWithoutDots);
        String moreThanThreeYearsAgoWithoutDotsString = dateTo.format(ddMMyyyyFormatterWithoutDots);

        elementsFunctions.typeIntoInput(dateFromByObjects.get(0), 1, todayWithoutDotsString, true);
        elementsFunctions.typeIntoInput(dateToByObjects.get(0), 1, moreThanThreeYearsAgoWithoutDotsString, true);
    }

    private void filterSelection() {
        List<By> filterByObjects = transparentAccountsPage.getParameterList("TA detail - transactions - filter");
        elementsFunctions.clickOnButton(filterByObjects.get(0),1);
    }

    private void assertTransactionDates(List<String> collectedTransactionDates, LocalDate expectedDateFrom, LocalDate expectedDateTo) {
        assertTrue(
            checkThatAllTheDisplayedTransactionsAreWithinTheExpectedDates(collectedTransactionDates, expectedDateFrom, expectedDateTo),
            "Displayed dates are out of the expected date ranges from: "
            + expectedDateFrom + " to " + expectedDateTo + "\n"
            + "Currently displayed dates are:\n"
            + collectedTransactionDates
        );
    }

    private boolean checkThatAllTheDisplayedTransactionsAreWithinTheExpectedDates(List<String> collectedTransactionDates, LocalDate expectedDateFrom, LocalDate expectedDateTo) {

        try {
            for (String dateString : collectedTransactionDates) {
                LocalDate transactionDate = LocalDate.parse(dateString, ddMMyyyyFormatter);

                if (transactionDate.isBefore(expectedDateFrom) || transactionDate.isAfter(expectedDateTo)) {
                    return false;
                }
            }
        } catch (DateTimeParseException e) {
            return false;
        }

        return true;
    }

    private void assertTransactionAmounts(List<String> collectedTransactionsAmounts, String positiveOrNegative) {
        if (positiveOrNegative.equals("positive")) {
            assertTrue(
                checkIfDisplayedTransactionsArePositiveOrNegative(collectedTransactionsAmounts, true),
                "One or more displayed payments are zero, negative, or invalid"
            );
        } else if (positiveOrNegative.equals("negative")) {
            assertTrue(
                checkIfDisplayedTransactionsArePositiveOrNegative(collectedTransactionsAmounts, false),
                "One or more displayed payments are zero, positive, or invalid"
            );
        } else if (positiveOrNegative.equals("both positive and negative")) {
            assertTrue(
                checkIfTransactionsAreDisplayed(collectedTransactionsAmounts),
                "Transactions are not displayed or some of them is zero or invalid"
            );
        }
        else {
            throw new IllegalArgumentException("positiveOrNegative parameter must be 'positive' or 'negative' or 'both positive and negative'");
        }
    }

    private boolean checkIfDisplayedTransactionsArePositiveOrNegative(List<String> collectedTransactionAmounts, boolean mustBePositive) {

        for (String transactionAmount : collectedTransactionAmounts) {
            try {
                String transactionAmountStringWithoutEmptySpaces = transactionAmount
                    .replace("\u00A0", "")
                    .replace(" ", "");

                double value = numberFormat.parse(transactionAmountStringWithoutEmptySpaces ).doubleValue();

                if (mustBePositive && value <= 0) {
                    return false;
                }
                if (!mustBePositive && value >= 0) {
                    return false;
                }

            } catch (ParseException e) {
                System.out.println("Invalid number value: " + transactionAmount);
                return false;
            }
        }
        return true;
    }

    private boolean checkIfTransactionsAreDisplayed(List<String> collectedTransactionAmounts) {

        if(collectedTransactionAmounts.isEmpty()) {
            return false;
        }

        for (String transactionAmount : collectedTransactionAmounts) {
            try {
                String transactionAmountStringWithoutEmptySpaces = transactionAmount
                    .replace("\u00A0", "")
                    .replace(" ", "");

                double value = numberFormat.parse(transactionAmountStringWithoutEmptySpaces ).doubleValue();

                if (value == 0) {
                    return false;
                }
            } catch (ParseException e) {
                System.out.println("Invalid number value: " + transactionAmount);
                return false;
            }
        }
        return true;
    }

    private void collectCurrentlyDisplayedTransactionData() {
        collectedTransactionsData = new CollectedTransactionsData();

        List<By> displayedTransactionDatesByObjects = transparentAccountsPage.getParameterList("TA detail - transactions - collection of displayed dates");
        List<By> displayedTransactionAmountsByObjects = transparentAccountsPage.getParameterList("TA detail - transactions - collection of displayed amounts");
        List<By> nexButtonEnabledByObjects = transparentAccountsPage.getParameterList("TA detail - paging - button next enabled");

        do {
            functions.waitUntilPageIsLoaded();

            ElementsCollection displayedTransactionDatesElements = functions.getElementsCollectionNew(displayedTransactionDatesByObjects);
            ElementsCollection displayedTransactionAmountsElements = functions.getElementsCollectionNew(displayedTransactionAmountsByObjects);

            displayedTransactionDatesElements.texts().forEach(collectedTransactionsData::addToCollectedDates);
            displayedTransactionAmountsElements.texts().forEach(collectedTransactionsData::addToCollectedAmounts);

            String firstDateBefore = displayedTransactionDatesElements.first().getText();

            ElementsCollection nextButtonEnabledElements =
                functions.getElementsCollectionNew(nexButtonEnabledByObjects);

            if (nextButtonEnabledElements.isEmpty()) {
                break;
            }

            nextButtonEnabledElements
                .first()
                .shouldBe(Condition.enabled)
                .click();

            displayedTransactionDatesElements.first().shouldNotHave(Condition.text(firstDateBefore));
        } while (true);

        collectedTransactionsData.writeCollectedTransactionsDataToLog();
    }

    public void collectDisplayedTransactionsOnMojaAccountDetailAndCheckThemWithStoredTransactions() {
        transactionsDataCollectedInMojaAccountDetail = new TransactionsDataCollectedInMojaAccountDetail();

        List<By> displayedTransactionDatesByObjects = productDetailPage.getParameterList("Processed transactions dates list");
        List<By> displayedTransactionAmountsByObjects = productDetailPage.getParameterList("Processed transactions amounts list");
        ElementsCollection displayedTransactionDatesElements = functions.getElementsCollectionNew(displayedTransactionDatesByObjects);
        ElementsCollection displayedTransactionAmountsElements = functions.getElementsCollectionNew(displayedTransactionAmountsByObjects);

        displayedTransactionDatesElements.texts().forEach(transactionsDataCollectedInMojaAccountDetail::addToCollectedDates);
        displayedTransactionAmountsElements.texts().forEach(transactionsDataCollectedInMojaAccountDetail::addToCollectedAmounts);

        transactionsDataCollectedInMojaAccountDetail.writeDataCollectedOnTransactInMojaAccountDetailPageToLog();
        transactionsDataStoredForLaterCheckInMoja.writeTransactionsDataToBeCheckInMojaToLog();

        List<String> transactionsDatesCollectedInMojaWithoutAdditionalInfoTexts = transactionsDataCollectedInMojaAccountDetail.getTransactionsDatesCollectedInMojaAccountDetail()
            .stream()
            .map(s -> s.replaceAll(".*\\((\\d{2}\\.\\d{2}\\.\\d{4})\\)", "$1"))
            .toList();

        List<String> transactionsDatesStoredBeforeWithoutDuplications = transactionsDataStoredForLaterCheckInMoja.getTransactionsForMojaCheckDates().stream().distinct().toList();

        for (int i = 0; i < transactionsDatesCollectedInMojaWithoutAdditionalInfoTexts.size(); i++) {
            if(!(transactionsDatesCollectedInMojaWithoutAdditionalInfoTexts.get(i)).equals(transactionsDatesStoredBeforeWithoutDuplications.get(i))) {
                throw new AssertionError(
                    "Dates displayed in Moja product detail are not the same as dates displayed in transparent account detail\n" +
                    "Transparent account detail dates:\n" +
                    transactionsDatesStoredBeforeWithoutDuplications +
                    "\nMoja account detail dates:\n" +
                    transactionsDatesCollectedInMojaWithoutAdditionalInfoTexts
                );
            }
        }

        for (int i = 0; i < transactionsDataCollectedInMojaAccountDetail.getTransactionsAmountsCollectedInMojaAccountDetail().size(); i++) {
            if(!(transactionsDataCollectedInMojaAccountDetail.getTransactionsAmountsCollectedInMojaAccountDetail().get(i).replace("EUR", "").trim())
                .equals(transactionsDataStoredForLaterCheckInMoja.getTransactionsForMojaCheckAmounts().get(i))) {
                throw new AssertionError(
                    "Amounts displayed in Moja product detail are not the same as amounts displayed in transparent account detail\n" +
                    "Transparent account detail amounts:\n" +
                    transactionsDataStoredForLaterCheckInMoja.getTransactionsForMojaCheckAmounts() +
                    "\nMoja account detail amounts:\n" +
                    transactionsDataCollectedInMojaAccountDetail.getTransactionsAmountsCollectedInMojaAccountDetail()
                );
            }
        }
    }

    static class CollectedTransactionsData {
        @Getter
        private final List<String> collectedDates;
        @Getter
        private final List<String> collectedAmounts;

        public CollectedTransactionsData() {
            this.collectedDates = new ArrayList<>();
            this.collectedAmounts = new ArrayList<>();
        }

        public void addToCollectedDates(String value) {
            collectedDates.add(value);
        }

        public void addToCollectedAmounts(String value) {
            collectedAmounts.add(value);
        }

        public void writeCollectedTransactionsDataToLog() {
            System.out.println("Collected dates are:");
            System.out.println(getCollectedDates());
            System.out.println("Collected amounts are:");
            System.out.println(getCollectedAmounts());
        }
    }

    static class TransactionsDataStoredForLaterCheckInMoja {
        @Getter
        private final List<String> transactionsForMojaCheckDates;
        @Getter
        private final List<String> transactionsForMojaCheckAmounts;

        public TransactionsDataStoredForLaterCheckInMoja(List<String> dates, List<String> amounts) {
            this.transactionsForMojaCheckDates = new ArrayList<>(dates);
            this.transactionsForMojaCheckAmounts = new ArrayList<>(amounts);
        }

        public void writeTransactionsDataToBeCheckInMojaToLog() {
            System.out.println("Transaction dates to be checked in Moja are:");
            System.out.println(getTransactionsForMojaCheckDates());
            System.out.println("Transaction amounts to be checked in Moja are:");
            System.out.println(getTransactionsForMojaCheckAmounts());
        }
    }

    static class TransactionsDataCollectedInMojaAccountDetail {
        @Getter
        private final List<String> transactionsDatesCollectedInMojaAccountDetail;
        @Getter
        private final List<String> transactionsAmountsCollectedInMojaAccountDetail;

        public TransactionsDataCollectedInMojaAccountDetail() {
            this.transactionsDatesCollectedInMojaAccountDetail = new ArrayList<>();
            this.transactionsAmountsCollectedInMojaAccountDetail = new ArrayList<>();
        }

        public void addToCollectedDates(String value) {
            transactionsDatesCollectedInMojaAccountDetail.add(value);
        }

        public void addToCollectedAmounts(String value) {
            transactionsAmountsCollectedInMojaAccountDetail.add(value);
        }

        public void writeDataCollectedOnTransactInMojaAccountDetailPageToLog() {
            System.out.println("Transaction dates collected in Moja account detail page are:");
            System.out.println(getTransactionsDatesCollectedInMojaAccountDetail());
            System.out.println("Transaction dates collected in Moja account detail page are:");
            System.out.println(getTransactionsAmountsCollectedInMojaAccountDetail());
        }
    }
}