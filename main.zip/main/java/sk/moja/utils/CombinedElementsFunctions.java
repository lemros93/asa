package sk.moja.utils;

import com.codeborne.selenide.*;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.codeborne.selenide.CollectionCondition.*;
import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.ScrollIntoViewOptions.Block.center;
import static com.codeborne.selenide.ScrollIntoViewOptions.instant;
import static com.codeborne.selenide.Selectors.*;
import static java.lang.Double.parseDouble;
import static org.junit.Assert.*;

public class CombinedElementsFunctions extends Functions {

    public void selectFromDropdownByText(List<By> elementParametersList, List<String> valuesToBeSelected) {
        waitUntilPageIsLoaded();
        SelenideElement mainSelenideElement = getElement(elementParametersList.get(0));
        mainSelenideElement.scrollIntoView(instant().block(center)).click();
        ElementsCollection liElement;
        ElementsCollection ulElements = getElementsCollection(elementParametersList.get(1));
        SelenideElement ulElement = getElementFromCollection(ulElements);
        liElement = ulElement.findAll(elementParametersList.get(2));

        boolean foundElement = false;
        for (SelenideElement element : liElement) {
            if (stringContainsAllListWords(element.text(), valuesToBeSelected)) {
                element.click();
                foundElement = true;
                break;
            }
        }

        if (!foundElement) {
            fail("Error! Element not found!");
        }
    }

    public void selectFromDropdownInOrderByText(List<By> elementParametersList, int order, List<String> valuesToBeSelected) {
        waitUntilPageIsLoaded();
        ElementsCollection elementsCollection = getElementsCollection(elementParametersList.get(0));
        SelenideElement selenideElement = elementsCollection.get(order - 1);
        selenideElement.scrollIntoView(instant().block(center)).click();
        ElementsCollection liElement;
        ElementsCollection ulElements = getElementsCollection(elementParametersList.get(1));
        SelenideElement ulElement = getElementFromCollection(ulElements);
        liElement = ulElement.findAll(elementParametersList.get(2));

        boolean foundElement = false;
        for (SelenideElement element : liElement) {
            if (stringContainsAllListWords(element.text(), valuesToBeSelected)) {
                element.click();
                foundElement = true;
                break;
            }
        }

        if (!foundElement) {
            fail("Error! Element not found!");
        }
    }

    public void selectFromMultipleSelectionDropdownByText(List<By> elementParametersList, List<String> valuesToBeSelected) {
        selectFromDropdownByText(elementParametersList, valuesToBeSelected);
        pressEscape();
    }

    public void notSelectFromDropdownByText(List<By> elementParametersList, List<String> values) {
        waitUntilPageIsLoaded();
        SelenideElement mainSelenideElement = getElement(elementParametersList.get(0));
        mainSelenideElement.scrollIntoView(instant().block(center)).click();
        ElementsCollection liElement;
        ElementsCollection ulElements = getElementsCollection(elementParametersList.get(1));
        SelenideElement ulElement = getElementFromCollection(ulElements);
        liElement = ulElement.findAll(elementParametersList.get(2));

        boolean foundElement = false;
        for (SelenideElement element : liElement) {
            if (stringContainsAllListWords(element.text(), values)) {
                element.click();
                foundElement = true;
                break;
            }
        }
        if (!foundElement) {
            pressTab();
        }
        if (foundElement) {
            fail("Error! Element was found! Expectation is: it should not be found!");
        }
    }

    public void verifyTextInElement(List<By> elementParametersList, List<String> values, int order) {
        waitUntilPageIsLoaded();
        SelenideElement selenideElement;
        ElementsCollection elementsCollection = getElementsCollectionNew(elementParametersList);

        if (elementParametersList.size() == 1 || (!elementsCollection.get(order - 1).toString().toLowerCase().contains("dropdown") && !elementsCollection.get(order - 1).toString().toLowerCase().contains("select"))) {
            selenideElement = elementsCollection.get(order - 1);
            selenideElement.shouldBe(visible);
            selenideElement.scrollIntoView(instant().block(center));

            if (!Objects.requireNonNull(selenideElement.getText()).replace(" ", "").isEmpty()) {
                for (String item : values) {
                    selenideElement.shouldHave(text(item));
                }
            } else if (!Objects.requireNonNull(selenideElement.getValue()).replace(" ", "").isEmpty()) {
                for (String item : values) {
                    selenideElement.shouldHave(value(item));
                }
            } else if (values.size() == 1 && values.get(0).equals("") && selenideElement.getText().replace(" ", "").isEmpty() && Objects.requireNonNull(selenideElement.getValue()).isEmpty()) {
                return;
            }
        } else if (elementParametersList.size() > 1 && elementParametersList.get(1).equals(byXpath("//csob-dropdown")) || elementsCollection.get(order - 1).toString().toLowerCase().contains("select")) {
            selenideElement = findDropdown(elementParametersList, order);
            SelenideElement selenideElementParent = selenideElement.parent().parent();
            if (!selenideElementParent.getText().replace(" ", "").isEmpty()) {
                for (String item : values) {
                    selenideElementParent.shouldHave(text(item));
                }
            }
        } else {
            throwError("The searched text was not found in the element!");
        }
    }

    public void verifyTextInDropdown(List<By> elementParametersList, String expectedText, int order) {
        waitUntilPageIsLoaded();
        ElementsCollection elementsCollection = getElementsCollection(elementParametersList.get(0));
        SelenideElement dropdown = elementsCollection.get(order-1);
        String dropdownText = null;

        dropdown.shouldBe(visible);
        try {
            dropdownText = dropdown.getText();
            if(dropdownText.isEmpty() && dropdown.getTagName().equalsIgnoreCase("input")) {
                dropdownText = getDropdownInputValue(dropdown);
            }
        } catch (StaleElementReferenceException e) {
            // just ignore, because we will try input sub-element later
        }

        if (elementValueMatchesExpectedValue(dropdownText, expectedText)) {
            return;
        }

        SelenideElement inputElement = dropdown.find(byXpath(".//input"));
        if(inputElement.exists()) {
            String inputValue = getDropdownInputValue(inputElement);
            if (elementValueMatchesExpectedValue(inputValue, expectedText)) {
                return;
            }
         }

        throw new AssertionError(
                "Expected text: '" + expectedText +
                "' was not found or matched in the dropdown: " + dropdown +
                " Dropdown currently contains following text: '" + dropdownText +  "'");
    }

    private String getDropdownInputValue(SelenideElement dropdown) {
        String value = dropdown.getValue();
        if (value != null && !value.isEmpty()) {
            return value;
        }

        value = dropdown.getDomProperty("value");
        if (value != null && !value.isEmpty()) {
            return value;
        }

        value = dropdown.getAttribute("placeholder");
        if (value != null && !value.isEmpty()) {
            return value;
        }

        value = Selenide.executeJavaScript("return arguments[0].value;", dropdown);
        return value != null ? value : "";
    }

    private boolean elementValueMatchesExpectedValue(String elementValue, String expectedValue) {

        elementValue = elementValue.trim().replaceAll("\\s+", " ");
        expectedValue = expectedValue.trim().replaceAll("\\s+", " ");

        if (expectedValue.isEmpty()) {
            return (elementValue.isEmpty());
        } else {
            return (elementValue.contains(expectedValue));
        }
    }

    public void verifyRemovedTextInElement(List<By> elementParametersList, List<String> values, int order) {
        waitUntilPageIsLoaded();

        SelenideElement selenideElement;
        ElementsCollection elementsCollection = getElementsCollectionNew(elementParametersList);

        if (!elementsCollection.get(order - 1).toString().toLowerCase().contains("dropdown")) {
            selenideElement = elementsCollection.get(order - 1);
            selenideElement.shouldBe(visible);
        } else {
            selenideElement = findDropdown(elementParametersList, order);
        }

        boolean foundElement = false;
        if (!selenideElement.getText().replace(" ", "").isEmpty()) {
            for (String item : values) {
                if (!selenideElement.has(text(item))) {
                    foundElement = true;
                    break;
                }
            }
        } else if (!Objects.requireNonNull(selenideElement.getValue()).isEmpty()) {
            for (String item : values) {
                if (!selenideElement.has(value(item))) {
                    foundElement = true;
                    break;
                }
            }
        } else {
            SelenideElement selenideElementParent = selenideElement.parent().parent();
            if (!selenideElementParent.getText().replace(" ", "").isEmpty()) {
                for (String item : values) {
                    if (!selenideElementParent.has(text(item))) {
                        foundElement = true;
                        break;
                    }
                }
            }
        }

        if (!foundElement) {
            throwError("The searched text was found in the element! Expectation is: it should not be found!");
        }
    }

    public void verifyTextIsNotDisplayedInTheListOfElements(String text, List<By> elementParametersList) {
        ElementsCollection items = getElementsCollection(elementParametersList.get(0));

        List<String> rowsContainingText = items.stream()
                .filter(row -> containsTextRecursively(row, text))
                .map(SelenideElement::getText)
                .collect(Collectors.toList());

        if (!rowsContainingText.isEmpty()) {
            String message = String.format(
                    "Text '%s' was unexpectedly found in %d element(s):%n%s",
                    text,
                    rowsContainingText.size(),
                    String.join("\n---\n", rowsContainingText)
            );
            throw new AssertionError(message);
        }
    }

    private static boolean containsTextRecursively(SelenideElement element, String text) {
        String checkedText = text.toLowerCase();

        try {
            String elementText = element.getText();
            if (elementText != null && elementText.toLowerCase().contains(checkedText)) {
                return true;
            }

            ElementsCollection children = element.$$("*");
            for (SelenideElement child : children) {
                String childText = child.getText();
                if (childText != null && childText.toLowerCase().contains(checkedText)) {
                    return true;
                }
            }
        } catch (Exception ignored) {
            // Ignore stale or detached elements
        }

        return false;
    }


    public void verifyTextInElementsCollectionWithLessInformation(List<By> elementsParametersList, String type, List<String> values) {
        waitInSeconds(5);
        ElementsCollection listOfPayment = getElementsCollectionNew(elementsParametersList);
        if (type.replace(" ", "").equals("empty")) {
            SelenideElement element = getElement(elementsParametersList.get(1)).find(elementsParametersList.get(2));
            if (!stringContainsAllListWords(element.text(), values)) {
                throwError("The searched text was not found in the list!");
            }
        } else {

            listOfPayment.shouldHave(sizeGreaterThan(0));
            listOfPayment.get(0).shouldBe(visible);
            boolean foundElement = false;

            listOfPayment.get(0).scrollIntoView(instant().block(center));
            for (SelenideElement element : listOfPayment) {
                if (element.parent().has(cssClass("openable-item")) && element.parent().has(cssClass("open"))) {
                    element.parent().scrollIntoView(instant().block(center)).click();
                } else if (element.has(cssClass("openable-item")) && element.has(cssClass("open"))) {
                    element.scrollIntoView(instant().block(center)).click();
                }

                if (stringContainsAllListWords(element.text(), values)) {
                    foundElement = true;
                    break;
                }
            }
            if (!foundElement) {
                throwError("The searched text was not found in the list!");
            }
        }
    }

    public void seeTextInItemsInOrder(String textValueToBeChecked, List<By> elementParametersList, int expectedOrder) {
        SelenideElement parentOfAllItems = getElement(elementParametersList.get(0));
        By formattedItemDefinition = addDotPrefixToXpathLocator(elementParametersList.get(1));
        ElementsCollection itemsCollection = parentOfAllItems.$$(formattedItemDefinition);

        itemsCollection.get(expectedOrder).shouldHave(Condition.text(textValueToBeChecked));
    }

    public void setSliderToValue(List<By> elementParametersList, int value) {
        waitUntilPageIsLoaded();
        SelenideElement sliderElement = getElementsCollectionNew(elementParametersList).get(0);
        SelenideElement actualValueText = sliderElement.find(elementParametersList.get(5));
        double actualValue = parseDouble(actualValueText.text().replaceAll("\\D+", ""));
        double previousValue = 0;
        while (actualValue < value && previousValue != actualValue) {
            sliderElement.sendKeys(Keys.ARROW_RIGHT);
            previousValue = actualValue;
            actualValue = parseDouble(actualValueText.text().replaceAll("\\D+", ""));
        }
        while (actualValue > value && previousValue != actualValue) {
            sliderElement.sendKeys(Keys.ARROW_LEFT);
            previousValue = actualValue;
            actualValue = parseDouble(actualValueText.text().replaceAll("\\D+", ""));
        }

        actualValueText = sliderElement.find(elementParametersList.get(5));
        actualValue = parseDouble(actualValueText.text().replaceAll("\\D+", ""));

        if (actualValue != (double) value) {
            throwError("Actual and Expected value not match!");
        }
    }

    public void dragAndDrop(List<By> elementParametersList, int source, int target) {
        System.out.println(elementParametersList);
        System.out.println(source);
        System.out.println(target);
        
        ElementsCollection elementsCollection = getElementsCollection(elementParametersList.get(3));
        SelenideElement elementSource = elementsCollection.get(source - 1);
        SelenideElement elementTarget = elementsCollection.get(target-1);

        System.out.println(elementSource);
        System.out.println(elementSource.text());
        System.out.println(elementTarget);
        System.out.println(elementTarget.text());

        WebDriver driver = getDriver();

        Actions builder = new Actions(driver);

        Action dragAndDrop = builder.clickAndHold(elementSource)
                .moveToElement(elementTarget)
                .release(elementTarget)
                .build();

        dragAndDrop.perform();
    }

    private SelenideElement findDropdown(List<By> elementParametersList, int order) {
        waitUntilPageIsLoaded();
        ElementsCollection elementsCollection = getElementsCollection(elementParametersList.get(1));
        int index = 0;

        for (SelenideElement element : elementsCollection) {
            if (element.find(elementParametersList.get(0)).exists() ||
                elementParametersList.get(1).equals(By.xpath("//csobp-custom-select")) ||
                checkIfSiblingExists(element, elementParametersList.get(0))) {
                index++;
                if (index == order) {
                    element.shouldBe(visible);
                    return element;
                }
            }
        }
        throwError("Error! Element not found!");
        return null;
    }

    private boolean checkIfSiblingExists(SelenideElement currentElement, By potentialSiblingElementRepresentation) {
        try {
            WebElement parentOfCurrentElement = currentElement.findElement(By.xpath(".."));
            return !parentOfCurrentElement.findElements(potentialSiblingElementRepresentation).isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    private SelenideElement getElementFromCollection(ElementsCollection elementsCollection) {
        SelenideElement selenideElement = null;
        for (SelenideElement element : elementsCollection) {
            waitInSeconds(0.25);
            if (element.isDisplayed()) {
                selenideElement = element;
                break;
            }
        }
        return selenideElement;
    }

    public void verifyDatesAreSorted(By elementDefinition, String order) {
        List<String> datesTexts = getElementsCollection(elementDefinition).texts();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");

        List<LocalDate> dates = datesTexts.stream()
                .filter(text-> text.matches("\\d{2}\\.\\d{2}\\.\\d{4}"))
                .map(text-> LocalDate.parse(text, formatter))
                .collect(Collectors.toList());

        if (dates.size()<2){
            throw new AssertionError("Not enough dates found to verify sorting!");
        }
        List<LocalDate> sorted = new ArrayList<>(dates);
        if (order.equalsIgnoreCase("ASC")){
            sorted.sort(Comparator.naturalOrder());
        } else if (order.equalsIgnoreCase("DESC")){
            sorted.sort(Comparator.reverseOrder());
        } else {
            fail("This sort does not exist!");
        }

        if(!dates.equals(sorted)){
            throw new AssertionError("Dates are not sorted in " + order + "order.\nActual: " + dates + "\nExpected: " + sorted);
        }
    }

    public int setNumberFromList(String number, By elementDefinition) {
        ElementsCollection productsItems = getElementsCollection(elementDefinition);
        int productCount = productsItems.size();

        setUniqueText(number, String.valueOf(productCount));
        System.out.println("INFO Uložený počet produktov (" + productCount + ") do premennej '" + number + "'");
        return productCount;
    }

    public void verifyCarouselIsChanging(List<By> parameterList) {
        final int MAX_CHECKS = 100;

        waitUntilPageIsLoaded();
        ElementsCollection carouselItems = getElementsCollectionNew(parameterList);
        List<Integer> previousActiveIndexes = null;

        for (int i = 0; i < MAX_CHECKS; i++ ) {
            List<Integer> currentActiveIndexes = getActiveCarouselIndexes(carouselItems);

            if (previousActiveIndexes != null && !previousActiveIndexes.equals(currentActiveIndexes)) {
                return;
            }

            previousActiveIndexes = new ArrayList<>(currentActiveIndexes);
        }

        throw new AssertionError("Carousel did not change within " + MAX_CHECKS + " checks.");
    }

    private List<Integer> getActiveCarouselIndexes(ElementsCollection items){
        List<Integer> indexes = new ArrayList<>();

        for (int i=0; i<items.size(); i++){
            String classes = items.get(i).getAttribute("class");

            if (classes != null && classes.contains("p-carousel-item-active")){
                indexes.add(i);
            }
        }

        return indexes;
    }

    public void openItemFromCarousel(String carouselItemName, List<By> carouselItemButtonParameterList, List<By> carouselRightArrowParameterList) {
        final int MAX_ATTEMPTS = 20;

        SelenideElement carouselItemButton = getElement(carouselItemButtonParameterList.get(0));
        SelenideElement carouselRightArrow = getElement(carouselRightArrowParameterList.get(0));

        for (int i = 0; i< MAX_ATTEMPTS; i++) {
            waitUntilPageIsLoaded();
            if (carouselItemButton.isDisplayed()) {
                carouselItemButton.scrollIntoView(instant().block(center)).click();
                return;
            }
            carouselRightArrow.click();
        }
        throw new AssertionError("Button for carousel item " + carouselItemName + " was not clicked.");
    }
}