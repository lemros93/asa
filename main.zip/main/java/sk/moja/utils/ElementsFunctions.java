package sk.moja.utils;

import com.codeborne.selenide.*;
import org.openqa.selenium.By;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.codeborne.selenide.CollectionCondition.sizeGreaterThan;
import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.ScrollIntoViewOptions.Block.*;
import static com.codeborne.selenide.ScrollIntoViewOptions.instant;
import static com.codeborne.selenide.Selectors.byAttribute;
import static com.codeborne.selenide.Selenide.$;

public class ElementsFunctions extends Functions {

    public LocalDate parseDateString(String dateString) {
        DateTimeFormatter[] formatters = new DateTimeFormatter[] {
                DateTimeFormatter.ofPattern("d.M.yyyy"),
                DateTimeFormatter.ofPattern("d. M. yyyy"),
                DateTimeFormatter.ofPattern("yyyy-MM-dd")
        };

        for (DateTimeFormatter formatter : formatters) {
            try {
                return LocalDate.parse(dateString, formatter);
            } catch (DateTimeParseException e) {
            }
        }

        throw new IllegalArgumentException("Nepodarilo sa parsovať dátum: " + dateString);
    }

    public String getTextFromElement(By elementDefinition, int order) {
        ElementsCollection elementsCollection = getElementsCollection(elementDefinition);
        return elementsCollection.get(order - 1).text();
    }

    public String getTextFromChildElement(By parentLocator, By childLocator, List<String> values) {
        ElementsCollection elementsCollection = getElementsCollection(parentLocator);
        SelenideElement parentElement = elementsCollection.stream()
                .filter(element ->
                        values.stream()
                                .allMatch(value -> element.getText().contains(value)))
                .findFirst()
                .orElseThrow(() ->
        new RuntimeException("Element with text " + values + " was not found"));
        return parentElement.$(childLocator).getText();
    }

    public void typeIntoInput(By elementDefinition, int order, String text, boolean fastTestValue) {
        ElementsCollection elementsCollection = getElementsCollection(elementDefinition);
        elementsCollection.get(order - 1).scrollIntoView(instant().block(center));
        if (text.isEmpty()) {
            elementsCollection.get(order - 1).val(" ").val("").clear();
        } else if (fastTestValue) {
            Configuration.fastSetValue = true;
            elementsCollection.get(order - 1).val(text);
            Configuration.fastSetValue = false;
        } else {
            elementsCollection.get(order - 1).val(text);
        }
    }

    public void typeIntoInputInIFrame(String text, By inputDefinition, By iFrameDefinition) {
        try {
            SelenideElement iFrame = getElement(iFrameDefinition).shouldBe(exist).shouldBe(visible);
            Selenide.switchTo().frame(iFrame);
            SelenideElement input = getElement(inputDefinition);
            input.setValue(text);
        } finally {
            Selenide.switchTo().defaultContent();
        }
    }

    public void clickOnButton(By elementDefinition, int order) {
        ElementsCollection elementsCollection = getElementsCollection(elementDefinition);
        elementsCollection.get(order - 1).scrollIntoView(instant().block(center)).click();
    }

    public void clickOnElementInIFrame(By elementDefinition, By iFrameDefinition) {
        try {
            SelenideElement iFrame = getElement(iFrameDefinition).shouldBe(exist).shouldBe(visible);
            Selenide.switchTo().frame(iFrame);
            SelenideElement selenideElement = getElement(elementDefinition);
            selenideElement.scrollIntoView(instant().block(end)).click();
        } finally {
            Selenide.switchTo().defaultContent();
        }
    }

    public void verifyTextInElementsCollection(By elementDefinition, List<String> values) {
        waitInSeconds(5);
        waitUntilPageIsLoaded();
        ElementsCollection listOfPayments = getElementsCollection(elementDefinition).shouldHave(sizeGreaterThan(0));

        listOfPayments.get(0).shouldBe(visible);
        boolean foundElement = false;

        for (SelenideElement element : listOfPayments) {
            if (element.parent().has(cssClass("openable-item")) && !element.parent().has(cssClass("open"))) {
                element.parent().scrollIntoView(instant().block(center)).click();
            } else if (element.has(cssClass("openable-item")) && !element.has(cssClass("open"))) {
                element.scrollIntoView(instant().block(center)).click();
            }
            if (stringContainsAllListWords(element.text(), values)) {
                foundElement = true;
                break;
            }
        }

        if (!foundElement) {

            throwError("The searched text was not found in the list!");
        }
    }

    public void verifyAnyOfProvidedTextsIsDisplayedInElement (List<String> listOfTexts, By elementDefinition) {
        SelenideElement element = getElement(elementDefinition);
        String elementText = element.getText().trim();
        String elementValue = element.getValue() != null ? element.getValue().trim() : "";

        String elementContent = (elementText + " " + elementValue).trim();

        for(String text : listOfTexts) {
            if(elementContent.contains(text))
                return;
        }
        throw new AssertionError(
                "Text of element located by " + elementDefinition.toString() +
                " does not contain any of following texts: " + listOfTexts
        );
    }

    public void verifyRegexInElement(String regex, By elementDefinition) {
        SelenideElement element = getElement(elementDefinition);
        String elementText = element.getText().trim();
        String elementValue = element.getValue() != null ? element.getValue().trim() : "";

        String elementContent = (elementText + " " + elementValue).trim();

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(elementContent);

        if (!matcher.find()) {
            throw new AssertionError(
                "Text of element located by " + elementDefinition.toString() +
                " does not contain text defined by regex.\nExpected regex: " + regex +
                "\nCurrent text in the element: " + elementText +
                "\nCurrent value in the element: " + elementValue
            );
        }
    }

    public String getRegexMatchFromElement(String regex, By elementDefinition) {
        SelenideElement element = getElement(elementDefinition);

        String elementText = element.getText();
        String elementValue = element.getValue();

        StringBuilder contentBuilder = new StringBuilder();

        if (elementText != null && !elementText.trim().isEmpty()) {
            contentBuilder.append(elementText.trim());
        }

        if (elementValue != null && !elementValue.trim().isEmpty()) {
            contentBuilder.append(" ").append(elementValue.trim());
        }

        String elementContent = contentBuilder.toString().trim();

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(elementContent);

        if (matcher.find()) {
            return matcher.group();
        } else {
            throw new AssertionError(
                    "Text/value of element located by " + elementDefinition.toString() +
                            " does not contain text defined by regex.\nExpected regex: " + regex +
                            "\nCurrent combined content: " + elementContent
            );
        }
    }

    public void verifyRemovedTextFromElementsCollection(By elementDefinition, List<String> values) {
        waitInSeconds(5);
        ElementsCollection listOfPayments = getElementsCollection(elementDefinition);

        if (listOfPayments.isEmpty())
            return;

        listOfPayments.get(0).shouldBe(visible);

        listOfPayments.get(0).scrollIntoView(instant().block(center));
        for (SelenideElement element : listOfPayments) {
            if (element.parent().has(cssClass("openable-item")) && !element.parent().has(cssClass("open"))) {
                element.parent().scrollIntoView(instant().block(center)).click();
            } else if (element.has(cssClass("openable-item")) && !element.has(cssClass("open"))) {
                element.scrollIntoView(instant().block(center)).click();
            }
            if (stringContainsAllListWords(element.text(), values)) {
                throwError("The searched text was found in the list! Expectation is: it should not be found!");
                break;
            }
        }
    }

    public void verifyRemovedTextInElementsCollectionWithLessInformation(By elementDefinition, List<String> values) {
        waitInSeconds(5);
        ElementsCollection listOfPayments = getElementsCollection(elementDefinition);

        if (listOfPayments.isEmpty()) {
            return;
        }
        listOfPayments.get(0).shouldBe(visible);

        listOfPayments.get(0).scrollIntoView(instant().block(center));
        for (SelenideElement element : listOfPayments) {
            if (element.parent().has(cssClass("openable-item")) && element.parent().has(cssClass("open"))) {
                element.parent().scrollIntoView(instant().block(center)).click();
            } else if (element.has(cssClass("openable-item")) && element.has(cssClass("open"))) {
                element.scrollIntoView(instant().block(center)).click();
            }
            if (stringContainsAllListWords(element.text(), values)) {
                throwError("The searched text was found in the list! Expectation is: it should not be found!");
            }
        }
    }

    public void checkButton(By elementDefinition, String check) {
        SelenideElement selenideElement = getElement(elementDefinition);

        String tagName = selenideElement.getTagName();

        if(tagName.equalsIgnoreCase("csob-checkbox")) {
            SelenideElement checkbox = selenideElement.find(byAttribute("type", "checkbox"));

            if (check.equals("check")) {
                if (!checkbox.has(checked)) {
                    selenideElement.scrollIntoView(instant().block(center)).click();
                }
                checkbox.shouldBe(checked);
            } else if (check.equals("uncheck")) {
                if (checkbox.has(checked)) {
                    selenideElement.scrollIntoView(instant().block(center)).click();
                }
                checkbox.shouldNotBe(checked);
            }
        } else if (tagName.equalsIgnoreCase("maia-checkbox")){
            String ariaChecked = selenideElement.getAttribute("aria-checked");

            if (check.equals("uncheck")) {
                if ("true".equalsIgnoreCase(ariaChecked)) {
                    selenideElement.scrollIntoView(instant().block(center)).click();
                }
                selenideElement.shouldHave(Condition.attribute("aria-checked", "false"));
            } else if (check.equals("check")) {
                if ("false".equalsIgnoreCase(ariaChecked)){
                    selenideElement.scrollIntoView(instant().block(center)).click();
                }
                selenideElement.shouldHave(Condition.attribute("aria-checked", "true"));
            }
        }
    }

    public void controlCheckUncheckedRadioButton(By elementDefinition, String checked) {
        SelenideElement selenideElement = getElement(elementDefinition);

        if (checked.equals("uncheck")) {
            selenideElement.shouldHave(Condition.attribute("aria-checked", "false"));
        } else if (checked.equals("check")) {
            selenideElement.shouldHave(Condition.attribute("aria-checked", "true"));
        }
    }

    public void should(By elementDefinition, String prefix, String conditionText, int order) {
        ElementsCollection elementsCollection = getElementsCollection(elementDefinition);
        SelenideElement selenideElement = elementsCollection.get(order - 1);
        WebElementCondition condition = sk.moja.enumerators.Condition.valueOf(conditionText.toUpperCase()).value;

        switch (prefix) {
            case "not be":
                selenideElement.shouldNotBe(condition);
                break;
            case "be":
                selenideElement.shouldBe(condition);
                break;
            case "not":
                selenideElement.shouldNot(condition);
                break;
            case "":
                selenideElement.should(condition);
                break;
        }
    }

    public void elementWithTextShouldBe(By elementDefinition, String prefix, String conditionText, List<String> values) {
        ElementsCollection elementsCollection = getElementsCollection(elementDefinition);
        WebElementCondition condition = sk.moja.enumerators.Condition.valueOf(conditionText.toUpperCase()).value;
        SelenideElement selenideElement = null;
        for (SelenideElement element : elementsCollection) {
            element.scrollIntoView(instant().block(center));
            if (stringContainsAllListWords(element.text(), values)) {
                selenideElement = element;
                break;
            }
        }
        if (selenideElement != null) {
            switch (prefix) {
                case "not be":
                    if (conditionText.equals("disabled")) {
                        if (selenideElement.toString().contains(("disabled")))
                            throwError("The searched element with text was not found!");
                    } else
                        selenideElement.shouldNotBe(condition);
                    break;
                case "be":
                    if (conditionText.equals("disabled")) {
                        if (!selenideElement.toString().contains(("disabled")))
                            throwError("The searched element with text was not found!");

                    } else
                        selenideElement.shouldBe(condition);
                    break;
                case "not":
                    selenideElement.shouldNot(condition);
                    break;
                case "":
                    selenideElement.should(condition);
                    break;
            }
        } else {
            throwError("The searched element with text was not found!");
        }
    }

    public void verifyChildElementVisibilityInsideParentElementContainingText(String condition, By elementToBeVerified, By parentElement, String textContainedInParentElement) {
        ElementsCollection potentialParentElements = getElementsCollection(parentElement);
        SelenideElement parentElementContainingSpecificText = potentialParentElements.findBy(Condition.text(textContainedInParentElement)).scrollIntoView(instant().block(center)).shouldBe(visible);
        By elementToBeVerifiedFormatted = addDotPrefixToXpathLocator(elementToBeVerified);
        SelenideElement elementToBeVerifiedInisdeParentElement = parentElementContainingSpecificText.$(elementToBeVerifiedFormatted);

        if (condition.equals("see")) {
            elementToBeVerifiedInisdeParentElement.shouldBe(visible);
        } else if (condition.equals("don't see")) {
            elementToBeVerifiedInisdeParentElement.shouldNotBe(visible);
        } else {
            throwError("Incorrect visibility condition");
        }
    }

    public void clickOnElementWithText(By elementDefinition, List<String> values) {
        waitInSeconds(5);
        waitUntilPageIsLoaded();
        ElementsCollection elementsCollection = getElementsCollection(elementDefinition);
        boolean found = false;
        for (SelenideElement element : elementsCollection) {
            element.scrollIntoView(instant().block(center));
            if (stringContainsAllListWords(element.text(), values)) {
                element.scrollIntoView(instant().block(center)).click();
                found = true;
                break;
            }
        }
        if (!found) {
            throwError("The searched element with text was not found!");
        }
    }

    public void doAction(By action, By elementDefinition, List<String> searchedText) {
        ElementsCollection elementsCollection = getElementsCollection(elementDefinition).shouldHave(sizeGreaterThan(0));
        elementsCollection.get(0).shouldBe(visible);
        SelenideElement selenideElement = null;
        SelenideElement elementWithAction = null;
        boolean found;
        for (SelenideElement element : elementsCollection) {

            elementWithAction = element.find(action);
            found = stringContainsAllListWords(element.text(), searchedText);

            if (elementWithAction.exists() && found) {
                selenideElement = element;
                break;
            }

        }
        if (selenideElement == null) {
            throwError("Element not found!");
        }
        elementWithAction.scrollIntoView(instant().block(center)).click();

        waitInSeconds(4);
        waitUntilPageIsLoaded();
        $(By.xpath("//body")).shouldBe(visible);
        waitUntilPageIsLoaded();
    }

    public void clickIfElementIsDisplayed(By elementDefinition) {
        waitUntilPageIsLoaded();
        waitInSeconds(3);
        waitUntilPageIsLoaded();
        SelenideElement selenideElement = getElement(elementDefinition);
        if (selenideElement.isDisplayed())
            selenideElement.scrollIntoView(instant().block(center)).click();
    }

    public void typeIntoInputIfElementIsDisplayed(By elementDefinition, int order, String text) {
        waitUntilPageIsLoaded();
        ElementsCollection elementsCollection = getElementsCollection(elementDefinition);
        if (elementsCollection.get(order - 1).isDisplayed()) {
            if (text.isEmpty()) {
                elementsCollection.get(order - 1).val(" ").val("").clear();
            } else {
                elementsCollection.get(order - 1).val(text);
            }
        }
    }

    public void uploadFile(By elementDefinition, String filePath, int order) {
        waitUntilPageIsLoaded();
        ElementsCollection elementsCollection = getElementsCollection(elementDefinition);
        elementsCollection.get(order - 1).scrollIntoView(instant().block(center));
        elementsCollection.get(order - 1).uploadFile(new File(filePath));
    }

    public void switchTo(By elementDefinition) {
        Selenide.switchTo().frame(getElement(elementDefinition));
    }

    public String getTextFromElementCollection(By elementDefinition, int order) {
        return getElementsCollection(elementDefinition).get(order - 1).text();
    }

    public void verifyDateIsOneDayEarlier(LocalDate firstDate, LocalDate secondDate) {

        if (!firstDate.equals(secondDate.minusDays(1))){
            throw new AssertionError(
                    firstDate + " is not one day earlier than " + secondDate
            );
        }

    }
}