package sk.moja.utils;

import com.codeborne.selenide.Configuration;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.edge.EdgeOptions;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static sk.moja.enumerators.Constants.SERVER_WEB_DESTINATION;
import static sk.moja.enumerators.CustomProperties.*;
import static sk.moja.logger.GuiFormatter.printError;

public class PrepareData {

    private static File tempDir = new File(getDestination() + "/temp/");
    private static String localRunFrom = getRunFrom();

    public static void copyPropertyFile(String path) {
        try {
            FileUtils.copyFile(new File(path), new File(tempDir + "/property.properties"));
        } catch (IOException e) {
            if (localRunFrom.equals("localGui")) {
                printError(e);
            }
            e.printStackTrace();
        }
    }

    public static void makeTempFeatureCopies(List<String> listOfFeature) {
        deleteTempFeatureCopies();
        File featureDst = new File(tempDir + "/features/");
        if (!featureDst.mkdirs()) {
            System.out.println("Subor: " + featureDst + " sa nepodarilo vytvorit");
        }
        for (String s : listOfFeature) {
            System.out.println("Spracuvávam feature súbor: " + s);
            try {
                File src = new File(s);
                if (src.exists() && src.isDirectory()) {
                    FileFilter fileFilter = pathname -> pathname.getAbsolutePath().endsWith(".feature") || pathname.isDirectory();
                    List<String> listOfFolderName = Arrays.asList(src.getAbsolutePath().replace("\\ ", "").replace("\\", "/").split("/"));
                    String folderName = listOfFolderName.get(listOfFolderName.size() - 1);
                    File dst = new File(featureDst + "/" + folderName);
                    FileUtils.copyDirectory(src, dst, fileFilter);
                    System.out.println("Skopírovaný priečinok: " + src.getAbsolutePath() + "-> " + featureDst.getAbsolutePath() + featureDst.exists());
                }
                if (src.exists() && src.isFile()) {
                    FileUtils.copyFileToDirectory(src, featureDst);
                    System.out.println("Skopírovaný súbor: " + src.getAbsolutePath() + "-> " + featureDst.getAbsolutePath() + " " + featureDst.exists());
                }
            } catch (IOException e) {
                if (localRunFrom.equals("localGui")) {
                    printError(e);
                }
                e.printStackTrace();
            }
        }
        listFiles(featureDst, "");

    }

    private static void listFiles(File folder, String indent){
        File[] files = folder.listFiles();
        if (files != null){
            for (File f : files){
                System.out.println(indent  + (f.isDirectory() ? "[DIR] " : "     ") + f.getName());
                if (f.isDirectory()){
                    listFiles(f, indent+"     ");
                }
            }
        }
    }

    public static void deleteTempFeatureCopies() {
        for (int i = 0; i < 10; i++) {
            System.gc();
        }
        if (tempDir.exists()) {
            try {
                FileUtils.forceDelete(tempDir);
            } catch (IOException e) {
                if (localRunFrom.equals("localGui")) {
                    printError(e);
                }
                e.printStackTrace();
            }
        }
    }

    public static void copyReportsAfterRun() {
        File srcReports = new File(tempDir + "/reports/");
        File srcFeatures = new File(tempDir + "/features/");
        File dst = new File(getReportsFolder());
        if (srcReports.exists()) {
            try {
                FileUtils.copyDirectory(srcReports, dst);
                FileUtils.copyDirectory(srcFeatures, dst);
                deleteTempFeatureCopies();
            } catch (IOException e) {
                if (localRunFrom.equals("localGui")) {
                    printError(e);
                }
                e.printStackTrace();
            }
        }
        if (getRunFrom().equals("server")){
            try {
                FileUtils.copyDirectory(new File(getDestination() + "/" + getTimestampFolder()),new File(SERVER_WEB_DESTINATION + "/" + getTimestampFolder()));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

    }

    public static void setProxy() {
        System.out.println("setProxy");
        Proxy proxy = new Proxy();
        proxy.setHttpProxy("serverproxy.be.net.acc.sys:8080");
        proxy.setSslProxy("serverproxy.be.net.acc.sys:8080");

        EdgeOptions options = new EdgeOptions();
        options.setProxy(proxy);

        options.addArguments("--no-sandbox");

        Configuration.browserCapabilities = options;

        Configuration.webdriverLogsEnabled = true;
    }

    public static void prepareData(){
        System.out.println("PrepareDataMain");
        System.out.println("Working Directory = " + System.getProperty("user.dir"));
        setRunFrom(System.getProperty("runFrom"));
        localRunFrom = getRunFrom();
        setDestination();
        tempDir = new File(getDestination() + "/temp/");
        List<String> listOfFeature = new ArrayList<>();
        Collections.addAll(listOfFeature, System.getProperty("feature"));
        System.out.println("[Config] listOfFeature: " + listOfFeature);
        makeTempFeatureCopies(listOfFeature);
        String propertyPath = System.getProperty("propertyFileLocation");
        System.out.println("[Config] propertyPath: " + propertyPath);
        copyPropertyFile(propertyPath);
    }

    public static void main(String[] args) {

        prepareData();
    }
}
