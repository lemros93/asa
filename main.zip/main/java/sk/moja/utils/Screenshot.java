package sk.moja.utils;

import com.assertthat.selenium_shutterbug.core.Capture;
import com.assertthat.selenium_shutterbug.core.PageSnapshot;
import com.assertthat.selenium_shutterbug.core.Shutterbug;

import org.openqa.selenium.WebDriver;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import java.io.*;
import java.util.Iterator;


public class Screenshot {

    String path = "";
    String documentId = "";
    String filename = ""; // TODO Recheck if really needed and refactor
    String format = "png";
    WebDriver driver;
    PageSnapshot pageSnapshot;

    public Screenshot(WebDriver driver, String location, String screenshotName){
        this.driver = driver;
        this.path = location + screenshotName + "." + this.format;
        this.filename = screenshotName;
    }

    public String getPath() {
        return path;
    }

    public String getDocumentId() {
        return documentId;
    }

    public String getFormat() {
        return format;
    }

    public void createScreenshot(Capture capture) {
        this.pageSnapshot = Shutterbug.shootPage(driver, capture);
        try {
            this.compressScreenshot();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void compressScreenshot() throws IOException {
        File compressedImageFile = new File(this.path);
        OutputStream os = new FileOutputStream(compressedImageFile);
        Iterator<ImageWriter> writers = ImageIO.getImageWritersByFormatName(this.format);
        ImageWriter writer = writers.next();
        ImageOutputStream ios = ImageIO.createImageOutputStream(os);
        writer.setOutput(ios);
        ImageWriteParam param = writer.getDefaultWriteParam();
        if (param.canWriteCompressed()) {
            param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
            param.setCompressionQuality(0.0f);
        }
        writer.write(null, new IIOImage(this.pageSnapshot.getImage(), null, null), param);
        os.close();
        ios.close();
        writer.dispose();
    }
}