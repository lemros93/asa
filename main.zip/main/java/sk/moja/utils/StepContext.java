package sk.moja.utils;

public class StepContext {
    private static final ThreadLocal<String> resolvedStepName = new ThreadLocal<>();
    private static final ThreadLocal<String> currentStepName = new ThreadLocal<>();
    private static final ThreadLocal<String> currentStepId = new ThreadLocal<>();
    private static final ThreadLocal<String> screenshotPath = new ThreadLocal<>();
    private static final ThreadLocal<String> failedScreenshotPath = new ThreadLocal<>();
    private static final ThreadLocal<String> currentStepStatus = new ThreadLocal<>();
    private static final ThreadLocal<String> downloadFolder = new ThreadLocal<>();

    public static void setFailedScreenshotPath(String path) {
        failedScreenshotPath.set(path);
    }

    public static String getFailedScreenshotPath() {
        return failedScreenshotPath.get();
    }

    public static void setScreenshotPath(String path) {
        screenshotPath.set(path);
    }

    public static String getScreenshotPath() {
        return screenshotPath.get();
    }

    public static void setCurrentStepName(String name) {
        currentStepName.set(name);
    }

    public static String getCurrentStepName() {
        return currentStepName.get() != null ? currentStepName.get() : "step";
    }

    public static void setStepNameTransformed(String name) {
        resolvedStepName.set(name);
    }

    public static String getStepNameTransformed() {
        return resolvedStepName.get();
    }

    public static void setCurrentStepStatus(String status) {
        currentStepStatus.set(status);
    }

    public static String getCurrentStepStatus() {
        return currentStepStatus.get();
    }

    public static void setDownloadFolder(String folder) {
        downloadFolder.set(folder);
    }

    public static String getDownloadFolder() {
        return downloadFolder.get();
    }

    public static void setCurrentStepId(String StepId) {
        currentStepId.set(StepId);
    }

    public static String getCurrentStepId() {
        return currentStepId.get();
    }

    public static void clear() {
        resolvedStepName.remove();
        currentStepName.remove();
        failedScreenshotPath.remove();
        screenshotPath.remove();
        currentStepStatus.remove();
        currentStepId.remove();
        //downloadFolder.remove();
    }


}