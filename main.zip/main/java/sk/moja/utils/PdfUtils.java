package sk.moja.utils;

import com.codeborne.pdftest.PDF;
import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class PdfUtils extends Functions {

    public File getLatestDownloadedFile(){
        Path downloadsDir = Paths.get(StepContext.getDownloadFolder());
        // if we need debug in server System.out.println("The file to which it is downloaded is " + downloadsDir);
        int timeoutSeconds = 30;
        int waitedMs = 0;
        File downloadedFile = null;

        while (waitedMs < timeoutSeconds * 1000){
            downloadedFile = findLatestFile(downloadsDir.toFile());

            if(downloadedFile != null){
                //System.out.println("Found downloaded file: " +downloadedFile.getAbsolutePath());
                break;
            }
            Selenide.sleep(500);
            waitedMs+=500;
        }

        if (downloadedFile==null){
            throw new AssertionError("No PDF file found in the folder or subfolder.");
        }
        if (downloadedFile.length()== 0){
            throw new AssertionError("The downloaded file exists but has a size of 0.");
        }
        System.out.println("The file was successfully downloaded: " + downloadedFile.getName());
        return downloadedFile;
    }

    public List<File> listAllFiles(File root){
        List<File> result = new ArrayList<>();
        File[] files = root.listFiles();

        if (files==null){
            return result;
        }

        for (File f : files){
            if (f.isFile()){
                result.add(f);
            } else if (f.isDirectory()) {
                result.addAll(listAllFiles(f));
            }
        }
        return result;
    }

    private File findLatestFile(File root){
        return listAllFiles(root).stream()
                .filter(f-> f.getName().toLowerCase().endsWith(".pdf"))
                .max(Comparator.comparingLong(File::lastModified))
                .orElse(null);
    }

    public File getNewlyDownloadedFile(List<File> beforeDownload) throws Exception{
        File latest = getLatestDownloadedFile();

        boolean alreadyPresent = beforeDownload.stream()
                .anyMatch(file -> file.getAbsolutePath().equals(latest.getAbsolutePath()));

        if (alreadyPresent){
            throw new AssertionError("No new document has been added to the folder.");
        }

        return latest;
    }

    public PDF loadLatestPdf() throws Exception{
        File latestFile = getLatestDownloadedFile();

        if (!latestFile.getName().toLowerCase().endsWith(".pdf")){
            throw new AssertionError("The last file is not a PDF: " + latestFile.getName());
        }

        return new PDF(latestFile);
    }

    private String normalize(String s){
        if (s==null)
            return null;
        return s
                .replaceAll("\\s+", " ")
                .trim();
    }

    public boolean pdfContains(String inputText) throws Exception {
        PDF pdf = loadLatestPdf();

        String normalizePdf = normalize(pdf.text);
        String normalizedinputText = normalize(inputText);
        return normalizePdf.contains(normalizedinputText);
    }

    public String pdfGetText() throws Exception {
        PDF pdf = loadLatestPdf();
        return normalize(pdf.text);
    }
}
