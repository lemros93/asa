package sk.moja.utils;

import com.codeborne.selenide.*;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import sk.moja.base.TestBase;
import sk.moja.enumerators.CustomDates;
import sk.moja.enumerators.CustomProperties;
import sk.moja.enumerators.UniqueValues;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selectors.*;
import static com.codeborne.selenide.Selenide.*;
import static java.lang.Double.parseDouble;
import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.List;

public class Functions extends TestBase {

    public String getText(String text) {
        String propertyValue = CustomProperties.getProperty(text);
        String dateValue = CustomDates.getDates(text);

        if (propertyValue != null) {
            return propertyValue;
        } else if (dateValue != null) {
            return dateValue;
        } else if (text.startsWith("unique_")) {
            UniqueValues uniqueValues = new UniqueValues();
            return uniqueValues.getUniqueIdentifierValue(text);
        } else {
            return text;
        }
    }

    public String setText(String text) {
        if (text.startsWith("unique_amount_")) {
            UniqueValues uniqueValues = new UniqueValues();
            uniqueValues.setUniqueAmount(text);
            return uniqueValues.getUniqueIdentifierValue(text);
        } else if (text.startsWith("unique_")) {
            UniqueValues uniqueValues = new UniqueValues();
            uniqueValues.setUniqueIdentifier(text);
            return uniqueValues.getUniqueIdentifierValue(text);
        } else {
            fail("Wrong format, use prefix unique_!");
            assert false;
            return null;
        }
    }

    public void setUniqueText(String key, String value) {
        if (key.startsWith("unique_")) {
            UniqueValues uniqueValues = new UniqueValues();
            uniqueValues.setUniqueIdentifierWithText(key, value);
        } else {
            fail("Wrong format use unique_!");
            assert false;
        }
    }

    public static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = BigDecimal.valueOf(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

    public void compareAmounts(String srcValue, String operation, double value, String dstValue) {
        double srcDoubleValue = parseDouble(
                srcValue.replace("EUR", "").
                        replace("USD", "").
                        replace("CZK", "").
                        replace("GBP", "").
                        replace(" ", "").
                        replace(",", "."));
        double dstDoubleValue = parseDouble(
                dstValue.replace("EUR", "").
                        replace("USD", "").
                        replace("CZK", "").
                        replace("GBP", "").
                        replace(" ", "").
                        replace(",", "."));

        switch (operation) {
            case "plus":
                if ((round(dstDoubleValue, 2) != round((srcDoubleValue + value), 2))) {
                    fail("not equals");
                    assert false;
                } else
                    break;
            case "minus":
                if (round(dstDoubleValue, 2) != round((srcDoubleValue - value), 2)) {
                    fail("not equals");
                    assert false;
                } else
                    break;
            default:
                fail("not allowed operation");
                assert false;
                break;
        }
    }

    protected ElementsCollection getElementsCollection(By byElementObject) {
        ElementsCollection elementsCollection = null;
        try {
            elementsCollection = $$(byElementObject);
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
        return elementsCollection;
    }

    protected ElementsCollection getElementsCollectionNew(List<By> byElementObjects) {
        return getElementsCollection(byElementObjects.get(0));
    }

    protected SelenideElement getElement(By byElementObject) {
        SelenideElement selenideElement = null;
        try {
            selenideElement = $(byElementObject);
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
        return selenideElement;
    }

    public void waitUntilPageIsLoaded() {
        Selenide.sleep(1000);
        SelenideElement selenideElement = getElement(byXpath("//csob-block-template"));
        selenideElement.should(disappear);
    }

    public void waitUntilElementLoadersAreDone() {
        ElementsCollection elementLoaders = getElementsCollection(byXpath("//*[contains(@class, 'block-ui-wrapper') and contains(@class, 'active')]"));

        try {
            Selenide.Wait()
                    .withTimeout(Duration.ofSeconds(1))
                    .until(driver -> !elementLoaders.isEmpty());

            elementLoaders.shouldHave(CollectionCondition.size(0));
        } catch (TimeoutException e) {
            // ignored - not necessary that element loaders are active
        }
    }

    public static void closeBrowser() {
        closeWebDriver();
    }

    public void waitInSeconds(int seconds) {
        Selenide.sleep(seconds * 1000L);
    }

    protected void waitInSeconds(double seconds) {
        Selenide.sleep((long) (seconds * 1000L));
    }

    protected WebDriver getDriver() {
        return WebDriverRunner.getWebDriver();
    }

    public void pressTab() {
        actions().sendKeys(Keys.TAB).perform();
    }

    public void pressEscape() {
        SelenideElement selenideElement = $(getDriver().switchTo().activeElement());
        selenideElement.pressEscape();
    }

    public void throwError(String errorMessage) {
        assert false;
        fail(errorMessage);
    }

    public static boolean stringContainsAllListWords(String word, List<String> keywords) {
        boolean containsAll = true;
        for (String keyword : keywords) {
            if (!word.contains(keyword)) {
                containsAll = false;
                break;
            }
        }
        return containsAll;
    }

    public void switchToTab(int tabNumber) {
        Selenide.switchTo().window(tabNumber - 1);
    }

    protected By addDotPrefixToXpathLocator(By locator) {
        String locatorStr = locator.toString();

        if (locatorStr.startsWith("By.xpath: ")) {
            String xpath = locatorStr.replaceFirst("By\\.xpath: ", "").trim();

            if (xpath.startsWith(".//") || xpath.startsWith("./")) {
                return By.xpath(xpath);
            }
            if (xpath.startsWith("//")) {
                return By.xpath("." + xpath);
            }
            if (!xpath.startsWith(".")) {
                return By.xpath(".//" + xpath);
            }
        }

        // for CSS, ID, etc., return as-is
        return locator;
    }

    public void verifyEnvironment(String baseUrl, String currentUrl) {
        try {
            URL base = new URL(baseUrl);
            URL current = new URL(currentUrl);

            String baseHost = base.getHost();
            String currentHost = current.getHost();

            System.out.println("Expected host: " + baseHost);
            System.out.println("Current host: " + currentHost);

            assertEquals("Environment changed!", baseHost, currentHost);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }

    public String calculate(String amountValueStringOne, String operation, String amountValueStringTwo) {
        double number1 = parseDouble(
                amountValueStringOne.replace("EUR", "").
                        replace("USD", "").
                        replace("CZK", "").
                        replace("GBP", "").
                        replace(" ", "").
                        replace(",", "."));
        double number2 = parseDouble(
                amountValueStringTwo.replace("EUR", "").
                        replace("USD", "").
                        replace("CZK", "").
                        replace("GBP", "").
                        replace(" ", "").
                        replace(",", "."));

        double result = 0;

        switch (operation) {
            case "plus":
                result = round((number1 + number2), 2);
                break;
            case "minus":
                result = round((number1 - number2), 2);
                break;
            default:
                fail("Operation '" + operation + "' is not supported. Allowed values: plus, minus");
                assert false;
                break;
        }

        return String.valueOf(result);
    }
}