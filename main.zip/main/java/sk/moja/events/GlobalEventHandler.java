package sk.moja.events;

import io.cucumber.plugin.ConcurrentEventListener;
import io.cucumber.plugin.event.*;
import sk.moja.db.importer.plugin.StepEnrichmentPlugin;
import sk.moja.logger.GuiFormatter;
import sk.moja.logger.JiraReporter;
import sk.moja.logger.Reporting;
import sk.moja.partialResults.PartialResultsEventHandler;

import static sk.moja.enumerators.CustomProperties.getProperty;
import static sk.moja.enumerators.CustomProperties.getRunFrom;

public class GlobalEventHandler implements ConcurrentEventListener {

    private final Reporting reporting;
    private final GuiFormatter guiFormatter;
    private final JiraReporter jiraReporter;
    private final PartialResultsEventHandler partialResultsEventHandler;
    private final StepEnrichmentPlugin stepEnrichmentPlugin;

    public GlobalEventHandler() {
        this.reporting = new Reporting();
        this.guiFormatter = new GuiFormatter();
        this.jiraReporter = new JiraReporter();
        this.partialResultsEventHandler = new PartialResultsEventHandler();
        this.stepEnrichmentPlugin = new StepEnrichmentPlugin();
    }

    @Override
    public void setEventPublisher(EventPublisher publisher) {

        publisher.registerHandlerFor(TestStepStarted.class, reporting::handleStepStarted);
        publisher.registerHandlerFor(TestStepFinished.class, reporting::handleTestStepFinished);

        if(!getRunFrom().equals("server")) {
            publisher.registerHandlerFor(TestCaseStarted.class, guiFormatter::handleTestCaseStarted);
            publisher.registerHandlerFor(TestCaseFinished.class, guiFormatter::handleTestCaseFinished);
            publisher.registerHandlerFor(TestRunFinished.class, guiFormatter::handleTestRunFinished);
            publisher.registerHandlerFor(TestStepFinished.class, guiFormatter::handleTestStepFinished);
            publisher.registerHandlerFor(TestSourceRead.class, guiFormatter::handleTestSourceRead);
        }

        publisher.registerHandlerFor(TestCaseStarted.class, jiraReporter::handleTestCaseStarted);
        publisher.registerHandlerFor(TestStepFinished.class, jiraReporter::handleTestStepFinished);
        publisher.registerHandlerFor(TestCaseFinished.class, jiraReporter::handleTestCaseFinished);
        publisher.registerHandlerFor(TestRunFinished.class, jiraReporter::handleTestRunFinished);

        publisher.registerHandlerFor(TestRunStarted.class, partialResultsEventHandler::collectCurrentFileContent);
        publisher.registerHandlerFor(TestCaseStarted.class, partialResultsEventHandler::checkScenarioPreconditions);
        publisher.registerHandlerFor(TestStepStarted.class, partialResultsEventHandler::getValueFromStoredFile);
        publisher.registerHandlerFor(TestStepFinished.class, partialResultsEventHandler::collectTestStepInfo);
        publisher.registerHandlerFor(TestRunFinished.class, partialResultsEventHandler::publishPartialResults);

       // if(getRunFrom().equals("server")) {
            publisher.registerHandlerFor(TestStepFinished.class, stepEnrichmentPlugin::onTestStepFinished);
        //}
    }
}