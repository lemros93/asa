package sk.moja.steps;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.WebDriverRunner;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import org.openqa.selenium.By;
import sk.moja.enumerators.Links;
import sk.moja.enumerators.UniqueValues;
import sk.moja.pages.Pages;
import sk.moja.pages.mojaCsob.DashboardPage;
import sk.moja.utils.*;

import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.codeborne.selenide.Selenide.*;
import static org.junit.Assert.assertTrue;
import static sk.moja.utils.StepContext.setStepNameTransformed;

public class Steps {
    private final Functions functions = new Functions();
    private final PdfUtils pdfUtils = new PdfUtils();
    private final ElementsFunctions elementsFunctions = new ElementsFunctions();
    private final CombinedElementsFunctions combinedElementsFunctions = new CombinedElementsFunctions();
    private Pages pages;

    @Given("^I open browser$")
    public void openBrowser() {
        Selenide.open("");
        pages = new Pages("");
        setStepNameTransformed("I open browser");
        open("");
        functions.waitUntilPageIsLoaded();
    }

    @Given("^I open \"(.*?)\" page$")
    public void openPage(String productName) {
        pages = new Pages(productName);
        String product = productName.toUpperCase().replace(" ", "_");
        setStepNameTransformed("I open \"" + product + "\" page");

        functions.waitUntilPageIsLoaded();
        open(Links.valueOf(product).value);
        functions.waitInSeconds(5);
        functions.waitUntilPageIsLoaded();
        functions.waitUntilElementLoadersAreDone();
    }

    @Given("^I open \"(.*?)\" page for \"(.*?)\"$")
    public void openProductDetailPage(String productName, String productNumber) {
        pages = new Pages(productName);
        String product = productName.toUpperCase().replace(" ", "_");
        String productId = functions.getText(productNumber);
        setStepNameTransformed("I open \"" + productName + "\" page for \"" + productId + "\"");
        functions.waitUntilPageIsLoaded();
        open(Links.valueOf(product).value + productId);
        functions.waitInSeconds(5);
        functions.waitUntilPageIsLoaded();
    }

    @When("^I test \"(.*?)\" page$")
    public void testProduct(String productName) {
        pages = new Pages(productName);
        setStepNameTransformed("I test \"" + productName + "\" page");
    }

    @Then("^I am on \"(.*?)\" page$")
    public void verifyUrl(String linkName) {
        functions.waitUntilPageIsLoaded();
        Links link = Links.valueOf((linkName.toUpperCase().replace(" ", "_")));
        String expectedUrl = link.value;

        setStepNameTransformed("I am on \"" + link.value + "\" page");
        System.out.println("Expected url: " + expectedUrl);
        System.out.println("Real url: " + WebDriverRunner.url());

        assertTrue(WebDriverRunner.url().contains(expectedUrl));
    }

    @Given("^I login as \"(.*?)\" with pin \"(.*?)\" and token \"(.*?)\"$")
    public void loginAsUserWithPinAndToken(String ippid, String pin, String token) {
        pages = new Pages("");

        try {
            fillInputWithString("", ippid, "Ippid");
            clickWhenTheSecondFactorIsOn("Accept cookies");
            fillInputWithString("", pin, "Pin");
            clickOnButton("Login");
            functions.waitUntilPageIsLoaded();
            elementsFunctions.clickIfElementIsDisplayed(pages.getParameterList("Token redirect").get(0));
            clickWhenTheSecondFactorIsOn("Show cronto token2");
            fillInputWithStringWhenTheSecondFactorIsOn(token, "Token");
            clickWhenTheSecondFactorIsOn("Confirm");
            clickWhenTheSecondFactorIsOn("Popup - continue");
            shouldBe("My products", "be", "visible");
        } finally {
            String ippidValue = "";
            StringBuilder stepNameTransformed = new StringBuilder("I login with ippid: ");

            if (!ippid.isEmpty()) {
                ippidValue = functions.getText(ippid);
            }

            if(Objects.equals(ippidValue, ippid)) {
                stepNameTransformed.append(ippidValue);
            } else {
                stepNameTransformed.append(ippidValue);
                stepNameTransformed.append(" defined under property: ");
                stepNameTransformed.append(ippid);
            }

            setStepNameTransformed(stepNameTransformed.toString());
        }
    }

    @And("^I close browser$")
    public void closeBrowser() {
        setStepNameTransformed("I close browser");
        functions.closeBrowser();
    }

    @And("^I set \"(.*?)\"(?: and store result)?$")
    public void setUniqueText(String text) {
        String value = functions.setText(text);
        setStepNameTransformed("I set \"" + value + "\"");
    }

    @And("^I set \"(.*?)\" date from \"(.*?)\" element(?: and store result)?$")
    public void setUniqueDateFromElement(String key, String inputName) {

        List<By> parameterList = pages.getParameterList(inputName);

        String dateRegex =
                "(0?[1-9]|[12][0-9]|3[01])\\.\\s*(0?[1-9]|1[0-2])\\.\\s*(\\d{4})" +
                        "|(\\d{4})-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])";

        String date = elementsFunctions.getRegexMatchFromElement(dateRegex, parameterList.get(0));

        setStepNameTransformed(
                "I set \"" + date + "\" date from \"" + parameterList.get(0) + "\" element");

        functions.setUniqueText(key, date);
    }

    @And("^I set \"(.*?)\" from \"(.*?)\" element(?: and store result)?$")
    public void setUniqueTextFromElement(String key, String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        String value = elementsFunctions.getTextFromElement(parameterList.get(0), 1);
        setStepNameTransformed("I set \"" + value + "\" from \"" + parameterList.get(0) + "\"");
        functions.setUniqueText(key, value);
    }

    @And("^I set payment amount \"([^\"]+)\" from \"(.*?)\" element with \"(.*?)\" text(?: and store result)?$")
    public void setPaymentAmountFromElementWithText(String key, String inputName, String text) {
        List<By> parentLocator = pages.getParameterList(inputName);
        List<By> priceLocator = pages.getParameterList("Price");
        List<String> values = new ArrayList<>();

        for (String item : text.split("\" And \"")) {
            values.add(functions.getText(item));
        }

        String amount = elementsFunctions.getTextFromChildElement(parentLocator.get(0), priceLocator.get(0), values);
        setStepNameTransformed("I set payment amount \"" + amount + "\" from \"" + parentLocator.get(0) + "\" with text \"" + text + "\"");

        functions.setUniqueText(key, amount);
    }

    @And("^I set \"(.*?)\" value from stored file$")
    public void setValueFromStoredFile(String key) {
        // implemented as event: getValueFromStoredFile(TestStepStarted event) method in PartialResultsEventHandler.java
        setStepNameTransformed("I set \"" + key + "\" from stored file - set value is: " + functions.getText(key));
    }

    @And("^Amount from \"(.*?)\" (minus|plus) \"(.*?)\" compare with \"(.*?)\"$")
    public void compareAmounts(String srcKey, String operation, String valueOrKey, String dstKey) {
        UniqueValues uniqueValues = new UniqueValues();
        double amount;
        String amountValueString;

        String resolvedValue = uniqueValues.getUniqueIdentifierValue(valueOrKey);

        if (resolvedValue != null) {
            amountValueString = resolvedValue;
        } else {
            amountValueString = valueOrKey;
        }

        try {
            String formatedValue = amountValueString
                    .replace(",", ".")
                    .replaceAll("[^\\d\\.]", "")
                    .trim();

            amount = Double.parseDouble(formatedValue);

        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("The value/key '" + valueOrKey + "' did not resolve to a valid number. " +
                    "Resolved string was: '" + amountValueString + "'", e);
        }

        String srcValue = uniqueValues.getUniqueIdentifierValue(srcKey);
        String dstValue = uniqueValues.getUniqueIdentifierValue(dstKey);

        setStepNameTransformed("Amount from \"" + srcValue + "\" " + operation + " \"" + amount + "\" compare with \"" + dstValue + "\"");
        functions.compareAmounts(srcValue, operation, amount, dstValue);
    }

    @And("^I click \"(.*?)\" when the 2FA is on$")
    public void clickWhenTheSecondFactorIsOn(String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        setStepNameTransformed("I click \"" + parameterList.get(0) + "\"; when the 2FA is on");
        elementsFunctions.clickIfElementIsDisplayed(parameterList.get(0));
    }

    @And("^I click \"([^\"]+)\"$")
    public void clickOnButton(String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        setStepNameTransformed("I click \"" + parameterList.get(0) + "\";");
        elementsFunctions.clickOnButton(parameterList.get(0), 1);
    }


    @And("^I click \"(.*?)\" in order ([0-9]+)$")
    public void clickOnButtonInOrder(String inputName, int order) {
        List<By> parameterList = pages.getParameterList(inputName);
        setStepNameTransformed("I click \"" + parameterList.get(0) + "\" in order " + order);
        elementsFunctions.clickOnButton(parameterList.get(0), order);
    }

    @And("^I click \"([^\"]+)\" and the page is loaded")
    public void clickOnButtonAndHandleLoading(String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        clickOnButton(inputName);
        functions.waitUntilPageIsLoaded();
        functions.waitUntilElementLoadersAreDone();
        setStepNameTransformed("I click \"" + parameterList.get(0) + "\" and the page is loaded");
    }

    @Then("^I click \"([^\"]+)\" with \"(.*?)\" text$")
    public void clickOnButtonWithText(String inputName, String text) {
        List<By> parameterList = pages.getParameterList(inputName);
        List<String> values = new ArrayList<>();
        for (String item : text.split("\" And \"")) {
            values.add(functions.getText(item));
        }
        String result = values.stream()
                .map(String::valueOf)
                .collect(Collectors.joining("\" And \"", "\"", "\""));
        setStepNameTransformed("I click \"" + parameterList.get(0) + "\" with " + result + " text");
        elementsFunctions.clickOnElementWithText(parameterList.get(0), values);
    }

    @And("^I click \"(.*?)\" element in \"(.*?)\" iFrame$")
    public void clickElementInIFrame(String elementIdentifier, String iFrameIdentifier) {
        List<By> elementParameterList = pages.getParameterList(elementIdentifier);
        List<By> iFrameParameterList = pages.getParameterList(iFrameIdentifier);
        setStepNameTransformed("I click \"" + elementParameterList.get(0) + "\" element in " + iFrameParameterList.get(0) + " iFrame;");
        elementsFunctions.clickOnElementInIFrame(elementParameterList.get(0), iFrameParameterList.get(0));
    }

    @When("^I type (|fast )\"(.*?)\" into \"(.*?)\"$")
    public void fillInputWithString(String fastSetValueString, String text, String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        String value = "";
        if (!text.isEmpty()) {
            value = functions.getText(text);
        }
        boolean fastSetValue = fastSetValueString.contains("fast");
        setStepNameTransformed("I type \"" + value + "\" into \"" + parameterList.get(0) + "\"");
        elementsFunctions.typeIntoInput(parameterList.get(0), 1, value, fastSetValue);
    }

    @And("^I type \"(.*?)\" into \"(.*?)\" when the 2FA is on$")
    public void fillInputWithStringWhenTheSecondFactorIsOn(String text, String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        String value = "";
        if (!text.isEmpty()) {
            value = functions.getText(text);
        }
        setStepNameTransformed("I type \"" + value + "\" into \"" + parameterList.get(0) + "; when the 2FA is on");
        elementsFunctions.typeIntoInputIfElementIsDisplayed(parameterList.get(0), 1, value);
    }

    @When("^I type (|fast )\"(.*?)\" into \"(.*?)\" in order ([0-9]+)$")
    public void fillInputWithStringInOrder(String fastSetValueString, String text, String inputName, int order) {
        List<By> parameterList = pages.getParameterList(inputName);
        String value = "";
        if (!text.isEmpty()) {
            value = functions.getText(text);
        }
        boolean fastSetValue = fastSetValueString.contains("fast");

        setStepNameTransformed("I type \"" + value + "\" into \"" + parameterList.get(0) + "\" in order " + order);
        elementsFunctions.typeIntoInput(parameterList.get(0), order, value, fastSetValue);
    }

    @And("^I type \"(.*?)\" into \"(.*?)\" in \"(.*?)\" iFrame$")
    public void fillInputInIFrameWithString(String text, String inputName, String iFrameName) {
        List<By> inputParameterList = pages.getParameterList(inputName);
        List<By> iFrameParameterList = pages.getParameterList(iFrameName);

        setStepNameTransformed("I type \"" + text + "\" into \"" + inputParameterList.get(0) + "\" in \"" + iFrameParameterList.get(0) + "\" iFrame");
        elementsFunctions.typeIntoInputInIFrame(text, inputParameterList.get(0), iFrameParameterList.get(0));
    }

    @Then("^I select \"(.*?)\" from \"(.*?)\" dropdown$")
    public void selectFromDropdown(String text, String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        List<String> values = new ArrayList<>();
        for (String item : text.split("\" And \"")) {
            values.add(functions.getText(item));
        }
        String result = values.stream()
                .map(String::valueOf)
                .collect(Collectors.joining("\" And \"", "\"", "\""));
        setStepNameTransformed("I select " + result + " from \"" + parameterList.get(0) + "\" dropdown");
        combinedElementsFunctions.selectFromDropdownByText(parameterList, values);
    }

    @Then("^I select \"(.*?)\" from \"(.*?)\" dropdown in order ([0-9]+)$")
    public void selectFromDropdownInOrder(String text, String inputName, int order) {
        List<By> parameterList = pages.getParameterList(inputName);
        List<String> values = new ArrayList<>();
        for (String item : text.split("\" And \"")) {
            values.add(functions.getText(item));
        }
        String result = values.stream()
                .map(String::valueOf)
                .collect(Collectors.joining("\" And \"", "\"", "\""));

        setStepNameTransformed("I select " + result + " from \"" + parameterList.get(0) + "\" dropdown in order " + order);
        combinedElementsFunctions.selectFromDropdownInOrderByText(parameterList, order, values);
    }

    @Then("^I select \"(.*?)\" from \"(.*?)\" multiple selection dropdown$")
    public void selectFromMultipleSelectionDropdownByText(String text, String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        List<String> values = new ArrayList<>();
        for (String item : text.split("\" And \"")) {
            values.add(functions.getText(item));
        }
        String result = values.stream()
                .map(String::valueOf)
                .collect(Collectors.joining("\" And \"", "\"", "\""));
        setStepNameTransformed("I select " + result + " from \"" + parameterList.get(0) + "\" multiple selection dropdown");
        combinedElementsFunctions.selectFromMultipleSelectionDropdownByText(parameterList, values);
    }

    @Then("^I can't select \"(.*?)\" from \"(.*?)\" dropdown$")
    public void cantSelectFromDropdown(String text, String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        List<String> values = new ArrayList<>();
        for (String item : text.split("\" And \"")) {
            values.add(functions.getText(item));
        }
        String result = values.stream()
                .map(String::valueOf)
                .collect(Collectors.joining("\" And \"", "\"", "\""));
        setStepNameTransformed("I can't select " + result + " from \"" + parameterList.get(0) + "\" dropdown");
        combinedElementsFunctions.notSelectFromDropdownByText(parameterList, values);
    }

    @Then("^I click \"([^\"]+)\" from \"(.*?)\" with \"(.*?)\" text$")
    public void doActionWithText(String action, String inputName, String text) {
        List<By> parameterList = pages.getParameterList(inputName);
        List<By> parameterListAction = pages.getParameterList(action);
        List<String> values = new ArrayList<>();
        for (String item : text.split("\" And \"")) {
            values.add(functions.getText(item));
        }
        String result = values.stream()
                .map(String::valueOf)
                .collect(Collectors.joining("\" And \"", "\"", "\""));
        setStepNameTransformed("I click \"" + parameterListAction.get(0) + "\" from \"" + parameterList.get(0) + "\" with \"" + result + " text");
        elementsFunctions.doAction(parameterListAction.get(0), parameterList.get(0), values);
    }

    @Then("^I see \"(.*?)\" in \"(.*?)\"$")
    public void seeTextInElements(String text, String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        List<String> values = new ArrayList<>();
        for (String item : text.split("\" And \"")) {
            values.add(functions.getText(item));
        }
        String result = values.stream()
                .map(String::valueOf)
                .collect(Collectors.joining("\" And \"", "\"", "\""));
        setStepNameTransformed("I see " + result + " in \"" + parameterList.get(0) + "\"");
        combinedElementsFunctions.verifyTextInElement(parameterList, values, 1);
    }

    @Then("^I see \"(.*?)\" in \"(.*?)\" dropdown$")
    public void seeTextInDropdown(String text, String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        String result = functions.getText(text);
        setStepNameTransformed("I see " + result + " in \"" + parameterList.get(0) + "\" dropdown");
        combinedElementsFunctions.verifyTextInDropdown(parameterList, result, 1);
    }

    @Then("^I see \"(.*?)\" in \"(.*?)\" dropdown in order ([0-9]+)$")
    public void seeTextInDropdown(String text, String inputName, int order) {
        List<By> parameterList = pages.getParameterList(inputName);
        String result = functions.getText(text);
        setStepNameTransformed("I see " + result + " in \"" + parameterList.get(0) + "\" dropdown in order " + order);
        combinedElementsFunctions.verifyTextInDropdown(parameterList, result, order);
    }


    @Then("^I don't see \"(.*?)\" in \"(.*?)\"$")
    public void dontSeeTextInElements(String text, String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        List<String> values = new ArrayList<>();
        for (String item : text.split("\" And \"")) {
            values.add(functions.getText(item));
        }
        String result = values.stream()
                .map(String::valueOf)
                .collect(Collectors.joining("\" And \"", "\"", "\""));
        setStepNameTransformed("I don't see " + result + " in \"" + parameterList.get(0) + "\"");
        combinedElementsFunctions.verifyRemovedTextInElement(parameterList, values, 1);
    }

    @Then("^I see \"(.*?)\" in \"(.*?)\" in order ([0-9]+)$")
    public void seeTextInElementInOrder(String text, String inputName, int order) {
        List<By> parameterList = pages.getParameterList(inputName);
        List<String> values = new ArrayList<>();
        for (String item : text.split("\" And \"")) {
            values.add(functions.getText(item));
        }
        String result = values.stream()
                .map(String::valueOf)
                .collect(Collectors.joining("\" And \"", "\"", "\""));
        setStepNameTransformed("I see " + result + " in \"" + parameterList.get(0) + "\" in order " + order);
        combinedElementsFunctions.verifyTextInElement(parameterList, values, order);
    }

    @Then("^I don't see \"(.*?)\" in \"(.*?)\" in order ([0-9]+)$")
    public void dontSeeTextInElementInOrder(String text, String inputName, int order) {
        List<By> parameterList = pages.getParameterList(inputName);
        List<String> values = new ArrayList<>();
        for (String item : text.split("\" And \"")) {
            values.add(functions.getText(item));
        }
        String result = values.stream()
                .map(String::valueOf)
                .collect(Collectors.joining("\" And \"", "\"", "\""));
        setStepNameTransformed("I don't see " + result + " in \"" + parameterList.get(0) + "\" in order " + order);
        combinedElementsFunctions.verifyRemovedTextInElement(parameterList, values, order);
    }

    @Then("^I don't see \"(.*?)\" in \"(.*?)\" list of items$")
    public void dontSeeTextInListOfElements(String text, String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        List<String> values = new ArrayList<>();
        for (String item : text.split("\" And \"")) {
            values.add(functions.getText(item));
        }
        String result = values.stream()
                .map(String::valueOf)
                .collect(Collectors.joining("\" And \"", "\"", "\""));
        setStepNameTransformed("I don't see " + result + " in \"" + parameterList.get(0) + "\" list of items");
        combinedElementsFunctions.verifyTextIsNotDisplayedInTheListOfElements(result, parameterList);
    }

    @Then("^I see \"(.*?)\" in the(| empty) list of \"(.*?)\"$")
    public void verifyLessInformationInList(String text, String type, String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        List<String> values = new ArrayList<>();
        for (String item : text.split("\" And \"")) {
            values.add(functions.getText(item));
        }
        String result = values.stream()
                .map(String::valueOf)
                .collect(Collectors.joining("\" And \"", "\"", "\""));
        setStepNameTransformed("I see " + result + " in the list of \"" + parameterList.get(0) + "\"");
        combinedElementsFunctions.verifyTextInElementsCollectionWithLessInformation(parameterList, type, values);
    }

    @And("^I see the list of \"(.*?)\" is sorted by date (ASC|DESC)$")
    public void checkSortedElementsByDate(String inputName, String order){
        List<By> parameterList = pages.getParameterList(inputName);
        setStepNameTransformed("I see the list of \"" + parameterList.get(0) +  "\" is sorted by date " + order);

        combinedElementsFunctions.verifyDatesAreSorted(parameterList.get(0), order);
    }

    @And("^I see date in the \"(.*?)\" element$")
    public void seeDateInTheElement(String inputName){
        List<By> parameterList = pages.getParameterList(inputName);
        String dateRegex ="(0?[1-9]|[12][0-9]|3[01])\\.\\s*(0?[1-9]|1[0-2])\\.\\s*(\\d{4})|(\\d{4})-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])";

        setStepNameTransformed(
                "I am checking if D.M.YYYY/DD.M.YYYY/D.MM.YYYY/DD.MM.YYYY/YYYY-MM-DD date is present in the "
                + parameterList.get(0) + " element");

        elementsFunctions.verifyRegexInElement(dateRegex, parameterList.get(0));
    }

    @Then("^I don't see \"(.*?)\" in the list of \"(.*?)\"$")
    public void iDonTSeeLessInformationInTheListOf(String text, String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        List<String> values = new ArrayList<>();
        for (String item : text.split("\" And \"")) {
            values.add(functions.getText(item));
        }
        String result = values.stream()
                .map(String::valueOf)
                .collect(Collectors.joining("\" And \"", "\"", "\""));
        setStepNameTransformed("I don't see " + result + " in the list of \"" + parameterList.get(0) + "\"");
        elementsFunctions.verifyRemovedTextInElementsCollectionWithLessInformation(parameterList.get(0), values);
    }

    @Then("^I see \"(.*?)\" in the more detailed list of \"(.*?)\"$")
    public void verifyStringInList(String text, String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        List<String> values = new ArrayList<>();
        for (String item : text.split("\" And \"")) {
            values.add(functions.getText(item));
        }
        String result = values.stream()
                .map(String::valueOf)
                .collect(Collectors.joining("\" And \"", "\"", "\""));
        setStepNameTransformed("I see " + result + " in the more detailed list of \"" + parameterList.get(0) + "\"");
        elementsFunctions.verifyTextInElementsCollection(parameterList.get(0), values);
    }

    @And("^I don't see \"(.*?)\" in the more detailed list of \"(.*?)\"$")
    public void removedElementFromList(String text, String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        List<String> values = new ArrayList<>();
        for (String item : text.split("\" And \"")) {
            values.add(functions.getText(item));
        }
        String result = values.stream()
                .map(String::valueOf)
                .collect(Collectors.joining("\" And \"", "\"", "\""));
        setStepNameTransformed("I don't see " + result + " in the more detailed list of \"" + parameterList.get(0) + "\"");
        elementsFunctions.verifyRemovedTextFromElementsCollection(parameterList.get(0), values);
    }

    @Then("^I see \"(.*?)\" text in \"(.*?)\" items in order ([0-9]+)$")
    public void seeTextInItemsInOrder(String text, String inputName, int order) {
        List<By> parameterList = pages.getParameterList(inputName);
        String textValue = functions.getText(text);

        setStepNameTransformed("I see \"" + textValue + "\" text in \"" + parameterList.get(0)+ "\" items in order " + order);

        combinedElementsFunctions.seeTextInItemsInOrder(textValue, parameterList, order);
    }

    @Then("^I see \"(.*?)\" that should (be|not be||not) \"(.*?)\"$")
    public void shouldBe(String inputName, String prefix, String condition) {
        List<By> parameterList = pages.getParameterList(inputName);
        setStepNameTransformed("I see \"" + parameterList.get(0) + "\" should " + prefix + " \"" + condition + "\"");
        elementsFunctions.should(parameterList.get(0), prefix, condition, 1);
    }

    @Then("^I see \"(.*?)\" with \"(.*?)\" text that should (be|not be||not) \"(.*?)\"$")
    public void elementWithTextShouldBe(String inputName, String text, String prefix, String condition) {
        List<By> parameterList = pages.getParameterList(inputName);
        List<String> values = new ArrayList<>();
        for (String item : text.split("\" And \"")) {
            values.add(functions.getText(item));
        }
        String result = values.stream()
                .map(String::valueOf)
                .collect(Collectors.joining("\" And \"", "\"", "\""));
        setStepNameTransformed("I see \"" + parameterList.get(0) + "\" with " + result + " text that should " + prefix + " \"" + condition + "\"");
        elementsFunctions.elementWithTextShouldBe(parameterList.get(0), prefix, condition, values);
    }

    @Then("^I (see|don't see) \"(.*?)\" element inside \"(.*?)\" element containing \"(.*?)\" text$")
    public void verifyChildElementVisibilityInsideParentElementContainingText(String condition, String elementToBeVerified, String parentElement, String textContainedInParentElement) {
        List<By> elementToBeVerifiedParameterList = pages.getParameterList(elementToBeVerified);
        List<By> parentElementParameterList = pages.getParameterList(parentElement);
        String textInParentElement = functions.getText(textContainedInParentElement);

        setStepNameTransformed("I " + condition + " \"" + elementToBeVerifiedParameterList.get(0) + "\" element inside \"" + parentElementParameterList.get(0) + "\" containing \"" + textContainedInParentElement + "\" text");
        elementsFunctions.verifyChildElementVisibilityInsideParentElementContainingText(condition, elementToBeVerifiedParameterList.get(0), parentElementParameterList.get(0), textInParentElement);
    }

    @Then("^I see any of ((?:\"[^\"]+\"(?: or )?)+) values in \"(.*?)\" element$")
    public void iSeeAnyOfDefinedValuesInElement(String values, String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        List<String> valuesList = Arrays.stream(values.split(" or "))
                .map(v -> v.replace("\"", ""))
                .toList();

        setStepNameTransformed("I see any of " + valuesList + " values in " + parameterList.get(0) + " element");
        elementsFunctions.verifyAnyOfProvidedTextsIsDisplayedInElement(valuesList, parameterList.get(0));
    }

    @And("^I (check|uncheck) \"(.*?)\"$")
    public void checkCheckButton(String check, String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        setStepNameTransformed("I " + check + " \"" + parameterList.get(0) + "\"");
        elementsFunctions.checkButton(parameterList.get(0), check);
    }

    @And("^I see that \"(.*?)\" is (check|uncheck)$")
    public void iSeeCheckedUncheckedButton(String inputName, String checked) {
        List<By> parameterList = pages.getParameterList(inputName);
        setStepNameTransformed("I " + checked + " \"" + parameterList.get(0) + "\"");
        elementsFunctions.controlCheckUncheckedRadioButton(parameterList.get(0), checked);
    }

    @And("^Wait ([0-9]+) seconds$")
    public void waitSeconds(int seconds) {
        setStepNameTransformed("Wait " + seconds + " seconds");
        functions.waitInSeconds(seconds);
    }

    @And("^I press Tab$")
    public void pressTab() {
        setStepNameTransformed("I press Tab");
        functions.pressTab();
    }

    @And("^I press Escape$")
    public void pressEsc() {
        setStepNameTransformed("I press Escape");
        functions.pressEscape();
    }

    @And("^I set slider \"(.*?)\" to ([0-9]+)$")
    public void setSliderToValue(String inputName, int value) {
        List<By> parameterList = pages.getParameterList(inputName);
        setStepNameTransformed("I set slider \"" + parameterList.get(0) + "\" to " + value);
        combinedElementsFunctions.setSliderToValue(parameterList, value);
    }

    @And("^I upload file \"(.*?)\" to \"(.*?)\" in order ([0-9]+)$")
    public void uploadFile(String fileName, String inputName, int order) {
        List<By> parameterList = pages.getParameterList(inputName);
        String filePath = functions.getText(fileName);

        setStepNameTransformed("I upload file \"" + filePath + "\" to \"" + parameterList.get(0) + "\" in order " + order);
        elementsFunctions.uploadFile(parameterList.get(0), filePath, order);
    }

    @And("^I upload file \"(.*?)\" to \"(.*?)\"$")
    public void uploadFile(String fileName, String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        String filePath = functions.getText(fileName);
        setStepNameTransformed("I upload file \"" + filePath + "\" to \"" + parameterList.get(0) + "\"");
        elementsFunctions.uploadFile(parameterList.get(0), filePath, 1);
    }

    @And("^I switch to \"(.*?)\"$")
    public void iSwitchTo(String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        setStepNameTransformed("I switch to \"" + parameterList.get(0) + "\"");
        elementsFunctions.switchTo(parameterList.get(0));
    }

    @Then("^I move ([0-9]+) account to ([0-9]+) position from \"(.*?)\" element$")
    public void swapAccount(int source, int target, String inputName) {
        List<By> parameterList = pages.getParameterList(inputName);
        setStepNameTransformed("I move " + source + " account to " + target + " position from  \"" + parameterList.get(0) + "\" element");
        combinedElementsFunctions.dragAndDrop(parameterList, source, target);
    }

    @And("^I set \"(.*?)\" from \"(.*?)\" element in ([0-9]+) order(?: and store result)?$")
    public void setUniqueTextFromElement(String key, String inputName, int order) {
        List<By> parameterList = pages.getParameterList(inputName);
        String value = elementsFunctions.getTextFromElementCollection(parameterList.get(0), order);
        setStepNameTransformed("I set \"" + value + "\" from \"" + parameterList.get(0) + "\" element in " + order + " order");
        functions.setUniqueText(key, value);
    }

    @And("^I switch to tab number ([0-9]+)$")
    public void switchToTabNumber(int tabNumber) {
        setStepNameTransformed("I switch to tab number " + tabNumber );
        functions.switchToTab(tabNumber);
    }

    @And("Find the number of elements in \"(.*?)\" and store in \"(.*?)\"$")
    public void setNumberFrom(String inputName, String number) {
        List<By> parameterList = pages.getParameterList(inputName);
        int count = combinedElementsFunctions.setNumberFromList(number, parameterList.get(0));

        setStepNameTransformed("I set \"" + count + "\" from \"" + parameterList.get(0) + "\"");
    }

    @Then("^I download \"([^\"]+)\" from \"(.*?)\" with \"(.*?)\" text$")
    public void downloadDocument(String action, String inputName, String text) throws Exception {
        List<File> before = pdfUtils.listAllFiles(new File(StepContext.getDownloadFolder()));
        doActionWithText(action, inputName, text);
        functions.waitInSeconds(15);
        File newFile = pdfUtils.getNewlyDownloadedFile(before);

        setStepNameTransformed("Downloaded new document: \"" + newFile.getName());
    }

    @And("I see \"(.*?)\" in latest downloaded document$")
    public void iSeeInLatestDownloadedDocument(String inputText) throws Exception {
        String value = "";
        if (!inputText.isEmpty()) {
            value = functions.getText(inputText);
        }

        setStepNameTransformed("I see \"" + value + "\" in the latest downloaded PDF document");

        boolean contains = pdfUtils.pdfContains(value);

        if (!contains){
            String pdfContent = pdfUtils.pdfGetText();
            throw new AssertionError("Text not found in latest PDF: " + value + "\n\n ===Content PDF===\n" + pdfContent + "\n============================");
        }
    }

    @And("^I test \"(.*?)\" is one day earlier than \"(.*?)\"$")
    public void testDateIsOneDayEarlier(String firstKey, String secondKey) {
        UniqueValues uniqueValues = new UniqueValues();

        String firstDateString = uniqueValues.getUniqueIdentifierValue(firstKey);
        String secondDateString = uniqueValues.getUniqueIdentifierValue(secondKey);

        LocalDate firstDate = elementsFunctions.parseDateString(firstDateString);
        LocalDate secondDate = elementsFunctions.parseDateString(secondDateString);

        setStepNameTransformed(
                "I test \"" + firstDateString + "\" is one day earlier than \"" + secondDateString + "\"");

        elementsFunctions.verifyDateIsOneDayEarlier(firstDate, secondDate);
    }

    @And("^I see \"(.*?)\" carousel is changing$")
    public void iSeeCarouselIsChanged(String elementName) {
        List<By> parameterList = pages.getParameterList((elementName));
        setStepNameTransformed(
                "I see \"" + parameterList + "\" is changing");
        combinedElementsFunctions.verifyCarouselIsChanging(parameterList);
    }

    @And("^I am on the same environment$")
    public void iAmOnTheSameEnvironment() {
        functions.waitUntilPageIsLoaded();

        String baseUrl = Configuration.baseUrl;
        String currentUrl = WebDriverRunner.url();

        setStepNameTransformed("Current url \"" + currentUrl + "\" is the same as expected url \"" + baseUrl );

        functions.verifyEnvironment(baseUrl, currentUrl);

    }

    @And("^I open \"(.*?)\" item from carousel$")
    public void iOpenItemFromCarousel(String carouselItemName) {
        List<By> carouselItemButtonParameterList = pages.getByObjectsForElement(DashboardPage.getCarouselButtonByItemName(carouselItemName));
        List<By> carouselRightArrowParameterList = pages.getParameterList("Carousel right");

        try {
            combinedElementsFunctions.openItemFromCarousel(carouselItemName, carouselItemButtonParameterList, carouselRightArrowParameterList);
        } finally {
            setStepNameTransformed("I open \"" + carouselItemName + "\" item from carousel");
        }
    }

    @And("Calculate \"(.*?)\" (minus|plus) \"(.*?)\" and save in \"(.*?)\"$")
    public void calculateAndStoreItIn(String valueOrKeyFirst, String operation, String valueOrKeySecond, String resultKey) {
        UniqueValues uniqueValues = new UniqueValues();

        String resolvedValueOne = uniqueValues.getUniqueIdentifierValue(valueOrKeyFirst);
        String resolvedValueTwo = uniqueValues.getUniqueIdentifierValue(valueOrKeySecond);

        String amountValueStringOne=resolvedValueOne != null ? resolvedValueOne : valueOrKeyFirst;
        String amountValueStringTwo=resolvedValueTwo != null ? resolvedValueTwo : valueOrKeySecond;

        String calculatedResult = functions.calculate(amountValueStringOne, operation, amountValueStringTwo);

        functions.setUniqueText(resultKey, calculatedResult);
        setStepNameTransformed("Calculate \"" + amountValueStringOne + "\" " + operation + " \"" + amountValueStringTwo + "\" and save in \"" + calculatedResult + "\"");

    }
}