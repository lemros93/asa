package sk.moja.steps;

import com.codeborne.selenide.AuthenticationType;
import com.codeborne.selenide.BasicAuthCredentials;
import com.codeborne.selenide.Configuration;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import org.apache.hc.core5.net.URIBuilder;
import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeOptions;
import sk.moja.enumerators.CustomProperties;
import sk.moja.enumerators.Domains;
import sk.moja.enumerators.Links;
import sk.moja.pages.Pages;
import sk.moja.pages.crm.CrmCustomerPage;
import sk.moja.pages.crm.CrmSearchPage;
import sk.moja.pages.crm.CrmServiceRequestsPage;
import sk.moja.utils.ElementsFunctions;
import sk.moja.utils.Functions;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;
import java.util.List;

import static com.codeborne.selenide.Selenide.closeWebDriver;
import static com.codeborne.selenide.Selenide.open;
import static sk.moja.utils.StepContext.setStepNameTransformed;

public class CrmSteps {
    private final Functions functions = new Functions();
    private final ElementsFunctions elementsFunctions = new ElementsFunctions();
    private Pages pages;

    @Given("^I open CRM as \"(.*?)\" user with \"(.*?)\" secret$")
    public void openCrm(String user, String secret) throws URISyntaxException {

        String runIncognito = CustomProperties.getProperty("crm_run_incognito");

        if(Objects.equals(runIncognito, "true")) {
            openCrmInIncognitoBrowserMode(user, secret);
        } else {
            openCrmInStandardBrowserMode(user, secret);
        }
    }

    private void openCrmInStandardBrowserMode(String user, String secret) throws URISyntaxException {
        pages = new Pages("CRM");

        String propertySecret = CustomProperties.getProperty(secret);
        String crmUserSecret;

        if(propertySecret != null) {
            byte[] crmUserSecretBytes = Base64.getDecoder().decode(propertySecret);
            crmUserSecret = new String(crmUserSecretBytes);
        } else {
            crmUserSecret = functions.getText(secret);
        }

        String crmUser = functions.getText(user);
        String crmUserUrlPart = crmUser + ":" + crmUserSecret;
        String crmBaseUrl = Domains.valueOf("ACC_CRM").value;
        String crmLoginPath = Links.valueOf("CRM_LOGIN").value;

        URI crmUrlWithLogin = new URIBuilder()
                .setScheme("https")
                .setUserInfo(crmUserUrlPart)
                .setHost(crmBaseUrl)
                .setPath(crmLoginPath)
                .build();

        setStepNameTransformed("I am opening crm url " + crmBaseUrl + crmLoginPath + " for user:" + crmUser);

        closeWebDriver();
        open(crmUrlWithLogin.toString());
    }

    private void openCrmInIncognitoBrowserMode(String user, String secret) {
        pages = new Pages("CRM");

        String propertySecret = CustomProperties.getProperty(secret);
        String crmUserSecret;

        if(propertySecret != null) {
            byte[] crmUserSecretBytes = Base64.getDecoder().decode(propertySecret);
            crmUserSecret = new String(crmUserSecretBytes);
        } else {
            crmUserSecret = functions.getText(secret);
        }

        String crmUser = functions.getText(user);
        String crmBaseUrl = Domains.valueOf("ACC_CRM").value;

        EdgeOptions options = new EdgeOptions();

        options.addArguments("--inprivate");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--remote-allow-origins=*");

        Map<String, Object> prefs = new HashMap<>();
        prefs.put("credentials_enable_service", false);
        prefs.put("profile.password_manager_enabled", false);
        options.setExperimentalOption("prefs", prefs);

        Configuration.browserCapabilities = options;
        Configuration.browser = "edge";
        Configuration.pageLoadStrategy="normal";
        Configuration.timeout = 15000;

        open("https://" + crmBaseUrl, AuthenticationType.BASIC, new BasicAuthCredentials(crmUser, crmUserSecret));

        setStepNameTransformed("I am opening crm url " + crmBaseUrl + " for user: " + crmUser);

        elementsFunctions.clickOnElementInIFrame(
                pages.getParameterList("CRM tab - app landing page").get(0),
                pages.getParameterList("CRM App landing page iFrame").get(0));
    }

    @When("^I open service request \"(.*)\" in CRM service request Dashboard$")
    public void openServiceRequestDetail(String serviceRequestTimeStamp) {
        List<By> parameterList = pages.getByObjectsForElement(CrmServiceRequestsPage.getServiceRequestByTheTimeStamp(functions.getText(serviceRequestTimeStamp)));
        setStepNameTransformed("I am opening service request with \"" + serviceRequestTimeStamp + "\" identifier");
        elementsFunctions.clickOnButton(parameterList.get(0), 1);
    }

    @And("^I click found user \"(.*)\" in \"(.*)\" iFrame on the CRM search page$")
    public void clickFoundUserOnTheCrmSearchPage(String foundUser, String iFrameName) {
        List<By> foundUserParameterList = pages.getByObjectsForElement(CrmSearchPage.getFoundLinkBasedOnTheCrmUserName(functions.getText(foundUser)));
        List<By> iFrameParameterList = pages.getParameterList(iFrameName);
        setStepNameTransformed("I am clicking on the link of found user: \""  + foundUserParameterList.get(0) + "\" in \"" + iFrameParameterList.get(0)+ "\" on the CRM search page");
        elementsFunctions.clickOnElementInIFrame(foundUserParameterList.get(0), iFrameParameterList.get(0));
    }

    @And("^I click found user \"(.*)\" with \"(.*)\" address in \"(.*)\" iFrame on the CRM search page$")
    public void clickFoundUserOnTheCrmSearchPage(String foundUser, String address, String iFrameName) {
        List<By> foundUserParameterList = pages.getByObjectsForElement(CrmSearchPage.getFoundLinkBasedOnTheCrmUserNameAndAddress(functions.getText(foundUser), functions.getText(address)));
        List<By> iFrameParameterList = pages.getParameterList(iFrameName);
        setStepNameTransformed("I am clicking on the link \""  + foundUserParameterList.get(0) + "\" of found user: \""  + foundUser + "\" with \"" + address + "\" address in \"" + iFrameParameterList.get(0)+ "\" on the CRM search page");
        elementsFunctions.clickOnElementInIFrame(foundUserParameterList.get(0), iFrameParameterList.get(0));
    }

    @And("^I click ([0-9]+). service request named \"(.*)\" on CRM user detail page$")
    public void clickNthServiceRequestWithNameOnUserDetailPage (int order, String serviceRequestName){
        List<By> serviceRequestElementParemeterList = pages.getByObjectsForElement(CrmCustomerPage.getNthServiceRequestWithName(order, serviceRequestName));
        setStepNameTransformed("I am clicking on the " + order + ". service request: \""  + serviceRequestElementParemeterList.get(0) + "\" on the CRM customer page");
        elementsFunctions.clickOnButton(serviceRequestElementParemeterList.get(0), 1);
    }

    @And("^I see \"(ID|Passport|Residence permit)\" document in the Client's request entering section on the Service Request Detail CRM page$")
    public void seePassportInClientsRequestEnteringOnTheServiceRequestDetailPage(String documentType) {
        List<By> clientsRequestServiceDetailParameterList = pages.getParameterList("Service Request Detail - Client's request entering");
        String documentRegex;

        if (documentType.equals("ID")) {
            documentRegex = "ID\\s+Predná\\s+strana:\\s*\\{([0-9A-Fa-f\\-]+)}\\s+Zadná\\s+strana:\\s*\\{([0-9A-Fa-f\\-]+)}";
        } else if(documentType.equals("Passport")){
            documentRegex = "PAS\\s+Predná\\s+strana:\\s*\\{([0-9A-Fa-f\\-]+)}";
        } else {
            documentRegex = "Povolenie\\s+na\\s+pobyt\\s+1\\. strana:\\s*\\{([0-9A-Fa-f\\-]+)}\\s+2\\. strana:\\s*\\{([0-9A-Fa-f\\-]+)}";
        }

        setStepNameTransformed("I am checking if " + documentType + "  document is present in the Client's request entering section on the Service Request Detail CRM page");

        elementsFunctions.verifyRegexInElement(documentRegex, clientsRequestServiceDetailParameterList.get(0));
    }
}