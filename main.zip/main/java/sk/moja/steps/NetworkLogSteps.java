package sk.moja.steps;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;
import io.cucumber.java.en.Given;
import sk.moja.customInvestigationTools.network.NetworkLog;
import sk.moja.customInvestigationTools.network.NetworkMonitor;

import java.util.List;

public class NetworkLogSteps {

    private final NetworkMonitor networkMonitor = new NetworkMonitor();

    @Given("^Open \"(.*?)\" url and monitor network traffic$")
    public void openUrlAndCaptureNetworkTraffic(String url) {
        Configuration.baseUrl = "";
        networkMonitor.startMonitoring();
        Selenide.open(url);
        List<NetworkLog> logs = networkMonitor.getLogs();
        logs.forEach(System.out::println);
        networkMonitor.stopMonitoring();
    }
}