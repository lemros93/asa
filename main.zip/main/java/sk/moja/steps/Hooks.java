package sk.moja.steps;

import io.cucumber.java.BeforeStep;
import io.cucumber.java.Scenario;
import sk.moja.partialResults.ErrorContext;
import sk.moja.utils.StepContext;

import java.util.List;

public class Hooks {

    @BeforeStep
    public void beforeStep(Scenario scenario) {
        String scenarioId = scenario.getId();
        List<AssertionError> errors = ErrorContext.getScenarioLevelErrors(scenarioId);

        if (!errors.isEmpty()) {
            AssertionError assertionError = new AssertionError("Collected assertion failure(s): " + errors.size());
            errors.forEach(assertionError::addSuppressed);
            ErrorContext.clearScenarioLevelErrors(scenarioId);
            throw assertionError;
        }

        StepContext.clear();
    }
}