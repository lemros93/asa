package sk.moja.steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import sk.moja.enumerators.Links;
import sk.moja.pages.Pages;
import sk.moja.utils.ElementsFunctions;
import sk.moja.utils.Functions;
import sk.moja.utils.TransparentAccountsUtils;

import java.util.List;

import static com.codeborne.selenide.Selenide.open;
import static sk.moja.utils.StepContext.setStepNameTransformed;

public class TransparentAccountsSteps {

    private final Functions functions = new Functions();
    private final ElementsFunctions elementsFunctions = new ElementsFunctions();
    private final Pages transparentAccountsPage = new Pages("Transparent accounts");
    private final TransparentAccountsUtils transparentAccountsUtils = new TransparentAccountsUtils();

    @Given("^I open transparent account with id \"(.*?)\"$")
    public void openTransparentAccountWithId(String transparentAccountId) {

        String transparentAccountIdValue = functions.getText(transparentAccountId);

        functions.waitUntilPageIsLoaded();
        open(Links.valueOf("TRANSPARENT_ACCOUNTS").value + transparentAccountIdValue);
    }

    @When("^I set empty dates in transparent accounts filter$")
    public void setEmptyDatesInTransparentAccountsFilter() {
        List<By> dateFromByObjects = transparentAccountsPage.getParameterList("TA detail - transactions - date from");
        List<By> dateToByObjects = transparentAccountsPage.getParameterList("TA detail - transactions - date to");

        setStepNameTransformed("I set empty dates in transparent accounts filter");
        elementsFunctions.typeIntoInput(dateFromByObjects.get(0), 1, "", true);
        elementsFunctions.typeIntoInput(dateToByObjects.get(0), 1, "", true);
    }

    @Then("^I check that displayed transactions are from the last 3 months and they are (positive|negative|both positive and negative)(| and I collect data for later recheck in Moja)$")
    public void checkThatDisplayedTransactionsAreFromTheLastThreeMonthsAndTheyArePositiveOrNegative(String transactionType, String laterRecheck) {
        setStepNameTransformed("I check that displayed transactions are from the last 3 months and they are " + transactionType);
        transparentAccountsUtils.checkThatDisplayedTransactionsAreFromTheLastThreeMonthsAndTheyArePositiveOrNegative(transactionType);
        if(!laterRecheck.isEmpty()) {
            transparentAccountsUtils.setTransactionsDataStoredForLaterCheckInMoja();
        }
    }

    @When("^I set dates period for last 3 years in transparent accounts filter$")
    public void setDatesForLastThreeYearsInTransparentAccountsFilter() {
        setStepNameTransformed("I set dates period for last 3 years in transparent accounts filter");
        transparentAccountsUtils.setDatesForLastThreeYearsInTransparentAccountsFilter();
    }

    @Then("^I check that displayed transactions are from the last 3 years and they are (positive|negative|both positive and negative)$")
    public void checkThatDisplayedTransactionsAreFromTheLastThreeYearsAndTheyArePositiveOrNegative(String transactionType) {
        setStepNameTransformed("I check that displayed transactions are from the last 3 years and they are " + transactionType);
        transparentAccountsUtils.checkThatDisplayedTransactionsAreFromTheLastThreeYearsAndTheyArePositiveOrNegative(transactionType);
    }

    @When("^I set dates period longer than 3 years ago in transparent accounts filter$")
    public void setDatesPeriodLongerThanThreeYearsAgoInTransparentAccountsFilter() {
        setStepNameTransformed("I set dates period longer than 3 years ago in transparent accounts filter");
        transparentAccountsUtils.setDatesPeriodLongerThanThreeYearsAgoInTransparentAccountsFilter();
    }

    @When("^I set higher date from than date to in transparent accounts filter$")
    public void setHigherDateFromThanDateToInTransparentAccountsFilter() {
        setStepNameTransformed("I set higher date from than date to in transparent accounts filter");
        transparentAccountsUtils.setHigherDateFromThanDateToInTransparentAccountsFilter();
    }

    @When("^I set weekend dates in transparent accounts filter and I see (positive|negative|both positive and negative) transactions limited by set dates$")
    public void setWeekendDatesInTransparentAccountsFilterAndCheckTransactions(String transactionType) {
        setStepNameTransformed("I set weekend dates in transparent accounts filter and I see " + transactionType + " transactions limited by set dates");
        transparentAccountsUtils.setWeekendDatesInTransparentAccountsFilterAndCheckTransactions(transactionType);
    }

    @When("^I set public holiday dates in transparent accounts filter and I see (positive|negative|both positive and negative) transactions limited by set dates$")
    public void setPublicHolidayDatesInTransparentAccountsFilterAndCheckTransactions(String transactionType) {
        setStepNameTransformed("I set public holiday dates in transparent accounts filter and I see " + transactionType + " transactions limited by set dates");
        transparentAccountsUtils.setPublicHolidayDatesInTransparentAccountsFilterAndCheckTransactions(transactionType);
    }

    @Then("^I collect displayed transactions on Moja account detail and check them with stored transactions$")
    public void collectDisplayedTransactionsOnMojaAccountDetailAndCheckThemWithStoredTransactions() {
        setStepNameTransformed("I collect displayed transactions on Moja account detail and chek them with stored transactions");
        transparentAccountsUtils.collectDisplayedTransactionsOnMojaAccountDetailAndCheckThemWithStoredTransactions();
    }
}