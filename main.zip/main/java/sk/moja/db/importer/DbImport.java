package sk.moja.db.importer;

import com.codeborne.selenide.Configuration;
import sk.moja.db.importer.config.ImportConfig;
import sk.moja.db.importer.db.DatabaseWriter;
import sk.moja.db.importer.model.TestRun;
import sk.moja.db.importer.parser.NdjsonParser;
import sk.moja.db.importer.parser.StepExtraParser;
import sk.moja.db.importer.model.StepExtra;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sk.moja.enumerators.CustomProperties;

import java.util.Map;

public class DbImport {

    private static final Logger log = LoggerFactory.getLogger(DbImport.class);

    public static void dbImport() {
        log.info("=== Cucumber NDJSON Importer ===");

        /*if (System.getProperty("triggerReason").contains("Manual")) {
            System.setProperty("trigger.type", "Manual");
            System.setProperty("triggered.by", System.getProperty("triggerUserName"));
        } else if (System.getProperty("triggerReason").contains("Scheduled")) {
            System.setProperty("trigger.type", "Scheduled");
            System.setProperty("triggered.by", null);
        } else {
            System.setProperty("trigger.type", System.getProperty("triggerReason"));
            System.setProperty("triggered.by", null);
        }*/

        System.setProperty("project", "mojacsob");
        System.setProperty("branch", "develop");
        System.setProperty("build.number", "");
        //System.setProperty("build.number", CustomProperties.getBuildPlan());
        //System.setProperty("browser.version", Configuration.browserBinary);
        System.setProperty("browser.version", "edge");
        System.setProperty("db.url", "jdbc:mysql://localhost:3306/automation");
        System.setProperty("db.user", "marek");
        System.setProperty("db.password", "password");
        ImportConfig config;
        try {
            config = ImportConfig.fromSystemProperties();
        } catch (IllegalArgumentException e) {
            log.error("Configuration error: {}", e.getMessage());
            log.error("Required properties: -Dndjson=... -Ddb.url=... -Ddb.user=... -Ddb.password=...");
            System.exit(1);
            return;
        }

        log.info("Project:      {}", config.project);
        log.info("Environment:  {}", config.environment);
        log.info("Branch:       {}", config.branch);
        log.info("Build:        {}", config.buildNumber);
        log.info("Triggered by: {} ({})", config.triggeredBy, config.triggerType);
        log.info("Browser:      {} {}", config.browser, config.browserVersion);
        log.info("NDJSON file:  {}", config.ndjsonPath);

        NdjsonParser parser = new NdjsonParser();
        StepExtraParser extraParser = new StepExtraParser();
        DatabaseWriter writer = null;

        try {
            Map<String, StepExtra> stepExtras = extraParser.parse(config.stepsExtraPath);
            TestRun run = parser.parse(config.ndjsonPath, stepExtras);
            writer = new DatabaseWriter(config);
            writer.save(run, config);
            log.info("=== Import completed successfully ===");

        } catch (Exception e) {
            log.error("Import failed: {}", e.getMessage(), e);
            System.exit(2);

        } finally {
            if (writer != null) writer.close();
        }
    }
    public static void main(String[] args) {
        dbImport();
    }

}
