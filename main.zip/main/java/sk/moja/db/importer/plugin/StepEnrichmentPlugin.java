package sk.moja.db.importer.plugin;

import com.fasterxml.jackson.databind.ObjectMapper;
import sk.moja.db.importer.model.StepExtra;
import sk.moja.utils.StepContext;
import io.cucumber.plugin.event.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.Objects;

import static sk.moja.enumerators.Constants.*;
import static sk.moja.enumerators.CustomProperties.getDestination;
import static sk.moja.logger.JiraReporter.getScreenshotServerUrlFromScreenshotPath;
import static sk.moja.utils.StepContext.*;

public class StepEnrichmentPlugin {

    private static final Logger log = LoggerFactory.getLogger(StepEnrichmentPlugin.class);

    private final ObjectMapper mapper = new ObjectMapper();
    private final Path outputPath;

    public StepEnrichmentPlugin() {
        this.outputPath = Path.of(getDestination() + "/temp/reports/cucumber-report/cucumberextra.ndjson");
        initOutputFile();
    }

    public void onTestStepFinished(TestStepFinished event) {

        if (event.getResult().getStatus().is(Status.SKIPPED)) {
            return;
        }

        if (event.getTestStep() instanceof PickleStepTestStep step) {
            StepContext.setCurrentStepId(step.getId().toString());
        }

        if (event.getTestStep() instanceof HookTestStep hookStep) {
            if (hookStep.getHookType().equals(HookType.AFTER_STEP)) {
                StepExtra extra = new StepExtra();
                extra.testStepId = getCurrentStepId();
                extra.translatedText = getStepNameTransformed();
                if (Objects.equals(getScreenshotPath(), "") || getScreenshotPath() == null || Objects.equals(getScreenshotPath(), "null")) {
                    extra.screenshotUrl = null;
                } else {
                    extra.screenshotUrl = getScreenshotServerUrlFromScreenshotPath(getScreenshotPath() + ".png");
                }
                if (Objects.equals(getFailedScreenshotPath(), "") || getFailedScreenshotPath() == null || Objects.equals(getFailedScreenshotPath(), "null")) {
                    extra.failedScreenshotUrl = null;
                } else {
                    extra.failedScreenshotUrl = getScreenshotServerUrlFromScreenshotPath(getFailedScreenshotPath() + ".png");
                }

                writeLine(extra);
            }
        }
    }

    private void initOutputFile() {
        try {
            Path parent = outputPath.getParent();
            if (parent != null) Files.createDirectories(parent);
            Files.write(outputPath, new byte[0],
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            log.error("StepEnrichmentPlugin: cannot create output file: {}", outputPath, e);
        }
    }

    private synchronized void writeLine(StepExtra extra) {
        try (BufferedWriter writer = Files.newBufferedWriter(
                outputPath, StandardCharsets.UTF_8, StandardOpenOption.APPEND)) {
            writer.write(mapper.writeValueAsString(extra));
            writer.newLine();
        } catch (IOException e) {
            log.error("StepEnrichmentPlugin: failed to write record for testStepId={}", extra.testStepId, e);
        }
    }
}
