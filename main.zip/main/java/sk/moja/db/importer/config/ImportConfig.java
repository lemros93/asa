package sk.moja.db.importer.config;

import static sk.moja.enumerators.Constants.DESTINATION;
import static sk.moja.enumerators.Constants.LOCAL_DESTINATION;
import static sk.moja.enumerators.CustomProperties.getDestination;

public class ImportConfig {

    public final String ndjsonPath;
    public final String stepsExtraPath;
    public final String dbUrl;
    public final String dbUser;
    public final String dbPassword;

    public final String project;
    public final String environment;
    public final String branch;
    public final String commitHash;
    public final String commitMessage;
    public final String buildNumber;
    public final String triggeredBy;
    public final String triggerType;

    public final String browser;
    public final String browserVersion;
    public final String appUrl;

    private ImportConfig(Builder b) {
        this.ndjsonPath = b.ndjsonPath;
        this.stepsExtraPath = b.stepsExtraPath;
        this.dbUrl = b.dbUrl;
        this.dbUser = b.dbUser;
        this.dbPassword = b.dbPassword;
        this.project = b.project;
        this.environment = b.environment;
        this.branch = b.branch;
        this.commitHash = b.commitHash;
        this.commitMessage = b.commitMessage;
        this.buildNumber = b.buildNumber;
        this.triggeredBy = b.triggeredBy;
        this.triggerType = b.triggerType;
        this.browser = b.browser;
        this.browserVersion = b.browserVersion;
        this.appUrl = b.appUrl;
    }

    public static ImportConfig fromSystemProperties() {
        return new Builder()
                .ndjsonPath(prop("ndjson",  LOCAL_DESTINATION + DESTINATION + "/temp/reports/cucumber-report/cucumber-messages.ndjson"))
                .stepsExtraPath(prop("steps.extra",  LOCAL_DESTINATION + DESTINATION + "/temp/reports/cucumber-report/cucumberextra.ndjson"))
                .dbUrl(require("db.url"))
                .dbUser(require("db.user"))
                .dbPassword(require("db.password"))
                .project(prop("project", "web-project"))
                .environment(prop("env", "unknown"))
                .branch(prop("branch", "unknown"))
                .commitHash(prop("commit.hash", "unknown"))
                .commitMessage(prop("commit.message", ""))
                .buildNumber(prop("build.number", "unknown"))
                .triggeredBy(prop("triggered.by", "unknown"))
                .triggerType(prop("trigger.type", "manual"))
                .browser(prop("browser", "unknown"))
                .browserVersion(prop("browser.version", "unknown"))
                .appUrl(prop("app.url", ""))

                .build();
    }

    private static String require(String key) {
        String val = System.getProperty(key);
        if (val == null || val.isBlank())
            throw new IllegalArgumentException("Required system property missing: -D" + key);
        return val;
    }

    private static String prop(String key, String defaultValue) {
        String val = System.getProperty(key);
        return (val != null && !val.isBlank()) ? val : defaultValue;
    }

    public static class Builder {
        private String ndjsonPath, stepsExtraPath, dbUrl, dbUser, dbPassword;
        private String project, environment, branch, commitHash, commitMessage, buildNumber;
        private String triggeredBy, triggerType;
        private String browser, browserVersion, appUrl;

        public Builder ndjsonPath(String ndjsonPath) {
            this.ndjsonPath = ndjsonPath;
            return this;
        }

        public Builder stepsExtraPath(String stepsExtraPath) {
            this.stepsExtraPath = stepsExtraPath;
            return this;
        }

        public Builder dbUrl(String dbUrl) {
            this.dbUrl = dbUrl;
            return this;
        }

        public Builder dbUser(String dbUser) {
            this.dbUser = dbUser;
            return this;
        }

        public Builder dbPassword(String dbPassword) {
            this.dbPassword = dbPassword;
            return this;
        }

        public Builder project(String project) {
            this.project = project;
            return this;
        }

        public Builder environment(String environment) {
            this.environment = environment;
            return this;
        }

        public Builder branch(String branch) {
            this.branch = branch;
            return this;
        }

        public Builder commitHash(String commitHash) {
            this.commitHash = commitHash;
            return this;
        }

        public Builder commitMessage(String commitHash) {
            this.commitMessage = commitHash;
            return this;
        }

        public Builder buildNumber(String buildNumber) {
            this.buildNumber = buildNumber;
            return this;
        }

        public Builder triggeredBy(String triggeredBy) {
            this.triggeredBy = triggeredBy;
            return this;
        }

        public Builder triggerType(String triggerType) {
            this.triggerType = triggerType;
            return this;
        }

        public Builder browser(String browser) {
            this.browser = browser;
            return this;
        }

        public Builder browserVersion(String browserVersion) {
            this.browserVersion = browserVersion;
            return this;
        }

        public Builder appUrl(String appUrl) {
            this.appUrl = appUrl;
            return this;
        }

        public ImportConfig build() {
            return new ImportConfig(this);
        }
    }
}
