package sk.moja.db.importer.model;

import java.util.ArrayList;
import java.util.List;

public class Scenario {
    public String name;
    public String status;
    public int line;
    public String tags;
    public long durationMs;
    public List<Step> steps = new ArrayList<>();

    public String hookErrorMessage;
    public String hookErrorType;

    public int totalSteps, passedSteps, failedSteps, skippedSteps;

    public void computeStepAggregations() {
        totalSteps = steps.size();
        passedSteps = 0;
        failedSteps = 0;
        skippedSteps = 0;
        boolean anyFailed = false;

        for (Step s : steps) {
            durationMs += s.durationMs;
            switch (s.status) {
                case "passed" -> passedSteps++;
                case "failed" -> {
                    failedSteps++;
                    anyFailed = true;
                }
                case "skipped" -> skippedSteps++;
            }
        }

        if (hookErrorMessage != null) {
            status = "failed";
        } else {
            status = anyFailed ? "failed" : (skippedSteps > 0 && passedSteps == 0) ? "skipped" : "passed";
        }
    }

    public boolean isFailed() {
        return "failed".equals(status);
    }
}
