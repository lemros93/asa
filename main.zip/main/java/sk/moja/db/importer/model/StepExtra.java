package sk.moja.db.importer.model;

public class StepExtra {
    public String testStepId;
    public String translatedText;
    public String screenshotUrl;
    public String failedScreenshotUrl;
}
