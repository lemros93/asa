package sk.moja.db.importer.model;

public class Step {
    public String testStepId;
    public String keyword;
    public String name;
    public String translatedText;
    public int line;
    public String status;
    public long durationMs;
    public String errorMessage;
    public String stackTrace;
    public String screenshotUrl;
    public String failedScreenshotUrl;
}
