-- Cucumber Test Results Database
-- Web project schema

CREATE TABLE IF NOT EXISTS runs (
                                    id                  INT AUTO_INCREMENT PRIMARY KEY,
                                    project             VARCHAR(100)    NOT NULL,
    project_type        VARCHAR(10)     NOT NULL DEFAULT 'web',
    run_at              DATETIME        NOT NULL,
    duration_ms         BIGINT,
    triggered_by        VARCHAR(100),
    trigger_type        VARCHAR(20),                    -- manual / scheduled / adhoc
    branch              VARCHAR(100),
    environment         VARCHAR(50),
    build_number        VARCHAR(50),

    -- aggregations (computed during import)
    total_features      INT             DEFAULT 0,
    passed_features     INT             DEFAULT 0,
    failed_features     INT             DEFAULT 0,
    total_scenarios     INT             DEFAULT 0,
    passed_scenarios    INT             DEFAULT 0,
    failed_scenarios    INT             DEFAULT 0,
    total_steps         INT             DEFAULT 0,
    passed_steps        INT             DEFAULT 0,
    failed_steps        INT             DEFAULT 0,
    skipped_steps       INT             DEFAULT 0,

    created_at          DATETIME        DEFAULT CURRENT_TIMESTAMP
    );

CREATE TABLE IF NOT EXISTS run_metadata (
                                            id          INT AUTO_INCREMENT PRIMARY KEY,
                                            run_id      INT             NOT NULL,
                                            meta_key    VARCHAR(100)    NOT NULL,
    meta_value  VARCHAR(500),
    FOREIGN KEY (run_id) REFERENCES runs(id) ON DELETE CASCADE
    );

CREATE TABLE IF NOT EXISTS features (
                                        id                  INT AUTO_INCREMENT PRIMARY KEY,
                                        run_id              INT             NOT NULL,
                                        name                VARCHAR(255)    NOT NULL,
    file_path           VARCHAR(500),
    status              VARCHAR(10)     NOT NULL,       -- passed / failed / skipped
    duration_ms         BIGINT,

    total_scenarios     INT             DEFAULT 0,
    passed_scenarios    INT             DEFAULT 0,
    failed_scenarios    INT             DEFAULT 0,

    FOREIGN KEY (run_id) REFERENCES runs(id) ON DELETE CASCADE
    );

CREATE TABLE IF NOT EXISTS scenarios (
                                         id              INT AUTO_INCREMENT PRIMARY KEY,
                                         feature_id      INT             NOT NULL,
                                         name            VARCHAR(255)    NOT NULL,
    status          VARCHAR(10)     NOT NULL,
    line            INT,
    duration_ms     BIGINT,
    hook_error_type     VARCHAR(10),
    hook_error_message  TEXT,

    total_steps     INT             DEFAULT 0,
    passed_steps    INT             DEFAULT 0,
    failed_steps    INT             DEFAULT 0,
    skipped_steps   INT             DEFAULT 0,

    FOREIGN KEY (feature_id) REFERENCES features(id) ON DELETE CASCADE
    );

-- steps only for failed scenarios
CREATE TABLE IF NOT EXISTS steps (
                                     id                    INT AUTO_INCREMENT PRIMARY KEY,
                                     scenario_id           INT             NOT NULL,
                                     keyword               VARCHAR(20),
    name                  VARCHAR(500)    NOT NULL,
    translated_text       VARCHAR(500),
    line                  INT             NOT NULL,
    status                VARCHAR(10)     NOT NULL,
    duration_ms           BIGINT,
    error_message         TEXT,
    stack_trace           TEXT,
    screenshot_url        VARCHAR(1000),
    failed_screenshot_url VARCHAR(1000),

    FOREIGN KEY (scenario_id) REFERENCES scenarios(id) ON DELETE CASCADE
    );

-- indexes for dashboard queries
CREATE INDEX idx_runs_project     ON runs(project);
CREATE INDEX idx_runs_run_at      ON runs(run_at);
CREATE INDEX idx_features_run_id  ON features(run_id);
CREATE INDEX idx_features_status  ON features(status);
CREATE INDEX idx_scenarios_feature_id ON scenarios(feature_id);
CREATE INDEX idx_scenarios_status     ON scenarios(status);
CREATE INDEX idx_steps_scenario_id    ON steps(scenario_id);
