package sk.moja.logger;

import com.kbc.qframe.jira.JiraAPIClient;
import com.kbc.qframe.jira.pojo.response.response.TestCycleEntity;
import com.kbc.qframe.jira.pojo.result.JiraScriptResultPOJO;
import com.kbc.qframe.jira.pojo.result.JiraStepStatusPOJO;
import com.kbc.qframe.jira.pojo.result.JiraTestResultPOJO;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.lang.reflect.Method;
import java.util.*;

public class JiraReportAPIClient extends JiraAPIClient {

    public JiraReportAPIClient() {
        super(
            System.getenv("JIRA_MACHINE_USER_PATID"),
            System.getenv("JIRA_MACHINE_USER_CREDENTIALS_USR"),
            Base64.getEncoder().encodeToString(System.getenv("JIRA_MACHINE_USER_CREDENTIALS_PSW").getBytes()));
    }

    public List<String> getListOfTestCasesOfTestCycle(String testCycleKey) {
        List<TestCycleEntity> testResults = getJiraTestResultsByTestCycleKey(testCycleKey);
        List<String> testCaseKeys = new ArrayList<>();

        for (TestCycleEntity testResult : testResults) {
            if(!testCaseKeys.contains(testResult.getTestCaseKey())){
                testCaseKeys.add(testResult.getTestCaseKey());
            }
        }

        return testCaseKeys;
    }

    public void createNewTestExecutionForAllTestCasesOfTestCycle(String testCycleKey) {
        List<String> testCaseKeys = getListOfTestCasesOfTestCycle(testCycleKey);

        for (String testCaseKey : testCaseKeys) {
            createNewTestExecution(testCycleKey, testCaseKey);
            updateTestCaseStatusAndExecutedBy(testCycleKey, testCaseKey, JiraStepStatusPOJO.NOT_EXECUTED, null);
        }

        System.out.println("New test execution created for test cycle: " + testCycleKey + " and for test test cases: " + testCaseKeys );
    }

    public void updateTestCaseStatusAndExecutedBy(String testCycleKey, String testCaseKey, JiraStepStatusPOJO status, String executedByUser) {
        try {

            // --- Build TestResult payload: status + executedBy + executedOn ---
            JiraTestResultPOJO.JiraTestResultBuilder builder = new JiraTestResultPOJO.JiraTestResultBuilder();
            builder
                .setStatus(status)
                .setExecutedBy(executedByUser);

            Object payloadObj = builder.build();

            // --- get URL ---
            Method urlMethod = JiraAPIClient.class.getDeclaredMethod(
                "getTestCaseTestResultUrl",
                String.class,
                String.class
            );
            urlMethod.setAccessible(true);
            String url = (String) urlMethod.invoke(this, testCycleKey, testCaseKey);

            // --- get WebResource ---
            Method resourceMethod = JiraAPIClient.class.getDeclaredMethod(
                "getApiResource",
                String.class
            );
            resourceMethod.setAccessible(true);
            Object webResource = resourceMethod.invoke(this, url);

            // --- JSON payload ---
            Method jsonMethod = JiraAPIClient.class.getDeclaredMethod(
                "toJsonString",
                Object.class,
                boolean.class
            );
            jsonMethod.setAccessible(true);
            String jsonPayload = (String) jsonMethod.invoke(this, payloadObj, true);

            // --- find private sendPutRequest(...) by name only ---
            Method putMethod = null;
            for (Method m : JiraAPIClient.class.getDeclaredMethods()) {
                if (m.getName().equals("sendPutRequest")) {
                    putMethod = m;
                    break;
                }
            }
            if (putMethod == null) {
                throw new RuntimeException("sendPutRequest not found");
            }
            putMethod.setAccessible(true);

            // --- execute PUT ---
            Object responseObj = putMethod.invoke(this, webResource, jsonPayload);

            // --- read response ---
            Method getEntityMethod = responseObj.getClass().getMethod("getEntity", Class.class);
            String responseMessage = (String) getEntityMethod.invoke(responseObj, String.class);

            // --- extract status code ---
            Method getStatusMethod = responseObj.getClass().getMethod("getStatus");
            int statusCode = (int) getStatusMethod.invoke(responseObj);

            // --- verify ---
            Method verifyMethod = null;
            for (Method m : JiraAPIClient.class.getDeclaredMethods()) {
                if (m.getName().equals("verifyResponseStatus")) {
                    verifyMethod = m;
                    break;
                }
            }
            verifyMethod.setAccessible(true);
            verifyMethod.invoke(this, statusCode, 200, responseMessage);

            System.out.println(
                "Status of test case " + testCaseKey +
                " in test cycle " + testCycleKey +
                " updated to status: " + status +
                " and executedBy set to: " + executedByUser
             );

        } catch (Exception e) {
            System.out.println("Exception caught: " + e + Arrays.toString(e.getStackTrace()));
        }
    }

    public void updateTestCaseStep(String testCycleKey, String testCaseKey, int stepIndex, JiraStepStatusPOJO jiraStepStatus, String comment) {
        JiraScriptResultPOJO scriptResult = new JiraScriptResultPOJO(stepIndex, jiraStepStatus, comment);
        reportStepToTestRun(testCycleKey, testCaseKey, scriptResult, null);
    }

    public void propagateFileToFirstStepOfLatestTestCase(String testCycleKey, String testCaseKey, String pathToFile) {
        File file = new File(pathToFile);
        if (!file.exists()) {
            System.err.println("[JiraReport] SKIPPED: Attachment file missing at path: " + pathToFile);
            return;
        }

        try {
            String testRunTestResultsUrl = getTestRunTestResultsUrl(testCycleKey);

            Method getResourceMethod = JiraAPIClient.class.getDeclaredMethod("getApiResource", String.class);
            getResourceMethod.setAccessible(true);
            WebResource resource = (WebResource) getResourceMethod.invoke(null, testRunTestResultsUrl);

            Method getRequestMethod = JiraAPIClient.class.getDeclaredMethod("sendGetRequest", WebResource.class);
            getRequestMethod.setAccessible(true);
            ClientResponse response = (ClientResponse) getRequestMethod.invoke(this, resource);

            if (response == null || response.getStatus() != 200) {
                System.err.println("[JiraReport] FAILED: API returned " + (response != null ? response.getStatus() : "null"));
                return;
            }

            String responseBody = response.getEntity(String.class);
            JSONArray results = new JSONArray(responseBody);
            Integer latestExecutionId = null;

            for (int i = results.length() - 1; i >= 0; i--) {
                JSONObject execution = results.getJSONObject(i);
                if (execution.has("testCaseKey") && execution.getString("testCaseKey").equals(testCaseKey)) {
                    latestExecutionId = execution.getInt("id");
                    break;
                }
            }

            if (latestExecutionId != null) {
                attachFileToTestResult(latestExecutionId, 0, file);
                System.out.println("[JiraReport] SUCCESS: Attached to Step 1 of execution [" + latestExecutionId + "]");
            } else {
                System.err.println("[JiraReport] SKIPPED: No execution found for [" + testCaseKey + "]");
            }

        } catch (Exception e) {
            System.err.println("[JiraReport] ERROR in child class propagation: " + e.getMessage());
            e.printStackTrace();
        }
    }
}