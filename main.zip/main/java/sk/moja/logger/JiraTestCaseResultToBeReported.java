package sk.moja.logger;

import com.kbc.qframe.jira.pojo.result.JiraStepStatusPOJO;
import lombok.Getter;
import lombok.Setter;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Setter
@Getter
public class JiraTestCaseResultToBeReported {

    private String testCaseKey;
    private String scenarioRowValue;
    private JiraStepStatusPOJO testCaseStatus;
    private String currentStep;
    private List<String> stepsPerformedBeforeFailedStep;
    private Map<String, String> parametersValues;
    private Throwable error;
    private StackTraceElement[] stacktrace;
    private String screenshotPath;
    private String screenshotUrl;

    public JiraTestCaseResultToBeReported(String testCaseKey, String scenarioRowValue , JiraStepStatusPOJO testCaseStatus, String currentStep, List<String> stepsPerformedBeforeFailedStep, Map<String, String> parametersValues, Throwable error, StackTraceElement[] stacktrace, String screenshotPath, String screenshotUrl) {
        this.testCaseKey = testCaseKey;
        this.scenarioRowValue = scenarioRowValue;
        this.testCaseStatus = testCaseStatus;
        this.currentStep = currentStep;
        this.stepsPerformedBeforeFailedStep = stepsPerformedBeforeFailedStep;
        this.parametersValues = parametersValues;
        this.error = error;
        this.stacktrace = stacktrace;
        this.screenshotPath = screenshotPath;
        this.screenshotUrl = screenshotUrl;
    }

    @Override
    public String toString() {
        return "\nJiraTestCaseResultToBeReported" +
                "\n{" +
                "\n  testCaseKey='" + testCaseKey + '\'' +
                "\n  scenarioRowValue='" + scenarioRowValue + '\'' +
                "\n  testCaseStatus=" + testCaseStatus +
                "\n  error=" + (error != null ? error.getMessage() : "null") +
                "\n  stacktrace=" + Arrays.toString(stacktrace) +
                "\n  screenshotPath='" + screenshotPath + '\'' +
                "\n  screenshotUrl='" + screenshotUrl + '\'' +
                "\n" + '}' + "\n\n";
    }
}