package sk.moja.logger;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static sk.moja.enumerators.CustomProperties.getProperty;
import static sk.moja.enumerators.CustomProperties.getRunFrom;

public class Scenario {

    private static String testCaseRegex = getProperty("jira_testCaseRegex");

    public static List<String> getTestCaseKeysFromTestCaseScenarioLine(String testCaseName) {

        if(getRunFrom().equals("server")) {
            testCaseRegex = System.getProperty("jiraTestCaseRegex");
        }

        Pattern pattern = Pattern.compile(testCaseRegex);
        Matcher matcher = pattern.matcher(testCaseName);
        List<String> matches = new ArrayList<>();

        while(matcher.find()) {
            matches.add(matcher.group());
        }

        if(!matches.isEmpty()) {
            System.out.println("TC key(s): " + matches);
            return matches;
        }

        // If the test case key is not parsed the whole testCaseName is returned
        matches.add(testCaseName);
        return matches;
    }
}