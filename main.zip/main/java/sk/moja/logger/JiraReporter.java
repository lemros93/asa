package sk.moja.logger;

import com.kbc.qframe.jira.pojo.result.JiraStepStatusPOJO;
import io.cucumber.plugin.event.*;
import sk.moja.utils.Functions;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static sk.moja.enumerators.Constants.SERVER_DESTINATION_TEST_RESULTS;
import static sk.moja.enumerators.Constants.SERVER_DESTINATION_TEST_RESULTS_URL;
import static sk.moja.enumerators.CustomProperties.*;
import static sk.moja.logger.Scenario.getTestCaseKeysFromTestCaseScenarioLine;

public class JiraReporter {

    private static final int INDEX_OF_THE_FIRST_STEP = 0;
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");

    private static final String GREEN_COLOR = "#7BC67E";
    private static final String RED_COLOR = "#F0625D";

    private static final int AMOUNT_OF_STEPS_TO_BE_STORED_BEFORE_FAILED_STEP = 15;

    private final Functions functions = new Functions();
    public static List<String> failedStepsScreenshotPaths = new ArrayList<>();

    Boolean dryRun = true;
    Boolean doNotUseNewestExistingZephyrExecutionCreateNewOne = false;
    String testCycleKey = getProperty("jira_testCycleKey");
    List<JiraTestCaseResultToBeReported> listOfAllJiraTestCaseResultsToBeReported = new ArrayList<>();
    String currentFailedStep = "";
    List<String> allPerformedSteps = new ArrayList<>();
    List<String> lastStepsPerformedBeforeFailedStep = new ArrayList<>();

    public JiraReporter() {
        if (getProperty("jira_dryRun") != null) {
            dryRun = Boolean.parseBoolean(getProperty("jira_dryRun"));
        }
        if (getProperty("jira_doNotUseNewestExistingZephyrExecutionCreateNewOne") != null) {
            doNotUseNewestExistingZephyrExecutionCreateNewOne = Boolean.parseBoolean(getProperty("jira_doNotUseNewestExistingZephyrExecutionCreateNewOne"));
        }
        if (getRunFrom().equals("server")) {
            dryRun = Boolean.parseBoolean(System.getProperty("jiraDryRun"));
            doNotUseNewestExistingZephyrExecutionCreateNewOne = Boolean.parseBoolean(System.getProperty("jiraDoNotUseNewestExistingZephyrExecutionCreateNewOne"));
            testCycleKey = System.getProperty("jiraTestCycleKey");
        }
    }

    public void handleTestCaseStarted(TestCaseStarted event) {
        allPerformedSteps.clear();
        lastStepsPerformedBeforeFailedStep.clear();
    }

    public void handleTestStepFinished(TestStepFinished event) {
        if (event.getTestStep() instanceof PickleStepTestStep testStep) {
            allPerformedSteps.add(testStep.getStep().getText());

            if (event.getResult().getStatus().equals(Status.FAILED)) {
                currentFailedStep = testStep.getStep().getText();

                int indexOfLastStepsBeforeFailedStep = Math.max(0, allPerformedSteps.size() - AMOUNT_OF_STEPS_TO_BE_STORED_BEFORE_FAILED_STEP);
                lastStepsPerformedBeforeFailedStep = new ArrayList<>(allPerformedSteps.subList(indexOfLastStepsBeforeFailedStep, allPerformedSteps.size()));
            }
        }
    }

    public void handleTestCaseFinished(TestCaseFinished event) {
        if (!dryRun) {
            JiraTestCaseResultToBeReported currentTestCaseResult;

            List<String> testCasesOfTheScenario = getTestCaseKeysFromTestCaseScenarioLine(event.getTestCase().getName());

            Throwable error = event.getResult().getError();
            StackTraceElement[] stacktrace = (error != null) ? error.getStackTrace() : null;
            String screenshotPath = "";
            String screenshotUrl = "";

            for (String testCaseOfTheScenario : testCasesOfTheScenario) {
                for (String screenshotLocalPath : failedStepsScreenshotPaths) {

                    if (normalizeString(screenshotLocalPath).contains(normalizeString(event.getTestCase().getName()))) {
                        screenshotPath = screenshotLocalPath + ".png";
                        if (getRunFrom().equals("server")) {
                            screenshotUrl = getScreenshotServerUrlFromScreenshotPath(screenshotPath);
                        }
                        break;
                    }
                }
                Map<String, String> realVariables = getVariableValues(lastStepsPerformedBeforeFailedStep);

                currentTestCaseResult =
                        new JiraTestCaseResultToBeReported(
                                testCaseOfTheScenario,
                                event.getTestCase().getName(),
                                getPojoStatusForProvidedCucumberStatus(event.getResult().getStatus()),
                                currentFailedStep,
                                new ArrayList<>(lastStepsPerformedBeforeFailedStep),
                                new HashMap<>(realVariables),
                                error,
                                stacktrace,
                                screenshotPath,
                                screenshotUrl
                        );
                listOfAllJiraTestCaseResultsToBeReported.add(currentTestCaseResult);
            }
        }
    }

    public void handleTestRunFinished(TestRunFinished event) {
        if (dryRun) {
            System.out.println("JIRA report is not generated because dryRun parameter is set to " + dryRun);
            return;
        }

        if (!providedSystemPropertiesExist(
                "JIRA_MACHINE_USER_PATID",
                "JIRA_MACHINE_USER_CREDENTIALS_USR",
                "JIRA_MACHINE_USER_CREDENTIALS_PSW",
                "JIRA_MACHINE_TECHNICAL_USER")) {
            System.out.println("JIRA report is not generated because required system properties are not properly defined");
            return;
        }

        if (testCycleKey == null || testCycleKey.isEmpty()) {
            System.out.println("JIRA report is not generated because test cycle key is not defined defined");
            return;
        }

        JiraReportAPIClient jiraApiClient = new JiraReportAPIClient();
        List<String> testCasesOfTheTestCycle = jiraApiClient.getListOfTestCasesOfTestCycle(testCycleKey);

        if (doNotUseNewestExistingZephyrExecutionCreateNewOne) {
            jiraApiClient.createNewTestExecutionForAllTestCasesOfTestCycle(testCycleKey);
        }

        listOfAllJiraTestCaseResultsToBeReported.sort(Comparator.comparing(JiraTestCaseResultToBeReported::getTestCaseKey));

        Map<String, List<JiraTestCaseResultToBeReported>> groupedMapOfTestCaseResultsToBeReported =
                listOfAllJiraTestCaseResultsToBeReported
                        .stream()
                        .collect(Collectors.groupingBy(JiraTestCaseResultToBeReported::getTestCaseKey));

        for (var setOfKeyAndTestResultsRelatedToOneTestCase : groupedMapOfTestCaseResultsToBeReported.entrySet()) {
            List<JiraTestCaseResultToBeReported> testCaseResults = setOfKeyAndTestResultsRelatedToOneTestCase.getValue();
            try {
                if (testCaseResults.size() == 1) {
                    reportStandardTestCase(testCasesOfTheTestCycle, testCaseResults.get(0), jiraApiClient);
                } else {
                    reportMultiplePartsTestCase(testCasesOfTheTestCycle, setOfKeyAndTestResultsRelatedToOneTestCase, jiraApiClient);
                }
            } catch (Exception e) {
                System.err.println("CRITICAL: Failed to report results to Jira for Test Case: " + setOfKeyAndTestResultsRelatedToOneTestCase.getKey());
                e.printStackTrace();
            }
        }
    }

    private void reportStandardTestCase(List<String> testCasesOfTheTestCycle, JiraTestCaseResultToBeReported result, JiraReportAPIClient jiraApiClient) {
        if (testCasesOfTheTestCycle.contains(result.getTestCaseKey())) {
            String comment = "<b>Reported:</b>&ensp;" + LocalDateTime.now().format(DATE_TIME_FORMATTER) + "<br/><br/>";

            comment += "<span style='" + getColorStyleBasedOnStatus(result.getTestCaseStatus()) + "'>" + "<b>" + result.getTestCaseKey() + "</b>&ensp;" + result.getScenarioRowValue() + "&emsp;<b>RESULT:</b>&ensp;" + result.getTestCaseStatus() + "</span><br/><br/>";
            if (getRunFrom().equals("server")) {
                if (result.getScreenshotUrl() != null && !Objects.equals(result.getScreenshotUrl(), "")) {
                    comment += "<b>Screenshot:</b>&ensp;" + result.getScreenshotUrl() + "<br/><br/>";
                }
            } else {
                if (result.getScreenshotPath() != null && !Objects.equals(result.getScreenshotPath(), "")) {
                    jiraApiClient.propagateFileToFirstStepOfLatestTestCase(testCycleKey, result.getTestCaseKey(), result.getScreenshotPath());
                    File file = new File(result.getScreenshotPath());
                    comment += "<b>Screenshot:</b>&ensp; see attachment " + file.getName() + "<br/><br/>";
                }
            }

            if (result.getError() != null) {
                comment += "<b>Failed gherkin step:</b>&ensp;" + result.getCurrentStep() + "<br/><br/>";

                comment += "<b>Context before failed step:</b><br/>";
                for (String stepBeforeFail : result.getStepsPerformedBeforeFailedStep()) {
                    comment += stepBeforeFail + "<br/>";
                }
                comment += "<br/>";

                if (!result.getParametersValues().isEmpty()) {
                    comment += "<b>Real variable values used in steps above are:</b><br/>";
                    for (Map.Entry<String, String> entry : result.getParametersValues().entrySet()) {
                        comment += "<b>key:</b>&ensp;" + entry.getKey() + "&ensp;<b>value:</b>&ensp;" + entry.getValue() + "<br/>";
                    }
                    comment += "<br/>";
                }

                comment += "<b>Error:</b><br/>" + result.getError() + "<br/>";

                if (result.getStacktrace() != null) {
                    StringBuilder stackTraceBuilder = new StringBuilder();
                    stackTraceBuilder.append("<pre style='font-family: monospace; font-size: 12px;'>");

                    for (StackTraceElement stackTraceElement : result.getStacktrace()) {
                        stackTraceBuilder.append(stackTraceElement.toString()).append("\n");
                    }

                    stackTraceBuilder.append("</pre>");
                    comment += stackTraceBuilder.toString();
                }
            }

            jiraApiClient.updateTestCaseStep(
                    testCycleKey,
                    result.getTestCaseKey(),
                    INDEX_OF_THE_FIRST_STEP,
                    result.getTestCaseStatus(),
                    comment
            );
            jiraApiClient.updateTestCaseStatusAndExecutedBy(testCycleKey, result.getTestCaseKey(), result.getTestCaseStatus(), System.getenv("JIRA_MACHINE_TECHNICAL_USER"));
        }
    }

    private void reportMultiplePartsTestCase(List<String> testCasesOfTheTestCycle, Map.Entry<String, List<JiraTestCaseResultToBeReported>> setOfKeyAndTestResultsRelatedToOneTestCase, JiraReportAPIClient jiraApiClient) {
        String testCaseKey = setOfKeyAndTestResultsRelatedToOneTestCase.getKey();
        List<JiraTestCaseResultToBeReported> testCaseResults = setOfKeyAndTestResultsRelatedToOneTestCase.getValue();

        List<JiraStepStatusPOJO> listOfAllStatusesOfMultiplePartsTestCase =
                testCaseResults.stream()
                        .map(JiraTestCaseResultToBeReported::getTestCaseStatus)
                        .toList();

        JiraStepStatusPOJO finalTestCaseStatus = getFinalStatusForMultiplePartTestCase(listOfAllStatusesOfMultiplePartsTestCase);
        StringBuilder finalCommentBuilder = new StringBuilder();

        finalCommentBuilder.append("<b>Reported:</b>&ensp;" + LocalDateTime.now().format(DATE_TIME_FORMATTER) + "<br/><br/>");

        for (JiraTestCaseResultToBeReported result : testCaseResults) {
            finalCommentBuilder
                    .append("<span style='")
                    .append(getColorStyleBasedOnStatus(result.getTestCaseStatus()))
                    .append("'>")
                    .append("<b>")
                    .append(testCaseKey)
                    .append("</b>")
                    .append("&ensp;<b>PART:</b>&nbsp;")
                    .append(result.getScenarioRowValue())
                    .append("&emsp;<b>RESULT:</b>&ensp;")
                    .append(result.getTestCaseStatus())
                    .append("</span><br/><br/>");

            if (getRunFrom().equals("server")) {
                if (result.getScreenshotUrl() != null && !Objects.equals(result.getScreenshotUrl(), "")) {
                    finalCommentBuilder
                            .append("<b>Screenshot:</b>&ensp;")
                            .append(result.getScreenshotUrl())
                            .append("<br/><br/>");
                }
            } else {
                if (!Objects.equals(result.getScreenshotPath(), "")) {
                    jiraApiClient.propagateFileToFirstStepOfLatestTestCase(testCycleKey, result.getTestCaseKey(), result.getScreenshotPath());
                    File file = new File(result.getScreenshotPath());
                    finalCommentBuilder
                            .append("<b>Screenshot:</b>&ensp; see attachment ")
                            .append(file.getName())
                            .append("<br/><br/>");
                }
            }

            if (result.getError() != null) {
                finalCommentBuilder
                        .append("<b>Failed gherkin step:</b>&ensp;")
                        .append(result.getCurrentStep())
                        .append("<br/><br/>");

                finalCommentBuilder.append("<b>Context before failed step:</b><br/>");
                for (String stepBeforeFail : result.getStepsPerformedBeforeFailedStep()) {
                    finalCommentBuilder.append(stepBeforeFail).append("<br/>");
                }

                if (!result.getParametersValues().isEmpty()) {
                    finalCommentBuilder.append("<br/><b>Real variable values used in steps above are:</b><br/>");
                    for (Map.Entry<String, String> entry : result.getParametersValues().entrySet()) {
                        finalCommentBuilder
                                .append("<b>key:</b>&ensp;")
                                .append(entry.getKey())
                                .append("&ensp;<b>value:</b>&ensp;")
                                .append(entry.getValue())
                                .append("<br/>");
                    }
                    finalCommentBuilder.append("<br/>");
                }

                finalCommentBuilder.append("<br/><br/><b>Error:</b><br/>")
                        .append(result.getError())
                        .append("<br/>");

                if (result.getStacktrace() != null) {
                    StringBuilder stackTraceBuilder = new StringBuilder();
                    stackTraceBuilder.append("<pre style='font-family: monospace; font-size: 12px;'>");

                    for (StackTraceElement stackTraceElement : result.getStacktrace()) {
                        stackTraceBuilder.append(stackTraceElement.toString()).append("\n");
                    }

                    stackTraceBuilder.append("</pre>");
                    finalCommentBuilder.append(stackTraceBuilder);
                    finalCommentBuilder.append("</br>");
                }
            }
        }

        String finalTesCaseComment = finalCommentBuilder.toString();

        if (testCasesOfTheTestCycle.contains(testCaseKey)) {
            jiraApiClient.updateTestCaseStep(
                    testCycleKey,
                    testCaseKey,
                    INDEX_OF_THE_FIRST_STEP,
                    finalTestCaseStatus,
                    finalTesCaseComment
            );
            jiraApiClient.updateTestCaseStatusAndExecutedBy(testCycleKey, testCaseKey, finalTestCaseStatus, System.getenv("JIRA_MACHINE_TECHNICAL_USER"));
        }
    }

    private JiraStepStatusPOJO getPojoStatusForProvidedCucumberStatus(Status cucumberStatus) {
        if (cucumberStatus == Status.PASSED) {
            return JiraStepStatusPOJO.PASS;
        } else if (cucumberStatus == Status.FAILED) {
            return JiraStepStatusPOJO.FAIL;
        } else {
            return JiraStepStatusPOJO.NOT_EXECUTED;
        }
    }

    private JiraStepStatusPOJO getFinalStatusForMultiplePartTestCase(List<JiraStepStatusPOJO> statusesOfMultiplePartTestCase) {
        if (statusesOfMultiplePartTestCase == null || statusesOfMultiplePartTestCase.isEmpty()) {
            return JiraStepStatusPOJO.NOT_EXECUTED;
        }

        if (statusesOfMultiplePartTestCase.contains(JiraStepStatusPOJO.FAIL)) {
            return JiraStepStatusPOJO.FAIL;
        }

        if (statusesOfMultiplePartTestCase.stream().allMatch(status -> status == JiraStepStatusPOJO.PASS)) {
            return JiraStepStatusPOJO.PASS;
        }

        return JiraStepStatusPOJO.NOT_EXECUTED;
    }

    private Boolean providedSystemPropertiesExist(String... systemProperties) {
        for (String systemProperty : systemProperties) {
            String value = System.getenv(systemProperty);
            if (value == null || value.isEmpty()) {
                System.out.println("Property " + systemProperty + " is not properly defined");
                return false;
            }
        }
        return true;
    }

    private String getColorStyleBasedOnStatus(JiraStepStatusPOJO status) {
        if (status.equals(JiraStepStatusPOJO.FAIL)) {
            return "background-color:" + RED_COLOR + ";";
        } else if (status.equals(JiraStepStatusPOJO.PASS)) {
            return "background-color:" + GREEN_COLOR + ";";
        } else {
            return "";
        }
    }

    private Map<String, String> getVariableValues(List<String> steps) {
        List<String> stepsParameters = getStepsParameters(steps);
        Map<String, String> variablesValues = new HashMap<>();

        for (String parameter : stepsParameters) {
            if (!parameter.equals(functions.getText(parameter))) {
                variablesValues.put(parameter, functions.getText(parameter));
            }
        }
        return variablesValues;
    }

    private List<String> getStepsParameters(List<String> steps) {

        Pattern pattern = Pattern.compile("\"([^\"]*)\"");

        return steps.stream()
                .flatMap(step -> {
                    Matcher matcher = pattern.matcher(step);
                    List<String> params = new ArrayList<>();

                    while (matcher.find()) {
                        params.add(matcher.group(1));
                    }

                    return params.stream();
                }).distinct().toList();
    }

    private static String normalizeString(String value) {
        return value.toLowerCase()
                .replace("-", "_")
                .replace("(", "")
                .replace(")", "")
                .replaceAll("\\s+", "_").replaceAll("[^a-zA-Z0-9]", "_").replaceAll("_+", "_").replaceAll("^_+|_+$", "")
                .trim();
    }

    public static String getScreenshotServerUrlFromScreenshotPath(String screenshotPathOnTheServer) {
        String screenshotRelativeUrlPath = screenshotPathOnTheServer.replace(SERVER_DESTINATION_TEST_RESULTS, "");
        return SERVER_DESTINATION_TEST_RESULTS_URL + screenshotRelativeUrlPath;
    }
}