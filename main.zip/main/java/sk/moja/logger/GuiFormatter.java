
package sk.moja.logger;

import io.cucumber.core.exception.ExceptionUtils;
import io.cucumber.plugin.event.*;
import sk.moja.enumerators.Constants;
import sk.moja.enumerators.CustomProperties;
import sk.moja.interfaces.Gui;

import static sk.moja.enumerators.Constants.DESTINATION;
import static sk.moja.enumerators.Constants.LOCAL_DESTINATION;
import static sk.moja.utils.StepContext.getStepNameTransformed;

public class GuiFormatter {
    private int numberOfFeature = 0;
    private String actualFeature = "";

    public GuiFormatter() {}

    public void handleTestSourceRead(TestSourceRead event) {
        this.numberOfFeature++;
    }

    public void handleTestRunFinished(TestRunFinished event) {
        Gui.featureProgressBar.setValue(Gui.featureProgressBar.getValue() + 1);
    }

    public void handleTestStepFinished(TestStepFinished event) {
        printStep(event);
        printError(event);
        Gui.scenarioProgressBar.setValue(Gui.scenarioProgressBar.getValue() + 1);
    }

    private void printStep(TestStepFinished event) {
        if (event.getTestStep() instanceof PickleStepTestStep) {
            PickleStepTestStep testStep = (PickleStepTestStep) event.getTestStep();
            String keyword = testStep.getStep().getKeyword();
            String stepText = testStep.getStep().getText();
            String status = event.getResult().getStatus().name().toUpperCase();
            String duration = event.getResult().getDuration().toString().replace("PT", "Cas: ");

            String statusColor;
            if (status.equalsIgnoreCase(Constants.PASSED))
                statusColor = "green";
            else if (status.equalsIgnoreCase(Constants.FAILED))
                statusColor = "red";
            else if (status.equalsIgnoreCase(Constants.SKIPPED))
                statusColor = "blue";
            else
                statusColor = "#8000ff";

            if (!CustomProperties.getExtractScenariosName()) {
                String message = "<p style=\"color:" + statusColor + "; padding-left: 4em;\"><b>" + keyword + " " + stepText + " " + status + " " + duration + "</b></p>";

                if ((status.equalsIgnoreCase(Constants.PASSED) || status.equalsIgnoreCase(Constants.FAILED)) && !CustomProperties.getDryRun()) {
                    message += "<p style=\"color:orange;  padding-left: 4em;\"><b>" + getStepNameTransformed() + "</b></p>";
                }

                Gui.updateLogTextArea(message);
            }

        }
    }

    private void printError(TestStepFinished event) {
        Result result = event.getResult();
        Throwable error = result.getError();
        if (error != null) {
            String text = ExceptionUtils.printStackTrace(error);
            StringBuilder errorText = new StringBuilder();
            String[] lines = text.split("\\r?\\n");

            for (String item : lines) {
                if (item.startsWith("Screenshot: file:")) {
                    errorText.append(item.replace("file:/", ""));
                    break;
                } else {
                    errorText.append(item.replace("<", "< ")).append("<br>");
                }
            }
            Gui.updateLogTextArea("<p style=\"color:red; padding-left: 4em;\">" + errorText + "</p>");
        }
    }

    public void handleTestCaseFinished(TestCaseFinished event) {
        String keyword = event.getTestCase().getKeyword();
        String testCase = event.getTestCase().getName();
        String status = event.getResult().getStatus().name();
        String duration = event.getResult().getDuration().toString().replace("PT", "Cas: ");

        String statusColor;
        if (status.equalsIgnoreCase(Constants.PASSED))
            statusColor = "green";
        else if (status.equalsIgnoreCase(Constants.FAILED))
            statusColor = "red";
        else if (status.equalsIgnoreCase(Constants.SKIPPED))
            statusColor = "blue";
        else
            statusColor = "#8000ff";

        if (!CustomProperties.getExtractScenariosName()) {
            String message = "<p style=\"background-color:" + statusColor + "; padding-left: 4em;\"><b>" + keyword + " " + testCase + " " + status + " " + duration + "</b></p>";
            Gui.updateLogTextArea(message);
        }

    }

    public void handleTestCaseStarted(TestCaseStarted event) {
        String message = "";
        String location = "/" + LOCAL_DESTINATION + DESTINATION + "/temp/";
        String featureName;

        if (actualFeature.equals("")) {
            this.actualFeature = event.getTestCase().getUri().toString();
            Gui.featureProgressBar.setMaximum(this.numberOfFeature);
            Gui.featureProgressBar.setValue(0);
            if (CustomProperties.getExtractScenariosName()) {
                featureName = event.getTestCase().getUri().getPath().replace(location, "");
                message += "<p style=\"padding-left: 4em;\"><b>" + featureName + "</b></p>";
            }
        }

        if (!this.actualFeature.equals(event.getTestCase().getUri().toString())) {
            this.actualFeature = event.getTestCase().getUri().toString();
            Gui.featureProgressBar.setValue(Gui.featureProgressBar.getValue() + 1);
            if (CustomProperties.getExtractScenariosName()) {
                featureName = event.getTestCase().getUri().getPath().replace(location, "");
                message += "<p style=\"padding-left: 4em;\"><b>" + "----------------------------------------------------------------------------------------" + "</b></p>";
                message += "<p style=\"padding-left: 4em;\"><b>" + "feature: " + featureName + "</b></p>";
            }
        }

        Gui.scenarioProgressBar.setValue(0);
        Gui.scenarioProgressBar.setMaximum(event.getTestCase().getTestSteps().size());

        String keyword = event.getTestCase().getKeyword();
        String testCaseName = event.getTestCase().getName();
        String testCase = testCaseName + " - Line " + event.getTestCase().getLine();

        if (!CustomProperties.getExtractScenariosName()) {
            message = "<p style=\"padding-left: 4em;\"><b>" + keyword + " " + testCase + "</b></p>";
        } else {
            message += "<p style=\"padding-left: 4em;\"><b>" + keyword + ": " + testCaseName + "</b></p>";
        }

        Gui.updateLogTextArea(message);
    }

    public static void printError(Exception e) {
        StringBuilder errorText = new StringBuilder();
        if (e != null) {
            String[] lines = e.getMessage().split("\\r?\\n");

            for (String item : lines) {
                errorText.append(item.replace("<", "< ")).append("<br>");
            }
            Gui.updateLogTextArea("<p style=\"color:red; padding-left: 4em;\">" + errorText + "</p>");
        }
    }
}
