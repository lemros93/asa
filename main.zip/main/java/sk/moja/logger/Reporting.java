package sk.moja.logger;

import io.cucumber.plugin.event.*;
import sk.moja.base.TestBase;
import sk.moja.utils.StepContext;

public class Reporting {

    public Reporting() {
        TestBase.setUp();
    }

    public void handleStepStarted(TestStepStarted event) {
        if (event.getTestStep() instanceof PickleStepTestStep) {
            PickleStepTestStep step = (PickleStepTestStep) event.getTestStep();
            StepContext.setCurrentStepName(step.getStep().getText());
        }
    }

    public void handleTestStepFinished(TestStepFinished event) {

        if (event.getTestStep() instanceof PickleStepTestStep) {
            StepContext.setCurrentStepName( ((PickleStepTestStep) event.getTestStep()).getStep().getText());
            StepContext.setCurrentStepStatus(event.getResult().getStatus().toString());

        }
    }
}
