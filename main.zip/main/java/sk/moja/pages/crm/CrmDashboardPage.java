package sk.moja.pages.crm;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.byXpath;

public class CrmDashboardPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static {
        elementMap.put("Home", new Element(byXpath("//*[(@data-text=\"Home\") or (@data-text=\"Domovská stránka\")]")));
        elementMap.put("Recent", new Element(byXpath("//*[@data-text=\"Recent\"]")));
        elementMap.put("Pinned", new Element(byXpath("//*[@data-text=\"Pinned\"]")));

        elementMap.put("Dashboards", new Element(byXpath("//*[(@data-text=\"Dashboards\") or (@data-text=\"Prehľady\")]")));
        elementMap.put("Activities", new Element(byXpath("//*[(@data-text=\"Activities\") or (@data-text=\"Aktivity\")]")));
        elementMap.put("Call reports", new Element(byXpath("//*[(@data-text=\"Call reports\") or (@data-text=\"Call Reporty\")]")));

        elementMap.put("Customer identification", new Element(byXpath("//*[(@data-text=\"Customer identification\" or (@data-text=\"Identifikácia zákazníka\"))]")));
        elementMap.put("Manual search", new Element(byXpath("//*[(@data-text=\"Manual search\") or (@data-text=\"Manuálne vyhľadávanie\")]")));
        elementMap.put("Customers", new Element(byXpath("//*[(@data-text=\"Customers\") or (@data-text=\"Zákazníci\")]")));
        elementMap.put("Contacts", new Element(byXpath("//*[(@data-text=\"Contacts\") or (@data-text=\"Kontakty\")]")));
        elementMap.put("Worker relationships", new Element(byXpath("//*[(@data-text=\"Worker relationships\") or (@data-text=\"Priradení pracovníci\")]")));

        elementMap.put("Opportunity", new Element(byXpath("//*[(@data-text=\"Opportunity\") or (@data-text=\"Príležitosti\")]")));
        elementMap.put("Offers", new Element(byXpath("//*[(@data-text=\"Offers\") or (@data-text=\"Ponuky\")]")));
        elementMap.put("Campaigns", new Element(byXpath("//*[(@data-text=\"Campaigns\") or (@data-text=\"Kampane\")]")));
        elementMap.put("Marketing Lists", new Element(byXpath("//*[(@data-text=\"Marketing Lists\") or (@data-text=\"Marketingové zoznamy\")]")));

        elementMap.put("Service requests", new Element(byXpath("//*[(@data-text=\"Service requests\") or (@data-text=\"Servisné požiadavky\")]")));
        elementMap.put("Queues", new Element(byXpath("//*[(@data-text=\"Queues\") or (@data-text=\"Fronty\")]")));
        elementMap.put("Compensations", new Element(byXpath("//*[(@data-text=\"Compensations\") or (@data-text=\"Kompenzácie\")]")));

        elementMap.put("User settings", new Element(byXpath("//*[(@data-text=\"User settings\") or (@data-text=\"Nastavenie používateľa\")]")));

        elementMap.put("New find", new Element(byXpath("//*[@id=\"button_1\"]")));
    }
}