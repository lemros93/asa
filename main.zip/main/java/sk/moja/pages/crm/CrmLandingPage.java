package sk.moja.pages.crm;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.byId;
import static com.codeborne.selenide.Selectors.byXpath;

public class CrmLandingPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static {
        elementMap.put("CRM App landing page iFrame", new Element(byId("AppLandingPage")));
        elementMap.put("CRM tab - app landing page", new Element(
            byXpath("//*[@id='AppLandingPageContentContainer']//a[contains(@aria-label, 'Centrum služieb pre zákazníkov') or contains(@aria-label, 'Customer Service Hub')]"
            )));
    }
}
