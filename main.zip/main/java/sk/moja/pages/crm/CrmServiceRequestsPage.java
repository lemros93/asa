package sk.moja.pages.crm;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.byAttribute;
import static com.codeborne.selenide.Selectors.byXpath;

public class CrmServiceRequestsPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static {
        // Service requests
        elementMap.put("Service Requests - Open Dashboards", new Element(byXpath("//*[@id='OpenEntityDashboard']")));
        elementMap.put("Service Requests - Refresh All", new Element(byXpath("//button[(@aria-label='Refresh All') or (@aria-label='Obnoviť všetky')]")));
        elementMap.put("Service Requests - Header", new Element(byAttribute("data-id", "headerContainer")));

        // Service request detail
        elementMap.put("Service Request Detail - Request Category L1", new Element(byXpath("//ul[contains(@id, 'categoryl1')]//*[contains(@id, 'tag_text')]")));
        elementMap.put("Service Request Detail - Request Category L2", new Element(byXpath("//ul[contains(@id, 'categoryl2')]//*[contains(@id, 'tag_text')]")));
        elementMap.put("Service Request Detail - Request Category L3", new Element(byXpath("//ul[contains(@id, 'categoryl3')]//*[contains(@id, 'tag_text')]")));
        elementMap.put("Service Request Detail - Customer - Name", new Element(byXpath("//*[contains(@id, 'customerid')]//*[contains(@id, 'tag_text')]")));
        elementMap.put("Service Request Detail - Customer - Main Phone", new Element(byXpath("//*[contains(@id, 'phone')]//input")));
        elementMap.put("Service Request Detail - Customer - Email", new Element(byXpath("//*[(@title='Customer') or (@title='Zákazník')]/../..//*[contains(@id, 'email')]//input")));
        elementMap.put("Service Request Detail - Client's request entering", new Element(byXpath("//textarea[contains(@data-id,'description.fieldControl-text')]")));
        elementMap.put("Service Request Detail - Product Concerned - Product", new Element(byXpath("//*[contains(@id, 'clientproductid')]//*[contains(@id, 'tag_text')]")));
        elementMap.put("Service Request Detail - Product Concerned - Product Number", new Element(byXpath("//*[contains(@id, 'mil_accountnumber')]//input")));
        elementMap.put("Service Request Detail - Product Concerned - Source System", new Element(byXpath("//*[contains(@id, 'mil_extsystem')]//*[contains(@id, 'tag_text')]")));

        elementMap.put("General", new Element(byXpath("//*[@data-id=\"tablist-general\"]")));
        elementMap.put("Processing data", new Element(byXpath("//*[@data-id=\"tablist-processingdata\"]")));
        elementMap.put("CRM information", new Element(byXpath("//*[@data-id=\"tablist-crminformation\"]")));
        elementMap.put("CRM opportunity", new Element(byXpath("//*[@data-id=\"mil_opportunityid.fieldControl-LookupResultsDropdown_mil_opportunityid_textInputBox_with_filter_new\"]")));
        elementMap.put("CRM opportunity tag", new Element(byXpath("//*[@data-id=\"mil_opportunityid.fieldControl-LookupResultsDropdown_mil_opportunityid_selected_tag_text\"]")));
        elementMap.put("Estimate close date", new Element(byXpath("//*[@data-id=\"estimatedclosedate.fieldControl-date-time-input\"]")));
        elementMap.put("Child service request", new Element(byXpath("//*[@data-id=\"tablist-childservicerequest\"]")));

        elementMap.put("List of requests", new Element(byXpath("//*[@data-id=\"data-set-body-container\"]")));

    }

    public static Element getServiceRequestByTheTimeStamp(String timeStamp) {
        return new Element(byXpath("//*[contains(text(), '" + timeStamp + "')]/.."));
    }
}