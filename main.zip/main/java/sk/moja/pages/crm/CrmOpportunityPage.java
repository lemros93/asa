package sk.moja.pages.crm;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.byXpath;

public class CrmOpportunityPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static {
        // Opportunity detail - summary tab
        elementMap.put("Opportunity Detail - Type", new Element(byXpath("//select[contains(@aria-label, 'Opportunity type') or contains(@aria-label, 'Typ príležitosti')]")));
        elementMap.put("Opportunity Detail - Subtype", new Element(byXpath("//*[contains(@data-id, 'opportunitysubtypeid_selected_tag_text')]")));
        elementMap.put("Opportunity Detail - Expected Closing Date", new Element(byXpath("//input[contains(@data-id, 'estimatedclosedate.fieldControl-date-time-input')]")));
        elementMap.put("Opportunity Detail - Customer", new Element(byXpath("//*[@data-id='parentaccountid.fieldControl-LookupResultsDropdown_parentaccountid_selected_tag_text']")));
        elementMap.put("Opportunity Detail - Owner", new Element(byXpath("//*[@data-id='ownerid.fieldControl-LookupResultsDropdown_ownerid_selected_tag_text']")));
        elementMap.put("Opportunity Detail - Additional information", new Element(byXpath("//textArea[contains(@id, 'description.fieldControl')]")));
        elementMap.put("Opportunity Detail - Product category 1", new Element(byXpath("//*[@data-id='mil_productcatalogl1id.fieldControl-LookupResultsDropdown_mil_productcatalogl1id_selected_tag_text']")));
        elementMap.put("Opportunity Detail - Product category 2", new Element(byXpath("//*[@data-id='mil_productcatalogl2id.fieldControl-LookupResultsDropdown_mil_productcatalogl2id_selected_tag_text']")));
        elementMap.put("Opportunity Detail - Product category 3", new Element(byXpath("//*[@data-id='mil_productcatalogl3id.fieldControl-LookupResultsDropdown_mil_productcatalogl3id_selected_tag_text']")));
        elementMap.put("Opportunity Detail - Product category 4", new Element(byXpath("//*[@data-id='mil_productcatalogl4id.fieldControl-LookupResultsDropdown_mil_productcatalogl4id_selected_tag_text']")));

        // Opportunity - product and service information
        elementMap.put("Opportunity - product and service information tab", new Element(byXpath("//li[@data-id='tablist-PRODUCTANDSERVICE']")));
        elementMap.put("Opportunity - product and service - amount", new Element(byXpath("//*[@data-id='mil_amount.fieldControl-decimal-number-text-input']")));
        elementMap.put("Opportunity - product and service - currency", new Element(byXpath("//*[@data-id='mil_currencyid.fieldControl-LookupResultsDropdown_mil_currencyid_selected_tag_text']")));
    }
}