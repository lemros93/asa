package sk.moja.pages.crm;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.byId;
import static com.codeborne.selenide.Selectors.byXpath;

public class CrmCustomerPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static {

        elementMap.put("Header title", new Element(byXpath("//*[@data-id=\"header_title\"]")));
        elementMap.put("Basic information", new Element(byXpath("//*[@data-id=\"tablist-BASIC_INFO_TAB\"]")));
        elementMap.put("Relationships", new Element(byXpath("//*[@data-id=\"tablist-RELATIONS_TAB\"]")));
        elementMap.put("Offers", new Element(byXpath("//*[@data-id=\"tablist-OFFERS_TAB\"]")));
        elementMap.put("Products", new Element(byXpath("//*[@data-id=\"tablist-PRODUCTS_TAB\"]")));
        elementMap.put("Services", new Element(byXpath("//*[@data-id=\"tablist-SERVICES_TAB\"]")));
        elementMap.put("Activities", new Element(byXpath("//*[@data-id=\"tablist-ACTIVITIES_TAB\"]")));

        elementMap.put("Risk Indicators", new Element(byId("WebResource_riskindicators")));
        elementMap.put("Tabs", new Element(byId("tablist_51")));

        elementMap.put("Notifications frame", new Element(byId("WebResource_notificationindicators")));
        elementMap.put("Service Requests link", new Element(byXpath("//*[contains(text(), 'servisných požiadaviek') or contains(text(), 'servisné požiadavky') or contains(text(), 'servisná požiadavka')]")));

        elementMap.put("Open Service Requests section", new Element(byXpath("//*[contains(@id,'ViewSelector') and (contains(text(),'Open service requests') or contains(text(),'Otvorené servisné žiadosti'))]/ancestor::*[@id='dataSetRoot_case']")));
        elementMap.put("Newest Open Service Request", new Element(byXpath("//*[contains(@id,'ViewSelector') and (contains(text(),'Open service requests') or contains(text(),'Otvorené servisné žiadosti'))]/ancestor::*[@id='dataSetRoot_case']//*[@class='wj-row']//*[@data-id=\"cell-0-2\"] | (//*[@data-id='case-GridList']//*[contains(@data-id, 'case-ListItemContent')])[1] ")));

        elementMap.put("Customer - Open opportunities", new Element(byXpath("//iframe[@id='WebResource_Opportunity']")));
        elementMap.put("Customer - Open opportunities - Newest opportunity", new Element(byXpath("//*[(@id='htab1-00')]")));
        elementMap.put("Customer - Open opportunities - Newest opportunity title", new Element(byXpath("//*[(@id='htab1-00Title')]")));
    }

    public static Element getNthServiceRequestWithName(int order, String serviceRequestName) {
        return new Element(byXpath(
            "(//*[contains(text(),'Open service requests') or contains(text(),'Otvorené servisné žiadosti')]/ancestor::*[@id='dataSetRoot_case' or @data-id='DataSetHostContainer']//*[contains(@class, 'wj-row') or @data-id='data-set-body-container']//self::*[a[@title='" + serviceRequestName + "'] or label[text()='" + serviceRequestName + "']])[" + order + "]"));
    }
}