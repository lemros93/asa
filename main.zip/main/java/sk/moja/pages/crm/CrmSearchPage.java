package sk.moja.pages.crm;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.byId;
import static com.codeborne.selenide.Selectors.byXpath;

public class CrmSearchPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static {
        elementMap.put("Manual search frame", new Element(byId("FullPageWebResource")));

        elementMap.put("Client type", new Element(byXpath("//*[@id='foForm']//*/div[@class='form-label' and text()='Typ osoby']/following-sibling::div[contains(@class,'form-input')]")));
        elementMap.put("Company", new Element(byXpath("//*[@id='foForm']//*/div[text()='Právnická osoba/Podnikateľ']")));
        elementMap.put("Physical person", new Element(byXpath("//*[@id='foForm']//*/div[text()='Fyzická osoba']")));

        elementMap.put("FirstName input overview", new Element(byXpath("//*[@id='foForm']//*/div[@class='form-label' and text()='Meno']/following-sibling::div[contains(@class,'form-input')]")));
        elementMap.put("FirstName input", new Element(byXpath("//*[@id='foForm']//*/div[@class='form-label' and text()='Meno']/following-sibling::div//input")));
        elementMap.put("Surname input overview", new Element(byXpath("//*[@id='foForm']//*/div[@class='form-label' and text()='Priezvisko']/following-sibling::div[contains(@class,'form-input')]")));
        elementMap.put("Surname input", new Element(byXpath("//*[@id='foForm']//*/div[@class='form-label' and text()='Priezvisko']/following-sibling::div//input")));
        elementMap.put("BirthNumber input overview", new Element(byXpath("//*[@id='foForm']//*/div[@class='form-label' and text()='Rodné číslo']/following-sibling::div[contains(@class,'form-input')]")));
        elementMap.put("BirthNumber input", new Element(byXpath("//*[@id='foForm']//*/div[@class='form-label' and text()='Rodné číslo']/following-sibling::div//input")));
        elementMap.put("Date of birth", new Element(byXpath("//*[@id='foForm']//*/div[@class='form-label' and text()='Dátum narodenia']/following-sibling::div[contains(@class,'form-input')]")));
        elementMap.put("Phone number", new Element(byXpath("//*[@id='foForm']//*/div[@class='form-label' and text()='Mobil']/following-sibling::div[contains(@class,'form-input')]")));
        elementMap.put("Account", new Element(byXpath("//*[@id='foForm']//*/div[@class='form-label' and text()='IBAN']/following-sibling::div[contains(@class,'form-input')]")));
        elementMap.put("E-mail", new Element(byXpath("//*[@id='foForm']//*/div[@class='form-label' and text()='E-mail']/following-sibling::div[contains(@class,'form-input')]")));

        elementMap.put("Company name overview", new Element(byXpath("//*[@id='poForm']//*/div[@class='form-label' and text()='Názov spoločnosti']/following-sibling::div[contains(@class,'form-input')]")));
        elementMap.put("Company name input", new Element(byXpath("//*[@id='poForm']//*/div[@class='form-label' and text()='Názov spoločnosti']/following-sibling::div//input")));
        elementMap.put("Company account", new Element(byXpath("//*[@id='poForm']//*/div[@class='form-label' and text()='IBAN']/following-sibling::div[contains(@class,'form-input')]")));
        elementMap.put("ICO", new Element(byXpath("//*[@id='poForm']//*/div[@class='form-label' and text()='IČO']/following-sibling::div[contains(@class,'form-input')]")));
        elementMap.put("ZECO", new Element(byXpath("//*[@id='poForm']//*/div[@class='form-label' and text()='ZEČO']/following-sibling::div[contains(@class,'form-input')]")));

        elementMap.put("Find", new Element(byId("primary_button")));
        elementMap.put("Client link", new Element(byXpath("//div[@class='list-value link name']")));
    }

    public static Element getFoundLinkBasedOnTheCrmUserName(String crmUserName) {
        return new Element(byXpath("//*[contains(@class,'list-value link') and text()='" + crmUserName + "']"));
    }

    public static Element getFoundLinkBasedOnTheCrmUserNameAndAddress(String crmUserName, String crmUserAddress) {
        return new Element(byXpath("//*[@class='list-value' and contains(text(),'" + crmUserAddress + "')]/ancestor::*[.//*[contains(@class,'list-value link') and text()='" + crmUserName + "']][1]//*[contains(@class,'list-value link') and text()='" + crmUserName + "']"));
    }
}