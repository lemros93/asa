package sk.moja.pages.mojaCsob.products;

import lombok.Getter;
import sk.moja.elements.CsobDropdown;
import sk.moja.elements.Element;
import sk.moja.elements.ListOfElementItems;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class ProductDetailPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Account rename", new Element(byClassName("csob-icon-set-edit")));
        elementMap.put("Account check", new Element(byClassName("csob-icon-set-check")));
        elementMap.put("Account name close", new Element(byClassName("csob-icon-set-close")));
        elementMap.put("Name input", new Element(byId("name")));
        elementMap.put("Change account", new Element(byXpath("//csob-dropdown[@inputid='simpleProductsDropdown']")));
        elementMap.put("Account name", new Element(byClassName("display-content")));
        elementMap.put("Payment", new Element(byClassName("csob-icon-set-payment")));
        elementMap.put("Standing order", new Element(byClassName("csob-icon-set-standing-order")));
        elementMap.put("Sepa payment templates", new Element(byClassName("csob-icon-set-templates")));
        elementMap.put("Overdraft", new Element(byClassName("csob-icon-set-add-alt")));
        elementMap.put("Direct debit", new Element(byClassName("csob-icon-set-direct-debit")));
        elementMap.put("List of accounts", new ListOfElementItems(byXpath("(//*[contains(@class, 'csob-dropdown-items-wrapper')]//ul)[1]"), byXpath("//li")));
        elementMap.put("Accounts", new Element(byXpath("(//*[contains(@class, 'csob-dropdown-items-wrapper')]//ul)[1]//li")));
        elementMap.put("Notification", new Element(byClassName("csob-icon-set-notification")));
        elementMap.put("Statements", new Element(byClassName("csob-icon-set-document")));
        elementMap.put("Saving transfer", new Element(byClassName("csob-icon-set-saving-add")));
        elementMap.put("Credit card", new Element(byClassName("csob-icon-set-card")));
        elementMap.put("Card repayment", new Element(byClassName("csob-icon-set-card-repay")));
        elementMap.put("Account transfer", new Element(byClassName("csob-icon-set-change-account-type")));
        elementMap.put("Owner name", new Element(byXpath("//label[normalize-space()='Majiteľ účtu']/following-sibling::h2")));
        elementMap.put("IBAN", new Element(byXpath("//ib-product-header/*//ib-iban")));
        elementMap.put("Help", new Element(byXpath("//csob-helper-icon")));
        elementMap.put("Help popover", new Element(byClassName("popover-content")));

        elementMap.put("Account detail buttons", new Element(byClassName("icon-buttons-wrapper-left")));
        elementMap.put("Upload energy certificate", new Element(byXpath("//csob-icon-button[@iconclass=\"csob-icon-set-document\"]/div[contains(., 'Nahrať energetický certifikát') or contains(., 'Pridať energetický certifikát')]")));
        elementMap.put("Account Balance", new Element(byXpath("//ib-product-basic-info-amount-item/div/ib-price")));
        elementMap.put("Available balance", new Element(byXpath("//ib-product-basic-info-amount-item")));
        elementMap.put("Notice period", new Element(byXpath("//ib-product-basic-info-item")));
        elementMap.put("Last payment amount", new Element(byXpath("(//ib-processed-transaction//ib-price//span[contains(@class, 'ng-star-inserted')])[1]")));
        elementMap.put("Account number", new Element(byXpath("//ib-processed-transaction/div/div/ib-iban")));
        elementMap.put("Additional info", new Element(byXpath("//ib-product-additional-info")));
        elementMap.put("Own balance", new Element(byAttribute("keyid", "ownBalance")));
        elementMap.put("Overdraft amount", new Element(byAttribute("keyid", "overdraftAmount")));

        elementMap.put("More account information", new Element(byText("Viac informácií o účte")));
        elementMap.put("Less account information", new Element(byText("Menej informácií o účte")));

        elementMap.put("More informations", new Element(byText("Viac informácií")));
        elementMap.put("Less informations", new Element(byText("Menej informácií o účte")));
        elementMap.put("My offer", new Element(byText("Pozrieť moju ponuku")));

        elementMap.put("Graf", new Element(byClassName("csob-icon-set-pie-chart")));
        elementMap.put("Graf - date from", new Element(byId("transactionsChartFilter_dateFrom")));
        elementMap.put("Graf - date to", new Element(byId("transactionsChartFilter_dateTo")));
        elementMap.put("Graf vyhladat", new Element(byText("Vyhľadať")));

        elementMap.put("Filter", new Element(byClassName("csob-icon-set-filter")));
        elementMap.put("Filter - search in transactions", new Element(byId("searchInput")));
        elementMap.put("Filter - date from", new Element(byId("transactionsFilter_dateFrom")));
        elementMap.put("Filter - date to", new Element(byId("transactionsFilter_dateTo")));
        elementMap.put("Filter - transaction type", new CsobDropdown(byAttribute("formcontrolname", "groups")));
        elementMap.put("Amount from", new Element(byId("transactionsFilter_amountFrom")));
        elementMap.put("Amount to", new Element(byId("transactionsFilter_amountTo")));
        elementMap.put("Filter submit", new Element(byText("Vyhľadať")));

        elementMap.put("Close", new Element(byClassName("close-text")));

        elementMap.put("Waiting transactions", new Element(byText("Čakajúce platby")));
        elementMap.put("Waiting transactions amount", new Element(byClassName("total-amount")));

        elementMap.put("Waiting transactions list", new Element(byXpath("//ib-waiting-transaction")));
        elementMap.put("Waiting transactions - row", new Element(byXpath("//ib-waiting-transaction/*[contains(@class, 'row')]")));
        elementMap.put("Waiting saving transactions list", new Element(byXpath("//ib-waiting-savings-transfer-transaction")));
        elementMap.put("Held transactions", new Element(byText("Blokované platby")));
        elementMap.put("Held transactions list", new Element(byXpath("//ib-held-transaction")));
        elementMap.put("Processed transactions list", new Element(byXpath("//ib-processed-transaction")));
        elementMap.put("Processed transactions date", new Element(byXpath("//ib-transactions-group/div/div/b")));
        elementMap.put("Processed transactions dates list", new Element(byXpath("//ib-transactions-group//*[contains(@class, 'separator')]//b")));
        elementMap.put("Processed transactions amounts list", new Element(byXpath("//ib-processed-transaction//ib-price//span")));
        elementMap.put("Last payment bank reference", new Element(byXpath("(//ib-processed-transaction//ib-detail-row//*[contains(text(), 'Referencia banky:')])[1]/following-sibling::span")));
        elementMap.put("Price", new Element(byXpath(".//ib-price")));

        elementMap.put("Cancel", new Element(byClassName("csob-icon-set-trash-alt")));
        elementMap.put("Postpay", new Element(byClassName("csob-icon-set-payment-back")));
        elementMap.put("Repeat", new Element(byClassName("csob-icon-set-payment-repeat")));
        elementMap.put("Payment detail in PDF", new Element(byXpath(".//ib-download-icon-button")));
        elementMap.put("Create a payment template", new Element(byClassName("csob-icon-set-templates")));
        elementMap.put("Create a standing order", new Element(byClassName("csob-icon-set-standing-order")));

        elementMap.put("Left arrow", new Element(byClassName("csob-icon-set-keyboard-arrow-left-alt2")));
        elementMap.put("Right arrow", new Element(byClassName("csob-icon-set-keyboard-arrow-right-alt2")));
        elementMap.put("Paging", new Element(byXpath("//csob-paging")));
        elementMap.put("Page size", new Element(byClassName("csob-table-item-container")));

        elementMap.put("Show cronto token", new Element(byXpath("//ib-cronto-signature/div/div/div/a")));
    }
}