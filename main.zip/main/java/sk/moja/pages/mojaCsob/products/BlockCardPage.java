package sk.moja.pages.mojaCsob.products;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class BlockCardPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Comment", new Element(byId("comment")));

        elementMap.put("Back", new Element(byId("cardBlock_formFooterCancel")));
        elementMap.put("Sign", new Element(byId("cardBlock_formFooterSign")));
        elementMap.put("Authorization code", new Element(byId("authorizationCode")));
        elementMap.put("Edit", new Element(byId("cardBlock_crontoSignatureCancel")));
        elementMap.put("Submit", new Element(byId("cardBlock_crontoSignatureSubmit")));
        elementMap.put("Show cronto token", new Element(byId("cardBlock_crontoSignatureSwitchToOnlineMode")));
    }
}