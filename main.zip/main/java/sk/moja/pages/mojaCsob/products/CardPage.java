package sk.moja.pages.mojaCsob.products;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class CardPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Cards list", new Element(byXpath("//ib-card-list-item")));
        elementMap.put("Display pin", new Element(byClassName("csob-icon-set-view")));
        elementMap.put("Card detail", new Element(byClassName("csob-icon-set-info-alt")));
        elementMap.put("Show more cards", new Element(byClassName("show-more")));
        elementMap.put("Hide last cards", new Element(byClassName("show-more")));

        elementMap.put("Card limit", new Element(byText("Zmeniť limit")));
        elementMap.put("Internet card limit", new Element(byText("Platba na internete")));
        elementMap.put("Block card", new Element(byClassName("csob-icon-set-card-blocking")));
        elementMap.put("Unblock card", new Element(byClassName("csob-icon-set-card")));
        elementMap.put("Notifications", new Element(byClassName("csob-icon-set-notification")));

        elementMap.put("Card status", new Element(byClassName("card-status")));
        elementMap.put("Card number", new Element(byXpath("//ib-card-number")));
        elementMap.put("Card detail list", new Element(byXpath("//ib-detail-list-item")));
    }
}