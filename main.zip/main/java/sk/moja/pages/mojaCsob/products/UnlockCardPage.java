package sk.moja.pages.mojaCsob.products;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class UnlockCardPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Back", new Element(byId("cardUnblock_formFooterCancel")));
        elementMap.put("Sign", new Element(byId("cardUnblock_formFooterSign")));
        elementMap.put("Authorization code", new Element(byId("authorizationCode")));
        elementMap.put("Edit", new Element(byId("cardUnblock_crontoSignatureCancel")));
        elementMap.put("Submit", new Element(byId("cardUnblock_crontoSignatureSubmit")));
        elementMap.put("Show cronto token", new Element(byId("cardUnblock_crontoSignatureSwitchToOnlineMode")));
    }
}