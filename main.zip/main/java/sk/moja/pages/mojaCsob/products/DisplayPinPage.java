package sk.moja.pages.mojaCsob.products;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class DisplayPinPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Comment", new Element(byId("comment")));

        elementMap.put("Hidden pin", new Element(byClassName("hidden-pin")));
        elementMap.put("Pin", new Element(byXpath("//ib-card-display-pin-timer/div/span/span/img")));

        elementMap.put("Back", new Element(byId("cardDisplayPin_formFooterCancel")));
        elementMap.put("Sign", new Element(byId("cardDisplayPin_formFooterSign")));
        elementMap.put("Authorization code", new Element(byId("authorizationCode")));
        elementMap.put("Edit", new Element(byId("cardDisplayPin_crontoSignatureCancel")));
        elementMap.put("Submit", new Element(byId("cardDisplayPin_crontoSignatureSubmit")));
        elementMap.put("Show cronto token", new Element(byId("cardDisplayPin_crontoSignatureSwitchToOnlineMode")));
    }
}