package sk.moja.pages.mojaCsob.products;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class CardLimitPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Limit", new Element(byId("limit")));

        elementMap.put("Back", new Element(byId("cardChangeLimits_formFooterCancel")));
        elementMap.put("Sign", new Element(byId("cardChangeLimits_formFooterSign")));
        elementMap.put("Authorization code", new Element(byId("authorizationCode")));
        elementMap.put("Edit", new Element(byId("cardChangeLimits_crontoSignatureCancel")));
        elementMap.put("Submit", new Element(byId("cardChangeLimits_crontoSignatureSubmit")));
        elementMap.put("Show cronto token", new Element(byId("cardChangeLimits_crontoSignatureSwitchToOnlineMode")));
    }
}