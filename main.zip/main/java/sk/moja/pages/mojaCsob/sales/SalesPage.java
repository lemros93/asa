package sk.moja.pages.mojaCsob.sales;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class SalesPage {
    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Content", new Element(byClassName("readonly-fader")));
        elementMap.put("Back", new Element(byText("Späť")));
        elementMap.put("Arrange meeting", new Element(byText("Dohodnúť si stretnutie")));
    }
}
