package sk.moja.pages.mojaCsob.sales;

import lombok.Getter;
import sk.moja.elements.CsobDropdown;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class OverdraftPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        //1krok
        elementMap.put("Credit limit", new Element(byId("sliderInput")));
        elementMap.put("Overdraft information", new Element(byXpath("//ib-sales-data-table")));
        //otaznik
        elementMap.put("Continue", new Element(byId("nextStep")));
        elementMap.put("Back", new Element(byId("previousStep")));


        //2krok
        elementMap.put("Name", new Element(byId("name")));
        elementMap.put("Surname", new Element(byId("surname")));
        elementMap.put("Phone", new Element(byId("phone")));
        elementMap.put("Email", new Element(byId("email")));

        //Doplňujúce osobné údaje
        elementMap.put("Family status", new CsobDropdown(byId("maritalStatus")));
        elementMap.put("Ownership without shares",new CsobDropdown(byId("typeOfTenancy")));
        elementMap.put("Number of tenants", new Element(byId("numberOfTenants")));
        elementMap.put("Educations", new CsobDropdown(byId("attainedEducation")));
        elementMap.put("Accommodation type", new CsobDropdown(byId("accommodationType")));
        // otaznik
        elementMap.put("Number of dependent children", new Element(byId("numberOfDependentChildrenLivingInACommonHousehold")));

        //Doplnujuce údaje pre banku
        elementMap.put("Employment type", new CsobDropdown(byId("employmentType")));
        elementMap.put("Employer", new Element(byId("employer")));
        elementMap.put("Employer CRN", new Element(byId("employerCRN")));
        elementMap.put("Work country", new Element(byId("workCountry")));
        elementMap.put("Employer sector", new CsobDropdown(byId("employerSector")));
        elementMap.put("Employer type", new CsobDropdown(byId("employerType")));
        elementMap.put("Worker type", new CsobDropdown(byId("workerType")));
        elementMap.put("Contract", new CsobDropdown(byId("contract")));
        elementMap.put("Current job from month", new CsobDropdown(byId("currentJobFromMonth")));
        elementMap.put("Current job from year", new CsobDropdown(byId("currentJobFromYear")));
        elementMap.put("Notice period", new Element(byAttribute("formcontrolname", "noticePeriod")));
        elementMap.put("Family component as employer", new Element(byAttribute("formcontrolname", "familyComponentAsEmployer")));
        elementMap.put("Income method", new CsobDropdown(byAttribute("formcontrolname", "incomeSendingMethod")));
        elementMap.put("Monthly net income", new Element(byId("monthlyNetIncome")));

        elementMap.put("Yes", new Element(byXpath("//p-togglebutton//*[contains(text(), 'ÁNO')]")));
        elementMap.put("No", new Element(byXpath("//p-togglebutton//*[contains(text(), 'NIE')]")));

        elementMap.put("Total amount SFRB", new Element(byId("totalLoanAmountSFRB")));
        elementMap.put("Mounthly payments SFRB", new Element(byId("monthlyPaymentSFRB")));

        // otaznik
        elementMap.put("Alimony expenses", new Element(byId("alimonyExpenses")));
        // otaznik
        elementMap.put("Amount of depts", new Element(byId("actualAmountOfPendingDebts")));
        // otaznik
        elementMap.put("Limit on  credit card and overdraft", new Element(byId("totalLimitOnCCAndOverdraft")));
        // otaznik
        elementMap.put("Potvrdzujem ze za poslednych 5 rokov ...", new Element(byId("finances.noDebtBankruptInslExec")));
        elementMap.put("Old age pension", new Element(byId("oldAgePension")));
        elementMap.put("Retirement pension", new Element(byId("retirementPension")));
        elementMap.put("Full disability pension", new Element(byId("fullDisabilityPension")));
        elementMap.put("Partial disability pension", new Element(byId("partialDisabilityPension")));
        elementMap.put("Widows pension", new Element(byId("widowsPension")));
        elementMap.put("Parental allowance", new Element(byId("parentalAllowance")));

        //dotaznik
        elementMap.put("Employment status", new CsobDropdown(byAttribute("formcontrolname","currentStatus")));
        elementMap.put("Employment status area", new CsobDropdown(byId("currentStatusArea")));

        elementMap.put("Origin of assets and funds - Income from employment", new Element(byXpath("//input[@id=\"originAssetsAndFunds_INCOME_FROM_EMPLOYMENT\"]/ancestor::label")));
        elementMap.put("Origin of assets and funds - Income from business", new Element(byXpath("//input[@id=\"originAssetsAndFunds_INCOME_FROM_BUSINESS\"]/ancestor::label")));
        elementMap.put("Origin of assets and funds - Savings", new Element(byXpath("//input[@id=\"originAssetsAndFunds_SAVINGS\"]/ancestor::label")));
        elementMap.put("Origin of assets and funds - Gift or heritage", new Element(byXpath("//input[@id=\"originAssetsAndFunds_GIFT_OR_HERITAGE\"]/ancestor::label")));
        elementMap.put("Origin of assets and funds - Social benefits", new Element(byXpath("//input[@id=\"originAssetsAndFunds_SOCIAL_BENEFITS\"]/ancestor::label")));
        elementMap.put("Origin of assets and funds - Maternity allowance", new Element(byXpath("//input[@id=\"originAssetsAndFunds_MATERNITY_ALLOWANCE\"]/ancestor::label")));
        elementMap.put("Origin of assets and funds - Pension or rent", new Element(byXpath("//input[@id=\"originAssetsAndFunds_PENSION_OR_RENT\"]/ancestor::label")));
        elementMap.put("Origin of assets and funds - Scholarship or temporary work or from parents", new Element(byXpath("//input[@id=\"originAssetsAndFunds_SCHOLARSHIP_OR_TEMPORARY_WORK_OR_FROM_PARENTS\"]/ancestor::label")));
        elementMap.put("Origin of assets and funds - Other", new Element(byXpath("//input[@id=\"originAssetsAndFunds_OTHER\"]/ancestor::label")));
        elementMap.put("Origin of assets and funds - Other define origin", new Element(byId("otherOriginAssetsAndFunds")));

        elementMap.put("Account usage purpose - Payroll", new Element(byXpath("//input[@id=\"accountUsagePurpose_PAYROLL\"]/ancestor::label")));
        elementMap.put("Account usage purpose - Financing household expenses", new Element(byXpath("//input[@id=\"accountUsagePurpose_FINANCING_HOUSEHOLD_EXPENSES\"]/ancestor::label")));
        elementMap.put("Account usage purpose - Purchase of goods and services", new Element(byXpath("//input[@id=\"accountUsagePurpose_PURCHASE_OF_GOODS_AND_SERVICES\"]/ancestor::label")));
        elementMap.put("Account usage purpose - Buy building or car", new Element(byXpath("//input[@id=\"accountUsagePurpose_BUY_BUILDING_OR_CAR\"]/ancestor::label")));
        elementMap.put("Account usage purpose - Savings", new Element(byXpath("//input[@id=\"accountUsagePurpose_SAVINGS\"]/ancestor::label")));
        elementMap.put("Account usage purpose - Investment", new Element(byXpath("//input[@id=\"accountUsagePurpose_INVESTMENT\"]/ancestor::label")));
        elementMap.put("Account usage purpose - Other", new Element(byXpath("//input[@id=\"accountUsagePurpose_OTHER\"]/ancestor::label")));
        elementMap.put("Account usage purpose - Other define the purpose", new Element(byId("otherAccountUsagePurpose")));

        elementMap.put("Cash transaction over limit Yes", new Element(byId("cashTransactionOverLimitYes")));
        elementMap.put("Cash transaction over limit No", new Element(byId("cashTransactionOverLimitNo")));
        elementMap.put("Payments risk countries Yes", new Element(byId("paymentsRiskCountriesYes")));
        elementMap.put("Payments risk countries No", new Element(byId("paymentsRiskCountriesNo")));
        elementMap.put("No debt bankrupt insl exec", new Element(byAttribute("selectbuttonformcontrolname", "noDebtBankruptInslExec")));
        elementMap.put("No debt bankrupt insl exec-agree", new Element(byXpath("//p-togglebutton//*[contains(text(), 'Súhlasím')]")));
        elementMap.put("No debt bankrupt insl exec-disagree", new Element(byXpath("//p-togglebutton//*[contains(text(), 'Nesúhlasím')]")));


        //3krok
        elementMap.put("No spec relation to bank", new Element(byXpath("//ib-sales-agreement[@checkboxformcontrolname='noSpecRelToBank']//csob-checkbox//div")));
        elementMap.put("Real data confirmation", new Element(byXpath("//ib-sales-agreement[@checkboxformcontrolname='realDataConfirmation']//csob-checkbox//div")));

        //4krok
        elementMap.put("Special procedures for the conclusion of distance contracts", new Element(byPartialLinkText("Osobitné dojednávania pre uzatváranie zmlúv na diaľku")));
        elementMap.put("Information prior to the conclusion of the financial service", new Element(byPartialLinkText("Informácia pred uzatvorením finančnej služby")));
        elementMap.put("Download client agreement", new Element(byPartialLinkText("Stiahnuť Klientsku zmluvu")));

        elementMap.put("Fee schedule", new Element(byAttribute("formcontrolname", "agreement")));
        elementMap.put("Overdraft conditions", new Element(byXpath("//ib-sales-agreement[@checkboxformcontrolname=\"overdraftConditions\"]/*//csob-checkbox/*//div")));

        elementMap.put("Download documents", new Element(byXpath("//ib-download-icon-button")));

        elementMap.put("Popover warning", new Element(byXpath("//popover-container")));
        elementMap.put("Alert message", new Element(byXpath("//csob-alert")));

        elementMap.put("Sign", new Element(byId("nextStep")));
        elementMap.put("Authorization code", new Element(byId("authorizationCode")));
        elementMap.put("Edit", new Element(byId("overdraftSignPage_crontoSignatureCancel")));
        elementMap.put("Submit", new Element(byId("overdraftSignPage_crontoSignatureSubmit")));
        elementMap.put("Show cronto token", new Element(byId("overdraftSignPage_crontoSignatureSwitchToOnlineMode")));

        elementMap.put("Body", new Element(byClassName("section-body")));
    }
}