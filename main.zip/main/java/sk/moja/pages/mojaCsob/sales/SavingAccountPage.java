package sk.moja.pages.mojaCsob.sales;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class SavingAccountPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        //1krok
        elementMap.put("Vypovedna lehota", new Element(byClassName("build_loan_product_totalDuration")));
        elementMap.put("Interest rate", new Element(byClassName("speed_sales_forms_build_loan_rate_between_value")));
        elementMap.put("Mesacny vklad", new Element(byId("formData.formObject.monthlyPayment")));
        elementMap.put("Dlzka sporenia", new Element(byId("formData.formObject.savingsDuration")));
        elementMap.put("Nasporena suma", new Element(byId("speed-sales-forms-savings-product-saved-amount")));
        elementMap.put("Ucet budem pouzivat aktivne", new Element(byName("formData.formObject.activeUsage")));
        elementMap.put("I am interested", new Element(byId("speed-sales-forms-summary-calculator-greenbutton")));

        //2krok
        elementMap.put("Name", new Element(byName("name")));
        elementMap.put("Surname ", new Element(byName("surname")));
        elementMap.put("Birth date", new Element(byName("birthDate")));
        elementMap.put("Birth number", new Element(byName("birthNumber")));
        elementMap.put("Phone number", new Element(byId("formData.formObject.phoneNumber")));
        elementMap.put("Email", new Element(byId("formData.formObject.email")));
        elementMap.put("Street", new Element(byName("residenceStreet")));
        elementMap.put("Postal code", new Element(byName("residenceZipCode")));
        elementMap.put("City", new Element(byName("residenceCity")));
        elementMap.put("Country", new Element(byName("residenceCountry")));
        elementMap.put("Back", new Element(byValue("Späť")));
        elementMap.put("Continue", new Element(byValue("Pokračovať")));

        //3krok
        elementMap.put("Product type", new Element(byName("productType")));
        elementMap.put("Statement type", new Element(byName("reportFormat")));
        elementMap.put("Statement frequency", new Element(byName("reportDeliveryFrequency")));
        elementMap.put("Statement language", new Element(byName("reportLanguage")));
        elementMap.put("Relation with bank", new Element(byId("formData.formObject.relatedToBank")));

        //4krok
        elementMap.put("Accept client draft agreement", new Element(byName("formData.formObject.signableComponents.acceptSignature")));
        //link
        //link
        //link
        elementMap.put("Sign document", new Element(byId("speed-sales-form-navigation-submit2")));
        elementMap.put("Show cronto token", new Element(byXpath("//ib-cronto-signature/div/div/div/a")));
        elementMap.put("Authorization code", new Element(byName("formData.formObject.signableComponents.authorizationToken")));
        elementMap.put("Submit", new Element(byId("speed-sales-form-navigation-submit2")));
        elementMap.put("Time limit", new Element(byClassName("speed-timeout")));
        elementMap.put("Transaction number", new Element(byClassName("field-note-transaction-number")));

        elementMap.put("Error", new Element(byClassName("common-forms-error-message")));
        elementMap.put("Question mark", new Element(byClassName("speed-common-question")));
        elementMap.put("Help message", new Element(byClassName("speed-common-question-text")));
    }
}