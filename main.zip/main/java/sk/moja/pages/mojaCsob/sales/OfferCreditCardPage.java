package sk.moja.pages.mojaCsob.sales;

import lombok.Getter;
import sk.moja.elements.CsobDropdown;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class OfferCreditCardPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Offer List", new Element(byXpath("//ib-offer-list")));
        elementMap.put("Show more information", new Element(byClassName("show-more")));
        elementMap.put("Show less information", new Element(byClassName("show-more")));
        elementMap.put("Show offer", new Element(byClassName("btn-primary")));

        elementMap.put("Continue", new Element(byId("nextStep")));
        elementMap.put("Back", new Element(byId("previousStep")));
        elementMap.put("Make an appointment", new Element(byText("Dohodnúť stretnutie na pobočke")));

        //1strana
        elementMap.put("Card type", new Element(byXpath("//ib-credit-card-limit-selector")));
        elementMap.put("Loan limit", new Element(byId("sliderInput")));
        elementMap.put("Loan limit slider", new Element(byId("sliderInput")));
        elementMap.put("Help", new Element(byClassName("csob-icon-set-help-alt")));
        elementMap.put("Alert", new Element(byClassName("alert-warning")));

        //2strana
        elementMap.put("Automatic payment", new CsobDropdown(byId("automaticPayment")));
        elementMap.put("Payment account", new CsobDropdown(byId("paymentAccount_paymentProductDropdownId")));
        elementMap.put("Internet payment limit", new Element(byId("internetPaymentLimit")));
        elementMap.put("Internet payment phone number", new Element(byId("phone")));
        elementMap.put("Travel insurance", new CsobDropdown(byId("travelInsurance")));
        elementMap.put("Credit card information", new Element(byXpath("//ib-sales-data-table")));

        //3strana
        elementMap.put("Name", new Element(byId("name")));
        elementMap.put("Surname", new Element(byId("surname")));
        elementMap.put("Phone", new Element(byId("phone")));
        elementMap.put("Email", new Element(byId("email")));

        //adresa
        elementMap.put("Card delivery address type", new CsobDropdown(byAttribute("formcontrolname", "cardDeliveryAddressType")));
        elementMap.put("Street", new Element(byId("cardDeliveryStreet")));
        elementMap.put("House number", new Element(byId("cardDeliveryHouseNumber")));
        elementMap.put("Postal code", new Element(byXpath("//label[@for=\"cardDeliveryZipCode\"]/following-sibling::input")));
        elementMap.put("City", new Element(byXpath("//label[@for=\"cardDeliveryCity\"]/following-sibling::input")));

        //dorucenie pinu
        elementMap.put("Use the same pin as on debit card", new Element(byAttribute("formcontrolname", "pinSameAsCard")));

        //Doplňujúce osobné údaje
        elementMap.put("Marital status", new CsobDropdown(byId("maritalStatus")));
        elementMap.put("Number of tenants", new Element(byId("numberOfTenants")));
        // otaznik
        elementMap.put("Number of dependent children", new Element(byId("numberOfDependentChildrenLivingInACommonHousehold")));
        // otaznik
        elementMap.put("Attained education", new CsobDropdown(byId("attainedEducation")));
        elementMap.put("Accommodation type", new CsobDropdown(byId("accommodationType")));

        //Doplnujuce údaje pre banku
        elementMap.put("Employment type", new CsobDropdown(byId("employmentType")));
        elementMap.put("Employer", new Element(byId("employer")));
        elementMap.put("Work country", new Element(byId("workCountry")));
        elementMap.put("Employer sector", new CsobDropdown(byId("employerSector")));
        elementMap.put("Employer type", new CsobDropdown(byId("employerType")));
        elementMap.put("Worker type", new CsobDropdown(byId("workerType")));
        elementMap.put("Contract", new CsobDropdown(byId("contract")));
        elementMap.put("Current job from month", new CsobDropdown(byId("currentJobFromMonth")));
        elementMap.put("Current job from year", new CsobDropdown(byId("currentJobFromYear")));
        elementMap.put("Notice period", new Element(byAttribute("formcontrolname", "noticePeriod")));
        elementMap.put("Family component as employer", new Element(byAttribute("formcontrolname", "familyComponentAsEmployer")));
        elementMap.put("Monthly net income", new Element(byId("monthlyNetIncome")));
        // otaznik
        elementMap.put("Alimony expenses", new Element(byId("alimonyExpenses")));
        // otaznik
        elementMap.put("Amount of depts", new Element(byId("actualAmountOfPendingDebts")));
        // otaznik
        elementMap.put("Limit on  credit card and overdraft", new Element(byId("totalLimitOnCCAndOverdraft")));
        // otaznik
        elementMap.put("Potvrdzujem ze za poslednych 5 rokov ...", new Element(byId("finances.noDebtBankruptInslExec")));
        elementMap.put("Old age pension", new Element(byId("oldAgePension")));
        elementMap.put("Retirement pension", new Element(byId("retirementPension")));
        elementMap.put("Full disability pension", new Element(byId("fullDisabilityPension")));
        elementMap.put("Partial disability pension", new Element(byId("partialDisabilityPension")));
        elementMap.put("Widows pension", new Element(byId("widowsPension")));
        elementMap.put("Parental allowance", new Element(byId("parentalAllowance")));

        //dotaznik
        elementMap.put("Employment status", new CsobDropdown(byAttribute("formcontrolname","currentStatus")));
        elementMap.put("Employment status area", new CsobDropdown(byId("currentStatusArea")));

        elementMap.put("Origin of assets and funds - Income from employment", new Element(byXpath("//input[@id=\"originAssetsAndFunds_INCOME_FROM_EMPLOYMENT\"]/ancestor::label")));
        elementMap.put("Origin of assets and funds - Income from business", new Element(byXpath("//input[@id=\"originAssetsAndFunds_INCOME_FROM_BUSINESS\"]/ancestor::label")));
        elementMap.put("Origin of assets and funds - Savings", new Element(byXpath("//input[@id=\"originAssetsAndFunds_SAVINGS\"]/ancestor::label")));
        elementMap.put("Origin of assets and funds - Gift or heritage", new Element(byXpath("//input[@id=\"originAssetsAndFunds_GIFT_OR_HERITAGE\"]/ancestor::label")));
        elementMap.put("Origin of assets and funds - Social benefits", new Element(byXpath("//input[@id=\"originAssetsAndFunds_SOCIAL_BENEFITS\"]/ancestor::label")));
        elementMap.put("Origin of assets and funds - Maternity allowance", new Element(byXpath("//input[@id=\"originAssetsAndFunds_MATERNITY_ALLOWANCE\"]/ancestor::label")));
        elementMap.put("Origin of assets and funds - Pension or rent", new Element(byXpath("//input[@id=\"originAssetsAndFunds_PENSION_OR_RENT\"]/ancestor::label")));
        elementMap.put("Origin of assets and funds - Scholarship or temporary work or from parents", new Element(byXpath("//input[@id=\"originAssetsAndFunds_SCHOLARSHIP_OR_TEMPORARY_WORK_OR_FROM_PARENTS\"]/ancestor::label")));
        elementMap.put("Origin of assets and funds - Other", new Element(byXpath("//input[@id=\"originAssetsAndFunds_OTHER\"]/ancestor::label")));
        elementMap.put("Origin of assets and funds - Other define origin", new Element(byId("otherOriginAssetsAndFunds")));

        elementMap.put("Account usage purpose - Payroll", new Element(byXpath("//input[@id=\"accountUsagePurpose_PAYROLL\"]/ancestor::label")));
        elementMap.put("Account usage purpose - Financing household expenses", new Element(byXpath("//input[@id=\"accountUsagePurpose_FINANCING_HOUSEHOLD_EXPENSES\"]/ancestor::label")));
        elementMap.put("Account usage purpose - Purchase of goods and services", new Element(byXpath("//input[@id=\"accountUsagePurpose_PURCHASE_OF_GOODS_AND_SERVICES\"]/ancestor::label")));
        elementMap.put("Account usage purpose - Buy building or car", new Element(byXpath("//input[@id=\"accountUsagePurpose_BUY_BUILDING_OR_CAR\"]/ancestor::label")));
        elementMap.put("Account usage purpose - Savings", new Element(byXpath("//input[@id=\"accountUsagePurpose_SAVINGS\"]/ancestor::label")));
        elementMap.put("Account usage purpose - Investment", new Element(byXpath("//input[@id=\"accountUsagePurpose_INVESTMENT\"]/ancestor::label")));
        elementMap.put("Account usage purpose - Other", new Element(byXpath("//input[@id=\"accountUsagePurpose_OTHER\"]/ancestor::label")));
        elementMap.put("Account usage purpose - Other define the purpose", new Element(byId("otherAccountUsagePurpose")));

        elementMap.put("Cash transaction over limit Yes", new Element(byId("cashTransactionOverLimitYes")));
        elementMap.put("Cash transaction over limit No", new Element(byId("cashTransactionOverLimitNo")));
        elementMap.put("Payments risk countries Yes", new Element(byId("paymentsRiskCountriesYes")));
        elementMap.put("Payments risk countries No", new Element(byId("paymentsRiskCountriesNo")));
        elementMap.put("No debt bankrupt insl exec", new Element(byAttribute("selectbuttonformcontrolname", "noDebtBankruptInslExec")));
        elementMap.put("No debt bankrupt insl exec-agree", new Element(byXpath("//p-togglebutton//*[contains(text(), 'Súhlasím')]")));
        elementMap.put("No debt bankrupt insl exec-disagree", new Element(byXpath("//p-togglebutton//*[contains(text(), 'Nesúhlasím')]")));

        //4strana
        elementMap.put("No spec relation to bank", new Element(byXpath("//ib-sales-agreement[@checkboxformcontrolname=\"noSpecRelToBank\"]/*//csob-checkbox/label/div")));
        elementMap.put("Real data confirmation", new Element(byXpath("//ib-sales-agreement[@checkboxformcontrolname=\"realDataConfirmation\"]/*//csob-checkbox/label/div")));

        //5strana
        elementMap.put("Download draft contract", new Element(byPartialLinkText("Stiahnuť návrh zmluvy")));
        elementMap.put("General terms and conditions", new Element(byPartialLinkText("Všeobecné obchodné podmienky")));
        elementMap.put("Fee schedule", new Element(byPartialLinkText("Sadzobník poplatkov")));
        elementMap.put("Conditions for issuing and using a ČSOB credit card", new Element(byPartialLinkText("Podmienky pre vydanie a používanie ČSOB kreditnej karty")));
        elementMap.put("Insurance information document, information before closing remotely", new Element(byPartialLinkText("Informačný dokument k poisteniu, Informácie pred uzatvorením na diaľku")));
        elementMap.put("Insurance information document and general insurance conditions", new Element(byPartialLinkText("Informačný dokument k poisteniu a Všeobecné poistné podmienky")));
        elementMap.put("Accept standard european information", new Element(byXpath("//ib-sales-agreement[@checkboxformcontrolname=\"acceptStandardEuropeanInformation\"]/*//csob-checkbox/label/div")));
        elementMap.put("Accept Rpmn", new Element(byXpath("//ib-sales-agreement[@checkboxformcontrolname=\"acceptRpmn\"]/*//csob-checkbox/label/div")));
        elementMap.put("Accept application", new Element(byXpath("//ib-sales-agreement[@checkboxformcontrolname=\"acceptApplication\"]/*//csob-checkbox/label/div")));
        elementMap.put("Accept bank insurance", new Element(byXpath("//ib-sales-agreement[@checkboxformcontrolname=\"bankInsurance\"]/*//csob-checkbox/label/div")));
        //elementMap.put("Accept bank insurance", new Element(byAttribute("checkboxformcontrolname", "bankInsurance")));
        elementMap.put("Accept client agreement", new Element(byAttribute("formcontrolname", "agreement")));
        elementMap.put("Popover warning", new Element(byXpath("//popover-container")));


        elementMap.put("Sign", new Element(byId("nextStep")));
        elementMap.put("Authorization code", new Element(byId("authorizationCode")));
        elementMap.put("Edit", new Element(byId("overdraftSignPage_crontoSignatureCancel")));
        elementMap.put("Submit", new Element(byId("overdraftSignPage_crontoSignatureSubmit")));
        elementMap.put("Show cronto token", new Element(byId("overdraftSignPage_crontoSignatureSwitchToOnlineMode")));

        elementMap.put("Body", new Element(byClassName("section-body")));
    }
}