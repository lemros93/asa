package sk.moja.pages.mojaCsob.sales;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class OfferSmartAccounts {
    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Account type", new Element(byClassName("section-body")));

    }
}


