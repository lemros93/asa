package sk.moja.pages.mojaCsob.sales;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.byClassName;
import static com.codeborne.selenide.Selectors.byXpath;

public class MortgageLoanCamundaPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static {
        elementMap.put("KDL container", new Element(byClassName("kdl-container")));
        elementMap.put("Property value", new Element(byXpath("//csob-input-with-slider[@formcontrolname='propertyValue']//input")));
        elementMap.put("Total Amount", new Element(byXpath("//csob-input-with-slider[@formcontrolname='totalAmount']//input")));
        elementMap.put("Repayment period", new Element(byXpath("//csob-input-with-slider[@formcontrolname='repaymentPeriod']//input")));
    }
}
