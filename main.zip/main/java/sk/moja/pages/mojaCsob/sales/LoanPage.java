package sk.moja.pages.mojaCsob.sales;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class LoanPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("KDL container", new Element(byClassName("kdl-container")));

        //1krok
        elementMap.put("Loan amount", new Element(byXpath("//csob-input-with-slider[@formcontrolname='amount']//input")));
        elementMap.put("Maturity in years", new Element(byId("formData.formObject.years")));
        elementMap.put("Insurance", new Element(byId("formData.formObject.insurance")));
        elementMap.put("Drawdown date", new Element(byId("formData.formObject.loanFrom")));
        elementMap.put("Due date of the month", new Element(byId("formData.formObject.paymentDay")));
        elementMap.put("Account number", new Element(byId("formData.formObject.userAccount")));
        elementMap.put("Monthly payment", new Element(byId("speed-sales-forms-monthlyAmount")));
        elementMap.put("Number of installments", new Element(byId("speed-sales-forms-months")));
        elementMap.put("Loan rate", new Element(byId("speed-sales-forms-loanRate")));
        elementMap.put("RPMN", new Element(byId("speed-sales-forms-apr-private")));
        elementMap.put("Processing fee", new Element(byId("speed-sales-forms-processingFee")));
        elementMap.put("Monthly insurance fee", new Element(byId("speed-sales-forms-monthlyInsuranceFee")));
        elementMap.put("Total amount", new Element(byId("speed-sales-forms-priceToPay")));
        elementMap.put("I am interested", new Element(byId("speed-sales-forms-summary-calculator-greenbutton")));

        //2krok
        elementMap.put("Name", new Element(byName("name")));
        elementMap.put("Surname ", new Element(byName("surname")));
        elementMap.put("Birth date", new Element(byName("birthDate")));
        elementMap.put("Birth number", new Element(byName("birthNumber")));
        elementMap.put("Type of identity document", new Element(byName("identityDocStored")));
        elementMap.put("Document number", new Element(byName("documentNumberStored")));
        elementMap.put("Document expiring date", new Element(byName("documentStoredExpiringDate")));
        elementMap.put("Phone number", new Element(byId("formData.formObject.phoneNumber")));
        elementMap.put("Email", new Element(byId("formData.formObject.email")));
        elementMap.put("Street", new Element(byName("residenceStreet")));
        elementMap.put("Postal code", new Element(byName("residenceZipCode")));
        elementMap.put("City", new Element(byName("residenceCity")));
        elementMap.put("Country", new Element(byName("residenceCountry")));
        elementMap.put("Same contact address as residence", new Element(byName("formData.formObject.sameContactAddressAsResidence")));
        elementMap.put("Contact street", new Element(byName("contactStreet")));
        elementMap.put("Contact zip code", new Element(byName("contactZipCode")));
        elementMap.put("Contact city", new Element(byName("contactCity")));
        elementMap.put("Contact country", new Element(byName("contactCountry")));
        elementMap.put("Marital status", new Element(byId("formData.formObject.maritalStatusNPxl")));
        elementMap.put("Number of tenants", new Element(byId("formData.formObject.numberOfHouseholdMembers")));
        elementMap.put("Number of dependent children", new Element(byId("formData.formObject.numberOfDependentChildrenLivingInACommonHousehold")));
        elementMap.put("Attained education", new Element(byId("formData.formObject.studiesLevel")));
        elementMap.put("Accommodation type", new Element(byId("formData.formObject.currentLiving")));
        elementMap.put("Back", new Element(byValue("Späť")));
        elementMap.put("Continue", new Element(byValue("Pokračovať")));

        //3krok
        elementMap.put("Social state", new Element(byId("formData.formObject.socialState")));
        elementMap.put("Employer company id", new Element(byId("formData.formObject.employerCompanyId")));
        elementMap.put("Work country", new Element(byId("formData.formObject.employerActivityCountry")));
        elementMap.put("Employer sector", new Element(byId("formData.formObject.employerSector")));
        elementMap.put("Employer type", new Element(byId("formData.formObject.employerType")));
        elementMap.put("Worker type", new Element(byId("formData.formObject.workerType")));
        elementMap.put("Contract", new Element(byId("formData.formObject.workContract")));
        elementMap.put("Current job from month", new Element(byId("formData.formObject.currentJobFromMonth")));
        elementMap.put("Current job from year", new Element(byId("formData.formObject.currentJobFromYear")));
        elementMap.put("Current job to month", new Element(byId("formData.formObject.currentJobToMonth")));
        elementMap.put("Current job to year", new Element(byId("formData.formObject.currentJobToYear")));
        elementMap.put("Company with family", new Element(byId("formData.formObject.companyWithFamilyComponentAsEmployerB")));
        elementMap.put("Monthly net income", new Element(byId("formData.formObject.monthlyEncomeS")));
        elementMap.put("Other monthly income", new Element(byId("formData.formObject.otherMonthlyEncome")));
        elementMap.put("Alimony expenses", new Element(byId("formData.formObject.monthlyExpenses")));
        elementMap.put("Monthly loan repayments", new Element(byId("formData.formObject.employeeLoanInstallmentAmount")));
        elementMap.put("Overfrafts limits", new Element(byId("formData.formObject.employeeOverdraftAndCreditCardAmount")));
        elementMap.put("Purpose of use of funds", new Element(byId("formData.formObject.loanUsageType")));
        elementMap.put("No debts declaration", new Element(byId("formData.formObject.noDebtsDeclarationB")));
        elementMap.put("Company name", new Element(byId("formData.formObject.userSelfEmployerName")));
        elementMap.put("ICO", new Element(byId("formData.formObject.userSelfEmployerCompanyId")));
        elementMap.put("Country of business", new Element(byId("formData.formObject.userSelfEmployerActivityCountry")));
        elementMap.put("Business area", new Element(byId("formData.formObject.userSelfEmployerSector")));
        elementMap.put("Starting a business from month", new Element(byId("formData.formObject.userSelfEmployerActivityFromMonth")));
        elementMap.put("Starting a business from year", new Element(byId("formData.formObject.userSelfEmployerActivityFromYear")));
        elementMap.put("Type of accounting", new Element(byId("formData.formObject.accountTypeE")));
        elementMap.put("Type of tax return", new Element(byId("formData.formObject.taxReturnTypeE")));
        elementMap.put("Business income", new Element(byId("formData.formObject.businessIncome")));
        elementMap.put("Business expenses", new Element(byId("formData.formObject.businessIncomeExpenses")));
        elementMap.put("Loss for the previous tax period", new Element(byId("formData.formObject.lossForTaxLastYear")));

        //4krok
        elementMap.put("Summary - Type of loan", new Element(byName("typPurpose")));
        elementMap.put("Summary - Loan amount", new Element(byName("price")));
        elementMap.put("Summary - Monthly payment", new Element(byName("wantedMonthlyFee")));
        elementMap.put("Summary - Due date", new Element(byName("loanFrom")));
        elementMap.put("Summary - Account number", new Element(byName("userAccount")));
        elementMap.put("Summary - First payment date", new Element(byName("firstPaymentDate")));
        elementMap.put("Summary - Number of installments", new Element(byName("monthsNumber")));
        elementMap.put("Summary - Insurance", new Element(byName("insurance")));
        elementMap.put("Summary - Monthly insurance fee", new Element(byName("monthlyInsuranceFee")));
        elementMap.put("Summary - Loan rate", new Element(byName("loanRate")));
        elementMap.put("Summary - RPMN", new Element(byName("apr")));
        elementMap.put("Summary - Processing fee", new Element(byName("processingFee")));
        elementMap.put("Summary - Total amount", new Element(byName("priceToPay")));
        elementMap.put("Summary - Statement type", new Element(byName("paymentType")));
        elementMap.put("Summary - Statement frequency", new Element(byName("paymentFrequency")));
        elementMap.put("Summary - Statement language", new Element(byName("paymentLanguage")));
        elementMap.put("Relation with bank", new Element(byName("formData.formObject.relatedToBank")));
        elementMap.put("Data confirmation", new Element(byName("formData.formObject.realDataConfirmation")));
        elementMap.put("I agree with the processing of personal data", new Element(byName("formData.formObject.acceptanceDataTreatment")));

        //5krok
        elementMap.put("Accept client draft agreement", new Element(byName("formData.formObject.signableComponents.acceptSignature")));
        //link
        //link
        //link
        elementMap.put("Sign document", new Element(byName("formData.formObject.signableComponents.acceptSignature")));
        elementMap.put("Show cronto token", new Element(byXpath("//ib-cronto-signature/div/div/div/a")));
        elementMap.put("Autorization code", new Element(byName("formData.formObject.signableComponents.authorizationToken")));
        elementMap.put("Submit", new Element(byId("speed-sales-form-navigation-submit2")));
        elementMap.put("Time limit", new Element(byClassName("speed-timeout")));
        elementMap.put("Transaction number", new Element(byClassName("field-note-transaction-number")));

        elementMap.put("Question mark", new Element(byClassName("speed-common-question")));
        elementMap.put("Help message", new Element(byClassName("speed-common-question-text")));
    }
}