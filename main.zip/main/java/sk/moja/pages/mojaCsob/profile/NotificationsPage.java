package sk.moja.pages.mojaCsob.profile;

import lombok.Getter;
import sk.moja.elements.Element;
import sk.moja.elements.MaiaDropdown;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class NotificationsPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Products", new MaiaDropdown(byAttribute("formcontrolname","selectedItem")));
        elementMap.put("Phone number", new MaiaDropdown(byAttribute("formcontrolname", "phoneNumber")));
        elementMap.put("Phone number-default", new Element(byXpath("//maia-input-select[@formcontrolname=\"phoneNumber\"]/maia-input-group/input")));
        elementMap.put("Email", new MaiaDropdown(byAttribute("formcontrolname", "email")));
        elementMap.put("Email-default", new Element(byXpath("//maia-input-select[@formcontrolname=\"email\"]/maia-input-group/input")));
        elementMap.put("Language", new MaiaDropdown(byAttribute("formcontrolname", "language")));
        elementMap.put("Language-default", new Element(byXpath("//maia-input-select[@formcontrolname=\"language\"]/maia-input-group/input")));
        elementMap.put("Set for all products", new Element(byAttribute("formcontrolname", "allProducts")));
        elementMap.put("Save", new Element(byText("Uložiť zmeny")));

        elementMap.put("Balance", new Element(byId("balance")));
        elementMap.put("Transactions", new Element(byId("transactions")));
        elementMap.put("Statements", new Element(byId("statements")));

        elementMap.put("Amount from", new Element(byAttribute("formcontrolname", "amountFrom")));

        //platba kartou
        elementMap.put("Card transactions - SMS", new Element(byXpath("//csob-notifications-cards-transaction-settings//*/maia-checkbox[@formcontrolname=\"sms\"][1]")));
        elementMap.put("Card transactions - Email", new Element(byXpath("(//csob-notifications-cards-transaction-settings//*/maia-checkbox[@formcontrolname=\"email\"])[1]")));
        elementMap.put("Card transactions - Push", new Element(byXpath("//csob-notifications-cards-transaction-settings//*/maia-checkbox[@formcontrolname=\"push\"][1]")));
        elementMap.put("Debet card", new Element(byAttribute("formcontrolname", "checked")));
        //elementMap.put("Card transactions - Amount", new Element(byXpath("//csob-notifications-card-transaction-settings//*/maia-checkbox[@formcontrolname=\"checked\"]")));

        //transakcie
        elementMap.put("Account transactions - SMS", new Element(byXpath("(//csob-notifications-account-transaction-settings//*/maia-checkbox[@formcontrolname=\"sms\"])[1]")));
        elementMap.put("Account transactions - Email", new Element(byXpath("(//csob-notifications-account-transaction-settings//*/maia-checkbox[@formcontrolname=\"email\"])[1]")));
        elementMap.put("Account transactions - Push", new Element(byXpath("//csob-notifications-account-transaction-settings//*/maia-checkbox[@formcontrolname=\"push\"][1]")));
        elementMap.put("Account transactions - Amounts credit", new Element(byXpath("(//csob-notifications-account-transaction-settings//*/maia-checkbox[@formcontrolname=\"creditTransaction\"])")));
        elementMap.put("Account transactions - Amounts debit", new Element(byXpath("(//csob-notifications-account-transaction-settings//*/maia-checkbox[@formcontrolname=\"debitTransaction\"])")));
        elementMap.put("Unrealized transactions - SMS", new Element(byAttribute("formcontrolname", "sms")));
        elementMap.put("Unrealized transactions - Email", new Element(byAttribute("formcontrolname", "email")));
        elementMap.put("Warning notification message", new Element(byClassName("maia-text")));

        //zostatok
        elementMap.put("Reaching your account balance - SMS", new Element(byXpath("(//csob-notifications-balance-tab//*/maia-checkbox[@formcontrolname=\"sms\"])[1]")));
        elementMap.put("Reaching your account balance - Email", new Element(byXpath("(//csob-notifications-balance-tab//*/maia-checkbox[@formcontrolname=\"email\"])[1]")));
        elementMap.put("Reaching your account balance - Push", new Element(byXpath("//csob-notifications-balance-tab//*/maia-checkbox[@formcontrolname=\"push\"][1]")));
        elementMap.put("Reaching your account balance - Amount from", new Element(byId("amount")));

        elementMap.put("Regular balance of the account balance - SMS", new Element(byXpath("(//maia-checkbox([@formcontrolname=\"sms\"])[3]")));
        elementMap.put("Regular balance of the account balance - Email", new Element(byXpath("(//maia-checkbox([@formcontrolname=\"email\"])[3]")));
        elementMap.put("Regular balance of the account balance - Time", new Element(byId("time")));


        elementMap.put("Regular balance of the account balance - Every day", new Element(byAttribute("formcontrolname", "email")));

        // Note: selectors changed to xpaths, but their content not changed at all - these two elements do not seem to be attributes as defined originally
        elementMap.put("Funds availability - SMS", new Element(byXpath("(//maia-checkbox[@formcontrolname=\"sms\"])[3]")));
        elementMap.put("Funds availability - Email", new Element(byXpath("(//maia-checkbox[@formcontrolname=\"email\"])[3]")));
    }
}