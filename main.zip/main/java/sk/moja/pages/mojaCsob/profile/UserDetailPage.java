package sk.moja.pages.mojaCsob.profile;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class UserDetailPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Name", new Element(byXpath("//div[label[.=\"Meno\"]]")));
        elementMap.put("Surname", new Element(byXpath("//div[label[.=\"Priezvisko\"]]")));
        elementMap.put("Birth date", new Element(byXpath("//div[label[.=\"Dátum narodenia\"]]")));

        //Trvala adresa
        elementMap.put("Street", new Element(byXpath("//ib-user-address[.//h3[contains(text(),'Trvalá adresa')]]//div[@id='street']")));
        elementMap.put("City", new Element(byXpath("//ib-user-address[.//h3[contains(text(),'Trvalá adresa')]]//div[@id='city']")));
        elementMap.put("Zip code", new Element(byXpath("//ib-user-address[.//h3[contains(text(),'Trvalá adresa')]]//div[@id='zipCode']")));
        elementMap.put("Country", new Element(byXpath("//ib-user-address[.//h3[contains(text(),'Trvalá adresa')]]//div[@id='countryDesc']")));

        //Korenspondencna adresa
        elementMap.put("Correspondence street", new Element(byXpath("//ib-user-address[.//h3[contains(text(),'Korešpondenčná adresa')]]//div[@id='street']")));
        elementMap.put("Correspondence city", new Element(byXpath("//ib-user-address[.//h3[contains(text(),'Korešpondenčná adresa')]]//div[@id='city']")));
        elementMap.put("Correspondence zip code", new Element(byXpath("//ib-user-address[.//h3[contains(text(),'Korešpondenčná adresa')]]//div[@id='zipCode']")));
        elementMap.put("Correspondence country", new Element(byXpath("//ib-user-address[.//h3[contains(text(),'Korešpondenčná adresa')]]//div[@id='countryDesc']")));

        elementMap.put("Email", new Element(byId("email")));
        elementMap.put("Phone number", new Element(byId("phoneNumber")));

        elementMap.put("Privacy - marketing", new Element(byXpath("//div[label[.=\"Marketingové aktivity\"]]")));
        elementMap.put("Privacy - consumer", new Element(byXpath("//div[label[.=\"Spotrebiteľské súťaže\"]]")));

        elementMap.put("Edit data", new Element(byText("Upraviť údaje")));
    }
}