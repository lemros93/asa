package sk.moja.pages.mojaCsob.profile;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class ContractsPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Document detail", new Element(byClassName("document-detail")));
        elementMap.put("Download PDF", new Element(byClassName("csob-icon-set-download")));

        elementMap.put("Left arrow", new Element(byClassName("csob-icon-set-keyboard-arrow-left-alt2")));
        elementMap.put("Right arrow", new Element(byClassName("csob-icon-set-keyboard-arrow-right-alt2")));
        elementMap.put("Paging", new Element(byXpath("//csob-paging")));
        elementMap.put("Page size", new Element(byClassName("csob-table-item-container")));
    }
}