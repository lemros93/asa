package sk.moja.pages.mojaCsob.profile;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class ProductOrderPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Cancel", new Element(byText("Zrušiť zmenu")));
        elementMap.put("Save", new Element(byText("Uložiť poradie")));
    }
}