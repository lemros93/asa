package sk.moja.pages.mojaCsob.profile;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class AvokaAmendmentsPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Accept cookies", new Element(byClassName("cookie-management-accept")));
        elementMap.put("Reject cookies", new Element(byClassName("cookie-management-deny")));
        elementMap.put("Edit cookies", new Element(byClassName("cookie-management-edit")));
        elementMap.put("Content", new Element(byClassName("content-wrapper")));

        elementMap.put("Privacy settings", new Element(byClassName("list-item-content")));
        elementMap.put("Marketing txt origin", new Element(byClassName("id-consentsMarketingTxt")));
        elementMap.put("Consumer txt origin", new Element(byClassName("id-consentsCompetitionTxt")));
        elementMap.put("Marketing txt", new Element(byClassName("id-finalConsentsMarketingText")));
        elementMap.put("Consumer txt", new Element(byClassName("id-finalConsentsCompetitionsText")));


        elementMap.put("Marketing activities", new Element(byXpath("(//maia-checkbox[@formcontrolname=\"marketingConsent\"])")));
        elementMap.put("Consumer competitions", new Element(byXpath("//maia-checkbox[@formcontrolname=\"competitionConsent\"]")));

        elementMap.put("Continue", new Element(byText("Pokračovať")));
        elementMap.put("remove and continue", new Element(byText("Áno, odobrať")));
        elementMap.put("Send", new Element(byText("Potvrdiť a odoslať")));

        elementMap.put("My accounts", new Element(byText("Pokračovať na Moje produkty")));
    }
}