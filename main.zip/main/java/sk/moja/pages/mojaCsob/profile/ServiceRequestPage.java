package sk.moja.pages.mojaCsob.profile;

import lombok.Getter;
import sk.moja.elements.Element;
import sk.moja.elements.MaiaDropdown;
import sk.moja.elements.MaiaSlider;
import sk.moja.elements.MultipleSelectionMaiaDropdown;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class ServiceRequestPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Service type", new MaiaDropdown(byAttribute("formcontrolname", "type")));
        elementMap.put("Info", new Element(byXpath("//maia-form-group")));
        elementMap.put("Continue", new Element(byText("Pokračovať")));
        elementMap.put("Continue EN", new Element(byText("Continue")));
        elementMap.put("Branch", new Element(byXpath("//maia-form-group/p/a")));
        elementMap.put("More information", new Element(byXpath("//maia-form-group//*/span/a")));
        elementMap.put("Validate", new Element(byXpath("//maia-validation-container")));
        elementMap.put("Content", new Element(byClassName("content-wrapper")));

        elementMap.put("Product type", new MaiaDropdown(byAttribute("formcontrolname", "subcategory")));
        elementMap.put("Product", new MaiaDropdown(byAttribute("formcontrolname", "product")));
        elementMap.put("Product dropdown", new Element(byXpath("//maia-select-options//maia-option")));
        elementMap.put("Product change", new MaiaDropdown(byAttribute("formcontrolname", "subSubcategory")));
        elementMap.put("New credit limit", new MaiaSlider(byClassName("maia-text")));
        elementMap.put("Unpack", new Element(byClassName("maia-backdrop--transparent")));
        elementMap.put("Title", new Element(byXpath("//maia-page-layout//*/h2")));

        //žiadosť o podnikateľský úver
        elementMap.put("Company and IBAN", new MaiaDropdown(byAttribute("data-testid", "businessCredit_accountProduct")));
        elementMap.put("Purpose of the loan", new MultipleSelectionMaiaDropdown(byXpath("//input[@data-testid='businessCredit_businessCreditPurpose']")));
        elementMap.put("Loan amount", new Element(byAttribute("formcontrolname", "amountInput")));
        elementMap.put("Loan amount slider", new MaiaSlider(byAttribute("formcontrolname","amountInput")));
        elementMap.put("Authorized person", new Element(byAttribute("formcontrolname", "eligiblePersonName")));
        elementMap.put("Phone number", new Element(byAttribute("formcontrolname", "eligiblePersonPhoneNumber")));
        elementMap.put("Note", new Element(byAttribute("formcontrolname", "additionalInfo")));

        //žiadosť o webpay
        elementMap.put("Warning", new Element(byClassName("maia-contextual-message--warning")));
        elementMap.put("Confirmation", new Element(byAttribute("data-testid", "webpayOverview_confirmation_ck")));
        elementMap.put("Device Type", new Element(byAttribute("data-testid", "webpayOverviewStep1_deviceType")));
        elementMap.put("Expect Monthly Turnover", new Element(byAttribute("data-testid", "webpayOverviewStep1_expectedMonthlyTurnover")));
        elementMap.put("Expect Monthly Note", new Element(byAttribute("data-testid", "webpayOverviewStep1_expectedMonthlyTurnover_note")));
        elementMap.put("Average Transaction Amount", new Element(byAttribute("data-testid", "webpayOverviewStep1_averageTransactionAmount")));
        elementMap.put("Average Amount Note", new Element(byAttribute("data-testid", "webpayOverviewStep1_averageTransactionAmount_note")));
        elementMap.put("Webpay Business Area", new MaiaDropdown(byAttribute("data-testid", "webpayOverviewStep1_businessArea")));
        elementMap.put("Web page", new Element(byAttribute("data-testid", "webpayOverviewStep1_webPage")));
        elementMap.put("Statement email", new Element(byAttribute("data-testid", "webpayOverviewStep1_statementEmail")));
        elementMap.put("Web page note", new Element(byAttribute("data-testid", "webpayOverviewStep1_webPage_note")));

        //spoločné s pos terminálom
        elementMap.put("Business Account", new MaiaDropdown(byAttribute("data-testid", "webpayOverview_businessAccount")));
        elementMap.put("Business Account Note", new MaiaDropdown(byAttribute("data-testid", "webpayOverview_businessAccount_note")));
        elementMap.put("Company name", new Element(byAttribute("data-testid", "webpayOverview_companyName")));
        elementMap.put("Eligible Person", new Element(byAttribute("formcontrolname", "eligiblePerson")));
        elementMap.put("Eligible Person Note", new Element(byAttribute("data-testid", "webpayOverview_eligiblePerson_note")));
        elementMap.put("Eligible Person Type", new Element(byAttribute("formcontrolname", "eligiblePersonType")));
        elementMap.put("Eligible Person Type Note", new Element(byAttribute("data-testid", "webpayOverview_eligiblePersonType_note")));
        elementMap.put("Eligible Person Phone", new Element(byAttribute("data-testid", "webpayOverview_eligiblePersonPhone")));
        elementMap.put("Eligible Person Email", new Element(byAttribute("data-testid", "webpayOverview_eligiblePersonEmail")));
        elementMap.put("Description", new Element(byAttribute("data-testid", "webpayOverview_clientDescription")));
        elementMap.put("Description Note", new Element(byAttribute("data-testid", "webpayOverview_clientDescription_note")));
        elementMap.put("Statutory true", new Element(byAttribute("data-testid", "webpayOverview_statutory_true")));
        elementMap.put("Statutory false", new Element(byAttribute("data-testid", "webpayOverview_statutory_false")));
        elementMap.put("Conclude a contract", new Element(byAttribute("data-testid", "webpayOverviewSummary_btn_submit")));
        elementMap.put("Go to page", new Element(byAttribute("data-testid", "webpayOverview_btn_techParameters")));
        elementMap.put("Minimum monthly fee", new Element(byXpath("//div[contains(@class, 'package-data-column')]//div[.//span[normalize-space()='Minimálny mesačný poplatok']]")));
        elementMap.put("Flat rate fee", new Element(byXpath("//div[contains(@class, 'package-data-column')]//div[.//span[normalize-space()='Paušálny poplatok']]")));
        elementMap.put("Connection fee", new Element(byXpath("//div[contains(@class, 'package-data-column')]//div[.//span[normalize-space()='Poplatok za GPRS pripojenie']]")));
        elementMap.put("Regulated cards", new Element(byXpath("//div[contains(@class, 'package-data-column')]//div[.//span[normalize-space()='Regulované karty']]")));
        elementMap.put("Unregulated cards", new Element(byXpath("//div[contains(@class, 'package-data-column')]//div[.//span[normalize-space()='Neregulované karty']]")));

        elementMap.put("Installation street", new Element(byAttribute("formcontrolname", "installationAddressStreet")));
        elementMap.put("Installation city", new Element(byAttribute("formcontrolname", "installationAddressCity")));
        elementMap.put("Installation zip", new Element(byAttribute("formcontrolname", "installationAddressZip")));
        elementMap.put("Previous payments", new Element(byAttribute("formcontrolname", "previousPayments")));

        //akceptačný/verifikačný dotazník & uploadID
        elementMap.put("Current status", new MaiaDropdown(byId("currentStatus")));
        elementMap.put("Business area", new MaiaDropdown(byId("currentStatusArea")));
        elementMap.put("Finance source", new MultipleSelectionMaiaDropdown(byXpath("//input[@id='originAssetsAndFunds']")));
        elementMap.put("Purpose of banking products", new MultipleSelectionMaiaDropdown(byXpath("//input[@id='accountUsagePurpose']")));
        elementMap.put("Foreigners products reasons", new MultipleSelectionMaiaDropdown(byXpath("//input[@id='foreignersProductsReason']")));
        elementMap.put("Cash deposits no", new Element(byId("cashTransactionOverLimitFalse")));
        elementMap.put("Cash deposits yes", new Element(byId("cashTransactionOverLimitTrue")));
        elementMap.put("Payments Risk Countries no", new Element(byId("paymentsRiskCountriesFalse")));
        elementMap.put("Payments Risk Countries yes", new Element(byId("paymentsRiskCountriesTrue")));
        elementMap.put("SK", new Element(byAttribute("data-testid", "serviceRequest_lngToogle_SK")));
        elementMap.put("EN", new Element(byAttribute("data-testid", "serviceRequest_lngToogle_EN")));
        elementMap.put("ID Card", new Element(byAttribute("data-testid", "serviceRequest_idTypeToogle_SK")));
        elementMap.put("Passport", new Element(byAttribute("data-testid", "serviceRequest_idTypeToogle_EN")));

        //žiadosť o podnikateľský účet
        elementMap.put("Company number", new Element(byAttribute("formcontrolname", "companyNumber")));
        elementMap.put("Name of company", new Element(byAttribute("formcontrolname", "companyName")));
        elementMap.put("Email", new Element(byAttribute("formcontrolname", "email")));
        elementMap.put("Phone", new Element(byAttribute("formcontrolname", "phone")));
        elementMap.put("Error", new Element(byXpath("//maia-validation")));
        elementMap.put("Same address true", new Element(byId("isCorrespondenceAddressSameTrue")));
        elementMap.put("Same address false", new Element(byId("isCorrespondenceAddressSameFalse")));
        elementMap.put("Correspondence address", new Element(byAttribute("formcontrolname", "correspondenceAddress")));
        elementMap.put("Purpose account", new MultipleSelectionMaiaDropdown(byXpath("//input[@id='accountUsagePurpose']")));
        elementMap.put("Current status area", new MaiaDropdown(byId("currentStatusArea")));
        elementMap.put("Football activity true", new Element(byId("footballClubActivityTrue")));
        elementMap.put("Football activity false", new Element(byId("footballClubActivityFalse")));
        elementMap.put("Import export true", new Element(byId("importExportOverTrue")));
        elementMap.put("Import export false", new Element(byId("importExportOverFalse")));
        elementMap.put("Money transfer true", new Element(byId("moneyTransferServiceTrue")));
        elementMap.put("Money transfer false", new Element(byId("moneyTransferServiceFalse")));
        elementMap.put("Crypto trading true", new Element(byId("cryptoTradingTrue")));
        elementMap.put("Crypto trading false", new Element(byId("cryptoTradingFalse")));
        elementMap.put("ATM Operations true", new Element(byId("atmOperationsTrue")));
        elementMap.put("ATM Operations false", new Element(byId("atmOperationsFalse")));
        elementMap.put("Cash transaction over limit true", new Element(byId("cashTransactionOverLimitTrue")));
        elementMap.put("Cash transaction over limit false", new Element(byId("cashTransactionOverLimitFalse")));
        elementMap.put("Risk countries true", new Element(byId("paymentsRiskCountriesTrue")));
        elementMap.put("Risk countries false", new Element(byId("paymentsRiskCountriesFalse")));
        elementMap.put("Origin of funds", new MultipleSelectionMaiaDropdown(byXpath("//input[@id='originAssetsAndFunds']")));
        elementMap.put("Ownership changes true", new Element(byId("ownershipChangesLastTwoYearsTrue")));
        elementMap.put("Ownership changes false", new Element(byId("ownershipChangesLastTwoYearsFalse")));
        elementMap.put("Electronic sign", new Element(byId("KEP")));
        elementMap.put("Branch sign", new Element(byId("BRANCH")));
        elementMap.put("Office", new MaiaDropdown(byId("branch_input")));
        elementMap.put("Tooltip", new Element(byXpath("//maia-tooltip-message")));
        elementMap.put("Tooltip content", new Element(byXpath("//maia-tooltip-content")));

        elementMap.put("Complaint description", new Element(byAttribute("formcontrolname", "clientDescription")));
        elementMap.put("Notice", new Element(byClassName("maia-content")));
        elementMap.put("Expiration ID warning", new Element(byXpath("//maia-pop-up//*[contains(text(), 'občiansky preukaz')]")));

        //žiadosť o POS/platobný terminál
        elementMap.put("POS Business area", new MaiaDropdown(byAttribute("formcontrolname", "businessArea")));
        elementMap.put("Custom Business area", new MaiaDropdown(byAttribute("formcontrolname", "customBusinessArea")));
        elementMap.put("Interier", new Element(byAttribute("data-testid", "outdoorSuitabilityNode_interior")));
        elementMap.put("Exterier", new Element(byAttribute("data-testid", "outdoorSuitabilityNode_exterior")));
        elementMap.put("Android Yes", new Element(byAttribute("data-testid", "ownDeviceNode_ownDevice")));
        elementMap.put("Android No", new Element(byAttribute("data-testid", "ownDeviceNode_nonOwnDevice")));
        elementMap.put("Ekasa Yes", new Element(byAttribute("data-testid", "cashRegisterConnectedNode_cashRegisterConnected")));
        elementMap.put("Ekasa Yes2", new Element(byAttribute("data-testid", "cashRegisterAvailabilityNode_cashRegisterAvailable")));
        elementMap.put("Gastro Yes", new Element(byAttribute("data-testid", "businessGastroNode_businessGastro")));
        elementMap.put("Ekasa No", new Element(byAttribute("data-testid", "cashRegisterConnectedNode_cashRegisterNotConnected")));
        elementMap.put("Ekasa No2", new Element(byAttribute("data-testid", "cashRegisterAvailabilityNode_cashRegisterUnavailable")));
        elementMap.put("Gastro No", new Element(byAttribute("data-testid", "businessGastroNode_notBusinessGastro")));
        elementMap.put("Portable", new Element(byAttribute("data-testid", "mobilityTypeNode_mobile")));
        elementMap.put("Non-transferable", new Element(byAttribute("data-testid", "mobilityTypeNode_stationary")));
        elementMap.put("Cash system", new Element(byAttribute("data-testid", "monthlySalesNode_cashSystem")));
        elementMap.put("Do not know", new Element(byXpath("//maia-checkbox")));
        elementMap.put("Monthly Turnover", new Element(byAttribute("formcontrolname", "expectedMonthlyPosTurnover")));
        elementMap.put("Approximate Monthly Turnover", new Element(byAttribute("formcontrolname", "expectedMonthlyTurnover")));
        elementMap.put("POS Average Transaction Amount", new Element(byAttribute("formcontrolname", "averageTransactionAmount")));
        elementMap.put("Branch name", new Element(byAttribute("formcontrolname", "branchName")));
        elementMap.put("Branch address", new Element(byAttribute("formcontrolname","installationAddress")));
        elementMap.put("Branch contact person", new Element(byAttribute("formcontrolname", "contactPerson")));
        elementMap.put("Branch contact phone", new Element(byAttribute("formcontrolname", "contactPhone")));
        elementMap.put("Branch contact mail", new Element(byAttribute("formcontrolname", "statementEmail")));
        elementMap.put("POS password", new Element(byAttribute("formcontrolname", "activationEmailPassword")));
        elementMap.put("POS send", new Element(byAttribute("data-testid", "posStepSummary_btn_submit")));
        elementMap.put("POS - Resume - Name", new Element(byXpath("//*[@data-testid='posStep3_businessAccount.owner']/span[@class='text-normal']")));
        elementMap.put("POS - Resume - IBAN", new Element(byXpath("//*[@data-testid='posStep3_businessAccount.productNumberAliasToDisplay']/span[@class='text-normal']")));
        elementMap.put("POS - Resume - Activity", new Element(byXpath("//*[@data-testid='posStep3_posHelperFormValue.businessArea.area']/span[@class='text-normal']")));
        elementMap.put("POS - Resume - Branch Name", new Element(byXpath("//*[@data-testid='posStep3_branchName']/span[@class='text-normal']")));
        elementMap.put("POS - Resume - Address", new Element(byXpath("//*[@data-testid='posStep3_installationAddress']/span[@class='text-normal']")));
        elementMap.put("POS - Resume - Device Type", new Element(byXpath("//*[@data-testid='posStep3_selectedTerminal.title']/span[@class='text-normal']")));
        elementMap.put("Card acceptance agreement", new Element(byXpath("//maia-tile-document-sign[@data-testid='posStepSummary_ib.serviceRequests.pos.stepSummary.document1.url']/..")));
        elementMap.put("Fee schedule", new Element(byXpath("//maia-tile-document-sign[@data-testid='posStepSummary_ib.serviceRequests.pos.stepSummary.document2.url']/..")));
        elementMap.put("Conditions for accepting payment cards", new Element(byXpath("//maia-tile-document-sign[@data-testid='posStepSummary_ib.serviceRequests.pos.stepSummary.document3.url']/..")));

        //žiadosť o prenos účtu
        elementMap.put("IBAN of another bank", new Element(byAttribute("formcontrolname", "iban")));
        elementMap.put("Change data", new Element(byAttribute("maiaminibuttontheme", "info")));
        elementMap.put("Set up online", new Element(byAttribute("maiaminibuttontheme", "warning")));
        elementMap.put("Account dropdown", new MaiaDropdown(byAttribute("formcontrolname", "account")));
        elementMap.put("Account", new Element(byXpath("//maia-input-select[@formcontrolname='account']//maia-input-group//input")));

        elementMap.put("Pop up", new Element(byId("maia-pop-up")));
        elementMap.put("Repayment reason", new MaiaDropdown(byAttribute("formcontrolname", "repaymentReason")));
        elementMap.put("Origin of finance", new MaiaDropdown(byAttribute("formcontrolname", "fundsOrigin")));

        elementMap.put("Date", new Element(byXpath("//maia-input-date[@formcontrolname='date']//input")));
        elementMap.put("Datepicker", new Element(byXpath("//maia-input-date[@formcontrolname='date']//button")));
        elementMap.put("Day", new Element(byClassName("maia-day")));
        elementMap.put("Year", new Element(byClassName("maia-year")));
        elementMap.put("Month", new Element(byClassName("maia-month")));

        //upload ID
        elementMap.put("Street", new Element(byAttribute("formcontrolname", "street")));
        elementMap.put("Street number", new Element(byAttribute("formcontrolname", "streetNumber")));
        elementMap.put("Additional address", new Element(byAttribute("formcontrolname", "additionalAddress")));
        elementMap.put("Zip code", new Element(byAttribute("formcontrolname", "zipCode")));
        elementMap.put("City", new Element(byAttribute("formcontrolname", "city")));
        elementMap.put("Country", new MaiaDropdown(byAttribute("formcontrolname","country")));

        //splatenie úveru, energetický certifikát
        elementMap.put("Type of loan product", new MaiaDropdown((byAttribute("formcontrolname", "productType"))));
        elementMap.put("Type of loan product-default", new Element(byAttribute("formcontrolname", "productType")));
        elementMap.put("Credit product", new MaiaDropdown((byAttribute("formcontrolname", "product"))));
        elementMap.put("Amount", new Element(byAttribute("formcontrolname", "amount")));
        elementMap.put("Extraordinary payment", new MaiaDropdown((byAttribute("formcontrolname", "repaymentPurpose"))));
        elementMap.put("Repayment date", new Element(byXpath("//maia-input-date[@formcontrolname='repaymentDate']/maia-input-group//input")));
        elementMap.put("Checkbox", new Element(byXpath("//maia-checkbox")));
        elementMap.put("Checkbox no", new Element(byId("loanBalanceCalculationFalse")));
        elementMap.put("Checkbox yes", new Element(byId("loanBalanceCalculationTrue")));
        elementMap.put("Call me", new Element(byXpath("//button[contains(.,'Zavolajte mi')]")));
        elementMap.put("Continue request", new Element(byXpath("//button[contains(.,'požiadavke')]")));
        elementMap.put("Dialog content", new Element(byXpath("//section[@role='dialog']")));

        //energetický certifikát
        elementMap.put("Upload", new Element(byXpath("//plain-shared-service-request-file-picker/maia-input-group//input")));
        elementMap.put("Pattern", new Element(byXpath("//plain-shared-service-request-file-picker/a")));
        elementMap.put("Trash", new Element(byXpath("//maia-input-group[@class=\"file-chosen ng-star-inserted\"]//div[3]")));

        elementMap.put("Next", new Element(byText("Ďalej")));
        elementMap.put("Submit", new Element(byText("Odoslať žiadosť")));
        elementMap.put("Sign online", new Element(byText("Uzatvoriť Zmluvu online")));
        elementMap.put("Confirm repayment", new Element(byText("Potvrdiť splatenie")));
        elementMap.put("Continue repayment", new Element(byText("Pokračovať v splatení")));
        elementMap.put("Send", new Element(byText("Odoslať")));
        elementMap.put("Submit EN", new Element(byText("Submit")));
        elementMap.put("Back", new Element(byText("Späť")));
        elementMap.put("Finish", new Element(byText("Dokončiť")));
        elementMap.put("Preview", new Element(byXpath("//form/*//button[@maiabuttontype='secondary']")));
        elementMap.put("POS preview", new Element(byXpath("//csob-section/*//button[@maiabuttontype='secondary']")));

        //Zrušenie debetnej karty
        elementMap.put("Card type", new Element(byXpath("//div[text()='Názov karty']/following-sibling::div[@class='service-request-card-data-value']")));
        elementMap.put("Card status", new Element(byXpath("//div[text()='Stav karty']/following-sibling::div[@class='service-request-card-data-value']")));
        elementMap.put("Card number", new Element(byXpath("//div[text()='Číslo karty']/following-sibling::div[@class='service-request-card-data-value']")));
        elementMap.put("Card holder", new Element(byXpath("//div[text()='Držiteľ karty']/following-sibling::div[@class='service-request-card-data-value']")));
        elementMap.put("Card expiry date", new Element(byXpath("//div[@class='service-request-card-image-expiry']")));


        elementMap.put("Thank you page", new Element(byClassName("notification")));
        elementMap.put("Close Request", new Element(byText("Zatvoriť")));
        elementMap.put("Close warning modal", new Element(byXpath("//*[text()='Zatvoriť' and @class='maia-button--primary ng-star-inserted']")));
    }
}