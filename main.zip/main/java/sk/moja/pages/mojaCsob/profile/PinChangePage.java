package sk.moja.pages.mojaCsob.profile;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class PinChangePage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Old pin", new Element(byId("password")));
        elementMap.put("New pin", new Element(byId("password-new")));
        elementMap.put("New pin confirm", new Element(byId("password-confirm")));

        elementMap.put("Back", new Element(byText("Spať")));
        elementMap.put("Sign", new Element(byId("signButton")));
        elementMap.put("Autorization code", new Element(byId("authorizationCode")));
        elementMap.put("Edit", new Element(byId("pinChangePage_crontoSignatureCancel")));
        elementMap.put("Submit", new Element(byClassName("submitPinButton")));

        elementMap.put("Pin message", new Element(byText("Váš PIN kód bol úspešne zmenený.")));
        elementMap.put("Continue changes", new Element(byId("modalBtn")));

        elementMap.put("Show cronto token", new Element(byXpath("//ib-cronto-signature/div/div/div/a")));
    }
}