package sk.moja.pages.mojaCsob;

import lombok.Getter;
import org.openqa.selenium.By;
import sk.moja.elements.Element;

import java.util.List;
import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;
import static java.util.Arrays.asList;

public class DashboardPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();
    @Getter
    private static final TreeMap<String, List<By>> combinedElementsMap = new TreeMap<>();

    static{
        elementMap.put("Dashboard name", new Element(byXpath("//div/a/h3")));
        combinedElementsMap.put("Products List", asList(
                byXpath("//ib-product-list-item"),
                byXpath("//ib-dashboard-default"),
                byClassName("product-label"),
                byClassName("cdk-drag")));
        elementMap.put("Payment", new Element(byClassName("csob-icon-set-payment")));
        elementMap.put("Card repayment", new Element(byClassName("csob-icon-set-card-repay")));
        elementMap.put("Transactions", new Element(byClassName("csob-icon-set-history")));

        elementMap.put("Carousel", new Element(byXpath("//p-carousel")));
        elementMap.put("Carousel products list", new Element(byXpath("//*[contains(@class, 'p-carousel-item') and not(contains(@class, 'p-carousel-item-cloned'))]")));
        elementMap.put("Carousel left", new Element(byXpath("//*[contains(@class, 'p-carousel-prev')]")));
        elementMap.put("Carousel right", new Element(byXpath("//*[contains(@class, 'p-carousel-next')]")));
        elementMap.put("Consumer loan", new Element(byText("Spotrebný úver")));
        elementMap.put("PPU", new Element(byXpath("//ib-offer-point-carousel-item//h3[text()='nPXLPovolené prečerpanie účtu']/../following-sibling::div//*[text()='Zistiť viac']")));
        elementMap.put("Credit card", new Element(byXpath("//ib-offer-point-carousel-item//h3[text()='nPXL Kreditná karta']/../following-sibling::div//*[text()='Zistiť viac']")));
        elementMap.put("Consumer loan field", new Element(byXpath("//h3[text()=\"Spotrebný úver\"]")));
        elementMap.put("Consumer loan in progress field", new Element(byXpath("//h3[text()=\"Máte rozpracovanú žiadosť o spotrebný úver\"]")));
        elementMap.put("Offer", new Element(byXpath("//a[@class=\"btn btn-primary\" and contains(@href, \"consumerloan\")]")));
        elementMap.put("Offer in progress", new Element(byXpath("//button[@class=\"btn btn-primary\" and text()=\"Dokončiť žiadosť\"]")));

        elementMap.put("Product Info", new Element(byClassName("product-label")));
        elementMap.put("Iban", new Element(byXpath("//ib-iban")));

        elementMap.put("Reorder accounts", new Element(byText("Zmeniť poradie účtov")));
        elementMap.put("Confirm reorder", new Element(byText("Uložiť poradie")));

        elementMap.put("More products", new Element(byId("productList_collapseList_additionalItems")));
        elementMap.put("Hide latest products", new Element(byText("Skryť posledné produkty")));

        elementMap.put("Waiting transactions", new Element(byText("Čakajúce platby")));
        elementMap.put("Waiting transactions list", new Element(byXpath("//ib-timeline-waiting-transaction")));
        elementMap.put("Held transactions", new Element(byText("Blokované platby")));
        elementMap.put("Held transactions list", new Element(byXpath("//ib-timeline-held-transaction")));
        elementMap.put("Processed transactions list", new Element(byXpath("//ib-timeline-processed-transaction")));

        elementMap.put("Cancel", new Element(byClassName("csob-icon-set-trash-alt")));
        elementMap.put("Postpay", new Element(byClassName("csob-icon-set-payment-back")));
        elementMap.put("Repeat", new Element(byClassName("csob-icon-set-payment-repeat")));
        elementMap.put("Detail platby v Pdf", new Element(byClassName("csob-icon-set-export")));
        elementMap.put("Vytvorit platobnu sablonu", new Element(byClassName("csob-icon-set-templates")));
        elementMap.put("Create a standing order", new Element(byClassName("csob-icon-set-standing-order")));

        elementMap.put("Dashboard alert", new Element(byXpath("//csob-alert")));
        elementMap.put("Navigation back", new Element(byId("navigation-back-button")));
    }

    public static Element getCarouselButtonByItemName(String carouselItemName) {
        return new Element(
          byXpath(
              "//h3[normalize-space()='" + carouselItemName + "']/ancestor::*[" +
              "contains(concat(' ', normalize-space(@class), ' '), ' p-carousel-item ')" +
              "and contains(concat(' ', normalize-space(@class), ' '), ' p-carousel-item-active ')" +
              "and not(contains(concat(' ', normalize-space(@class), ' '), ' p-carousel-item-clone '))]" +
              "//a[@class='btn']"));
    }
}