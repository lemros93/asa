package sk.moja.pages.mojaCsob.mini_loan;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class MiniLoanPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Back icon", new Element(byXpath("//div[@class='icon-button-text no-highlight']")));

        elementMap.put("Title text mini loan", new Element(byXpath("(//h3[contains(text(), 'Miniúver s 0 % úrokom')])[1]")));
        elementMap.put("Mini loan find out more", new Element(byXpath("(//a[contains(@href, 'miniloan')])[1]")));

        elementMap.put("Complete loan", new Element(byXpath("//button[@type='button' and text()='Dokončiť žiadosť']")));
        elementMap.put("Continue in process loan", new Element(byXpath("(//a[contains(@href, 'spotrebny-uver') and text()='Pokračuj'])[1]")));

        elementMap.put("Loan amount", new Element(byId("loanAmount")));
        elementMap.put("Number of installments", new Element(byXpath("//*[@class='text-display av-optional id-numberOfInstalmentsValue align-top csob-loan-summary-table-row-value-97205 col-xs-4 col-sm-4 col-md-4 col-lg-4 av-item-container ng-binding']")));
    }
}