package sk.moja.pages.mojaCsob;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;
import static com.codeborne.selenide.Selectors.byXpath;

public class OfferpointPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("I am interested", new Element(byText("Mám záujem")));
        elementMap.put("Increase limit", new Element(byText("Navýšiť limit")));
        elementMap.put("Recalculate loan", new Element(byText("Prepočítať úver")));
        elementMap.put("View offer", new Element(byText("Zobraziť ponuku")));
        elementMap.put("Next", new Element(byXpath("//ib-basic-footer//button[text()='Pokračovať']")));
        elementMap.put("Automatic payment selection", new Element(byXpath("(//csob-dropdown//*[text()='Vyberte z možností'])[01]")));
        elementMap.put("Selection 5%", new Element(byXpath("//ul//*[text()='5 %,  minimálne 15 EUR']")));
        elementMap.put("Select installment account", new Element(byXpath("(//csob-dropdown//*[text()='Vyberte z možností'])[01]")));
        elementMap.put("Account dropdown", new Element(byXpath("//csob-dropdown//*[text()='Vyberte účet']")));
        elementMap.put("Iban", new Element(byXpath("//ib-iban")));
        elementMap.put("Offer list", new Element(byXpath("//ib-offer-point-list")));
        elementMap.put("Offerpoint item", new Element(byXpath("//ib-offer-point-item")));

        //Smart account
        elementMap.put("Smart account", new Element(byXpath("//ib-smart-account-compare-benefit-block[@key='savingsInterestRate' and @accounttype='smart']/following-sibling::button[normalize-space()='Vybrať']")));
        elementMap.put("Smart plus account", new Element(byXpath("//ib-smart-account-compare-benefit-block[@key='savingsInterestRate' and @accounttype='smartPlus']/following-sibling::button[normalize-space()='Vybrať']")));
        elementMap.put("Smart premium account", new Element(byXpath("//ib-smart-account-compare-benefit-block[@key='savingsInterestRate' and @accounttype='smartPremium']/following-sibling::button[normalize-space()='Vybrať']")));
    }
}