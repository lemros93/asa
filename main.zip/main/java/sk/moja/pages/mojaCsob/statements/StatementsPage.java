package sk.moja.pages.mojaCsob.statements;

import lombok.Getter;
import sk.moja.elements.CsobDropdown;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class StatementsPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Product", new CsobDropdown(byAttribute("formcontrolname", "selectedItem")));
        elementMap.put("Frequency", new CsobDropdown(byAttribute("formcontrolname", "frequency")));
        elementMap.put("Language", new CsobDropdown(byAttribute("formcontrolname", "language")));
        elementMap.put("PDF", new Element(byAttribute("formcontrolname", "formatPdf")));
        elementMap.put("XML", new Element(byAttribute("formcontrolname", "formatXml")));
        elementMap.put("Accounts", new Element(byXpath("(//*[contains(@class, 'csob-dropdown-items-wrapper')]//ul)[1]//li")));

        elementMap.put("Account Statement", new Element(byXpath("//ib-product-dropdown-item/div/div/ib-iban")));
        elementMap.put("Frequency statements", new Element(byXpath("//ib-transactional-statements-settings-table-row/div/div/div")));

        elementMap.put("Warning", new Element(byClassName("text-danger")));
        elementMap.put("Checked mail", new Element(byClassName("input-switch")));
        elementMap.put("Statement product list", new Element(byXpath("//ib-statement-product-list-item")));
        elementMap.put("All products", new Element(byText("Zobraziť všetky produkty")));
        elementMap.put("Hide products", new Element(byText("Skryť ďalšie produkty")));

        elementMap.put("Forwarding account statements", new Element(byClassName("email-statements-disabled-message")));
        elementMap.put("Forward to email", new Element(byXpath("//p-inputswitch")));
        elementMap.put("Info message", new Element(byClassName("content")));
        elementMap.put("Email setting", new Element(byAttribute("inputid", "email")));

        elementMap.put("Password", new Element(byId("password")));
        elementMap.put("Save settings", new Element(byId("nextStep")));

        elementMap.put("Sign", new Element(byId("_formFooterSign")));
        elementMap.put("Back", new Element(byId("_formFooterCancel")));

        elementMap.put("Left arrow", new Element(byClassName("csob-icon-set-keyboard-arrow-left-alt2")));
        elementMap.put("Right arrow", new Element(byClassName("csob-icon-set-keyboard-arrow-right-alt2")));
        elementMap.put("Paging", new Element(byXpath("//csob-paging")));
        elementMap.put("Page size", new Element(byClassName("csob-table-item-container")));
        elementMap.put("Show cronto token", new Element(byXpath("//ib-cronto-signature/div/div/div/a")));
    }
}