package sk.moja.pages.mojaCsob.statements;

import lombok.Getter;
import sk.moja.elements.CsobDropdown;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class DealsPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Filter", new Element(byClassName("csob-icon-set-filter")));
        elementMap.put("From date", new Element(byId("dateFilter_fromDate")));
        elementMap.put("To date", new Element(byId("dateFilter_toDate")));
        elementMap.put("Filter Type", new CsobDropdown(byId("dealsFilter_dealType")));
        elementMap.put("Filter Status", new CsobDropdown(byId("dealsFilter_dealStatus")));
        elementMap.put("Filter submit", new Element(byText("Filtrovať")));
        elementMap.put("Close", new Element(byClassName("close-text")));
        elementMap.put("close filter", new Element(byClassName("close-text")));
        elementMap.put("cancel filter", new Element(byText("Zrušiť filter")));
        elementMap.put("is filtered", new Element(byClassName("text-muted")));

        elementMap.put("Deals list", new Element(byXpath("//ib-deals-table-row")));
        elementMap.put("Deals", new Element(byXpath("//csob-data-view")));
        elementMap.put("Detail", new Element(byClassName("csob-icon-set-info-alt")));
        elementMap.put("Sign deal", new Element(byClassName("csob-icon-set-sign-order")));
        elementMap.put("Type", new Element(byXpath("//ib-deals-table-row//*/div[@class='col-xs-12 col-md-4']")));

        elementMap.put("Left arrow", new Element(byClassName("csob-icon-set-keyboard-arrow-left-alt2")));
        elementMap.put("Right arrow", new Element(byClassName("csob-icon-set-keyboard-arrow-right-alt2")));
        elementMap.put("Paging", new Element(byXpath("//csob-paging")));
        elementMap.put("Page size", new Element(byClassName("csob-table-item-container")));
        elementMap.put("Show cronto token", new Element(byXpath("//ib-cronto-signature/div/div/div/a")));

        elementMap.put("Alert", new Element(byXpath("//csob-alert")));
    }
}