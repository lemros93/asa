package sk.moja.pages.mojaCsob.statements;

import lombok.Getter;
import sk.moja.elements.CsobDropdown;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class StatementsListPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Transactional statements", new Element(byText("Výpisy z účtov")));
        elementMap.put("Fee statements", new Element(byText("Výpisy poplatkov")));
        elementMap.put("Create transactional statement", new Element(byText("Vytvoriť šablónu výpisu")));
        elementMap.put("Statement setting", new Element(byText("Nastavenia výpisov")));

        elementMap.put("Transactional statements settings list", new Element(byXpath("//ib-transactional-statements-settings-table-row")));
        elementMap.put("Edit statement", new Element(byClassName("csob-icon-set-edit")));
        elementMap.put("Remove statement", new Element(byClassName("csob-icon-set-trash-alt")));

        elementMap.put("Filter", new Element(byClassName("csob-icon-set-filter")));
        elementMap.put("Date from", new Element(byId("transactionalStatementFilter_dateFrom")));
        elementMap.put("Date to", new Element(byId("transactionalStatementFilter_dateTo")));
        elementMap.put("Frequency", new CsobDropdown(byId("frequency")));
        elementMap.put("Filter submit", new Element(byText("Filtrovať")));
        elementMap.put("Close", new Element(byText("Zavrieť")));
        elementMap.put("Download", new Element(byClassName("csob-icon-set-document-download")));
        
        elementMap.put("Left arrow", new Element(byClassName("csob-icon-set-keyboard-arrow-left-alt2")));
        elementMap.put("Right arrow", new Element(byClassName("csob-icon-set-keyboard-arrow-right-alt2")));
        elementMap.put("Paging", new Element(byXpath("//csob-paging")));
        elementMap.put("Page size", new Element(byClassName("csob-table-item-container")));
        elementMap.put("Statements list", new Element(byXpath("//ib-transactional-statement-table-row")));
    }
}