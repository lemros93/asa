package sk.moja.pages.mojaCsob.statements;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class DealsDetailPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Trade", new Element(byXpath("//ib-detail-list/ib-detail-list-item/span")));

        elementMap.put("Document history", new Element(byXpath("//ib-deal-detail-documents-history-table-row")));
        elementMap.put("Download", new Element(byClassName("csob-icon-set-export")));

        elementMap.put("Back", new Element(byText("Späť")));
        elementMap.put("Reject", new Element(byId("reject")));
        elementMap.put("Reject reason", new Element(byId("rejectionReason")));
        elementMap.put("Sign", new Element(byId("signButton")));
        elementMap.put("Checkbox indicator", new Element(byClassName("indicator")));

        elementMap.put("Continue here", new Element(byId("dealDetailPage_crontoSignatureSwitchToOnlineMode")));
        elementMap.put("Edit fmci", new Element(byId("dealDetailPage_crontoSignatureCancel")));
        elementMap.put("virtual token", new Element(byId("authorizationCode")));
        elementMap.put("submit", new Element(byText("Odoslať")));
    }
}