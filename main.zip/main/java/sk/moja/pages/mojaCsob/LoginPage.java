package sk.moja.pages.mojaCsob;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class LoginPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        //first factor
        elementMap.put("Ippid", new Element(byId("username")));
        elementMap.put("Pin", new Element(byId("passwordInput")));
        elementMap.put("Login", new Element(byId("kc-login")));
        elementMap.put("Overlay error", new Element(byClassName("kc-feedback-text")));
        elementMap.put("Pin error", new Element(byId("password-error")));
        elementMap.put("Ippid error", new Element(byId("username-error")));

        elementMap.put("Client", new Element(byName("client")));
        elementMap.put("Prospect", new Element(byName("prospect")));
        elementMap.put("Phone number1", new Element(byName("username")));
        elementMap.put("Overlay Error", new Element(byClassName("overlay-error")));

        elementMap.put("Forgot the pin", new Element(byText("Zabudol som PIN / Generovať nový PIN")));
        elementMap.put("Unable to log in", new Element(byText("Nedarí sa vám prihlásiť?")));
        elementMap.put("Safety recommendations", new Element(byText("Bezpečnostné odporúčania")));

        //second factor
        elementMap.put("Token redirect", new Element(byXpath("//*[contains(@class, 'text-lighter')]//a")));
        elementMap.put("Token", new Element(byId("smart-token")));
        elementMap.put("Confirm", new Element(byId("token-submit")));

        //second factor popup
        elementMap.put("Popup - checkbox", new Element(byId("btn-token-submit")));
        elementMap.put("Popup - continue", new Element(byAttribute("type", "submit")));
        elementMap.put("Popup - how does login work", new Element(byClassName("modal-additional-msg-link")));

        elementMap.put("Show cronto token2", new Element(byXpath(".//div[@class='smart-token-label']/div[@class='row smart-token-plus style-small-text']/span[@class='link']")));
    }
}