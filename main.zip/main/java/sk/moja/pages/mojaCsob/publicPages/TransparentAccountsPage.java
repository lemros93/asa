package sk.moja.pages.mojaCsob.publicPages;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.byClassName;
import static com.codeborne.selenide.Selectors.byXpath;

public class TransparentAccountsPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static {

        // Transparent accounts list
        elementMap.put("Transparent accounts - title", new Element(byClassName("title")));

        // Transparent account detail
        elementMap.put("TA detail - back button", new Element(byXpath("//*[@id='navigation-back-button']//*[text()='Späť']")));
        elementMap.put("TA detail - info - transparent account name", new Element(byClassName("name")));
        elementMap.put("TA detail - info - transparent account IBAN", new Element(byClassName("iban-wrapper")));

        elementMap.put("TA detail - transactions - all", new Element(byXpath("//p-togglebutton//*[text()='Všetky']")));
        elementMap.put("TA detail - transactions - outcomes", new Element(byXpath("//p-togglebutton//*[text()='Odoslané']")));
        elementMap.put("TA detail - transactions - incomes", new Element(byXpath("//p-togglebutton//*[text()='Prijaté']")));

        elementMap.put("TA detail - transactions - all - is selected", new Element(byXpath("//p-togglebutton[@aria-pressed='true']//*[text()='Všetky']")));
        elementMap.put("TA detail - transactions - outcomes - is selected", new Element(byXpath("//p-togglebutton[@aria-pressed='true']//*[text()='Odoslané']")));
        elementMap.put("TA detail - transactions - incomes - is selected", new Element(byXpath("//p-togglebutton[@aria-pressed='true']//*[text()='Prijaté']")));

        elementMap.put("TA detail - transactions - date from", new Element(byXpath("(//input[contains(@aria-describedby,'maia-input-date')])[1]")));
        elementMap.put("TA detail - transactions - date to", new Element(byXpath("(//input[contains(@aria-describedby,'maia-input-date')])[2]")));
        elementMap.put("TA detail - transactions - date from - validation error text", new Element(byXpath("(//maia-validation[@type='error'])[1]//*[contains(text(), 'Vyberte dátum v správnom tvare.')]")));
        elementMap.put("TA detail - transactions - date to - validation error text", new Element(byXpath("(//maia-validation[@type='error'])[2]//*[contains(text(), 'Vyberte dátum v správnom tvare.')]")));

        elementMap.put("TA detail - transactions - cancel", new Element(byXpath("//button[text()='Zrušiť']")));
        elementMap.put("TA detail - transactions - filter", new Element(byXpath("//button[text()='Filtrovať']")));

        elementMap.put("TA detail - transactions - collection of displayed dates", new Element(byXpath("//*[contains(@class, 'transaction-date')]//span[last()]")));
        elementMap.put("TA detail - transactions - collection of displayed amounts", new Element(byXpath("//*[contains(@class, 'amount-value')]")));
        elementMap.put("TA detail - paging - button next enabled", new Element(byXpath("//button[contains(@class, 'paginator-next') and not(contains(@class, 'p-disabled'))]")));
    }
}
