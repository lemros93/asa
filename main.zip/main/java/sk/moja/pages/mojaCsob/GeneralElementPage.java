package sk.moja.pages.mojaCsob;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class GeneralElementPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Error message", new Element(byClassName("alert-danger")));
        elementMap.put("Error message - Back", new Element(byClassName("dismiss")));
        elementMap.put("Success message", new Element(byClassName("alert-success")));
        elementMap.put("Modal content", new Element(byClassName("modal-content")));
        elementMap.put("Modal accept", new Element(byXpath("//div[@class='modal-content']//*/button[contains(.,'Rozumiem')]")));
        elementMap.put("Info message", new Element(byClassName("alert-content")));
        elementMap.put("Popover message", new Element(byXpath("//popover-container")));
        elementMap.put("Popover", new Element(byClassName("popover-content")));

        elementMap.put("Datepicker", new Element(byXpath("//csob-datepicker")));
        elementMap.put("Day", new Element(byXpath("//*[@bsdatepickerdaydecorator]")));
        elementMap.put("Previous", new Element(byClassName("previous")));
        elementMap.put("Next", new Element(byClassName("next")));
        elementMap.put("Month", new Element(byXpath("//bs-datepicker-navigation-view/")));
        elementMap.put("Year", new Element(byXpath("//bs-datepicker-navigation-view/")));

        elementMap.put("Cookies", new Element(byClassName("cookie-management-modal-dialog")));
        elementMap.put("Accept cookies", new Element(byClassName("cookie-management-accept")));
        elementMap.put("Edit cookies", new Element(byClassName("cookie-management-edit")));
        elementMap.put("Decline cookies", new Element(byClassName("cookie-management-deny")));
        elementMap.put("Cookies detail", new Element(byClassName("cookie-management-modal-content")));
        elementMap.put("Cookies body", new Element(byClassName("cookie-management-modal-body-input")));
        elementMap.put("switch cookies", new Element(byClassName("cookie-management-switch-input")));
        elementMap.put("Technical cookies", new Element(byClassName("cookie-management-input-technical")));
        elementMap.put("Analytics cookies", new Element(byClassName("cookie-management-input-analytics")));
        elementMap.put("Marketing cookies", new Element(byClassName("cookie-management-input-marketing")));
        elementMap.put("Confirm cookies", new Element(byClassName("cookie-management-modal-action-button")));
        elementMap.put("Understand", new Element(byClassName("modal-footer")));

        elementMap.put("Duplicate payment - Continue", new Element(byXpath("//csob-confirm-modal/*//button[.='Pokračovať']")));
        elementMap.put("Warning message", new Element(byXpath("//csob-confirm-modal")));
        elementMap.put("Duplicate payment - Cancel", new Element(byXpath("//csob-confirm-modal/*//button[.='Zrušiť']")));
        elementMap.put("Duplicate payment", new Element(byClassName("modal-content")));

    }
}