package sk.moja.pages.mojaCsob.templates;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class SepaPaymentConnectionPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Name", new Element(byId("sepaConnectionDetail_name")));
        elementMap.put("Enter the original format", new Element(byText("Zadať pôvodný formát")));
        elementMap.put("Enter IBAN", new Element(byText("Zadať IBAN")));
        elementMap.put("Receiver IBAN", new Element(byId("sepaConnectionDetail__receiverIban")));
        elementMap.put("Receiver prefix number", new Element(byId("sepaConnectionDetail_bban_prefixNumber")));
        elementMap.put("Receiver account number", new Element(byId("sepaConnectionDetail_bban_accountNumber")));
        elementMap.put("Beneficary name", new Element(byId("sepaConnectionDetail_beneficiaryName")));

        elementMap.put("Discard changes", new Element(byClassName("delete-data-hint")));

        elementMap.put("Back", new Element(byId("_formFooterCancel")));
        elementMap.put("Sign", new Element(byId("_formFooterSign")));
    }
}