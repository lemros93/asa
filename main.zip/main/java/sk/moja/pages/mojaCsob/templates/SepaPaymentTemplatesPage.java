package sk.moja.pages.mojaCsob.templates;

import lombok.Getter;
import sk.moja.elements.CsobDropdown;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class SepaPaymentTemplatesPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Name", new Element(byId("sepaTemplateDetail_name")));
        elementMap.put("Payer", new CsobDropdown(byId("sepaTemplateDetail_paymentProductDropdownId")));
        elementMap.put("Receiver", new CsobDropdown(byId("sepaTemplateDetail_receiverDropdown")));
        elementMap.put("Enter the original format", new Element(byText("Zadať pôvodný formát")));
        elementMap.put("Enter IBAN", new Element(byText("Zadať IBAN")));
        elementMap.put("Receiver IBAN", new Element(byId("sepaTemplateDetail_receiverIban")));
        elementMap.put("Receiver prefix number", new Element(byId("sepaTemplateDetail_bban_prefixNumber")));
        elementMap.put("Receiver account number", new Element(byId("sepaTemplateDetail_bban_accountNumber")));

        elementMap.put("Amount", new Element(byId("sepaTemplateDetail_amount")));
        elementMap.put("Message", new Element(byId("sepaTemplateDetail_message")));
        elementMap.put("Due date", new CsobDropdown(byAttribute("formcontrolname", "dueDay")));

        elementMap.put("Discard changes", new Element(byClassName("delete-data-hint")));

        elementMap.put("More payment details", new Element(byXpath("//ib-sepa-payment-advanced-details/div/div/div/csob-collapse/a")));
        elementMap.put("Hide payment details", new Element(byXpath("//ib-sepa-payment-advanced-details/div/div/div/csob-collapse/a")));

        elementMap.put("Variable symbol", new Element(byId("sepaTemplateDetail_variableSymbol")));
        elementMap.put("Specific symbol", new Element(byId("sepaTemplateDetail_specificSymbol")));
        elementMap.put("Constant symbol", new Element(byId("sepaTemplateDetail_constantSymbol")));
        elementMap.put("Payer reference", new Element(byId("sepaTemplateDetail_payersReference")));
        elementMap.put("Beneficary name", new Element(byId("sepaTemplateDetail_beneficiaryName")));

        elementMap.put("Street", new Element(byId("sepaTemplateDetail_street")));
        elementMap.put("House number", new Element(byId("sepaTemplateDetail_houseNumber")));
        elementMap.put("City", new Element(byId("sepaTemplateDetail_city")));
        elementMap.put("Zip code", new Element(byId("sepaTemplateDetail_zipCode")));
        elementMap.put("Country", new CsobDropdown(byId("sepaTemplateDetail_country")));

        elementMap.put("Sign", new Element(byId("_formFooterSign")));
        elementMap.put("Back", new Element(byId("_formFooterCancel")));
    }
}