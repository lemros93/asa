package sk.moja.pages.mojaCsob.templates;

import lombok.Getter;
import sk.moja.elements.CsobDropdown;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class BulkSepaPaymentTemplatePage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Name", new Element(byId("sepaTemplateDetail_name")));
        elementMap.put("Payer", new CsobDropdown(byId("bulkSepaPaymentTemplate_paymentProductDropdownId")));
        elementMap.put("Receiver", new CsobDropdown(byId("bulkSepaPaymentTemplate_receiverDropdown")));
        elementMap.put("Enter the original format", new Element(byText("Zadať pôvodný formát")));
        elementMap.put("Enter IBAN", new Element(byText("Zadať IBAN")));
        elementMap.put("Receiver IBAN", new Element(byId("bulkSepaPaymentTemplate_receiverIban")));
        elementMap.put("Receiver prefix number", new Element(byId("bulkSepaPaymentTemplate_bban_prefixNumber")));
        elementMap.put("Receiver account number", new Element(byId("bulkSepaPaymentTemplate_bban_accountNumber")));
        elementMap.put("Amount", new Element(byId("bulkSepaPaymentTemplate_amount")));
        elementMap.put("Message", new Element(byId("bulkSepaPaymentTemplate_message")));

        elementMap.put("Discard changes", new Element(byClassName("delete-data-hint")));

        elementMap.put("Variable symbol", new Element(byId("bulkSepaPaymentTemplate_variableSymbol")));
        elementMap.put("Specific symbol", new Element(byId("bulkSepaPaymentTemplate_specificSymbol")));
        elementMap.put("Constant symbol", new Element(byId("bulkSepaPaymentTemplate_constantSymbol")));
        elementMap.put("Variable symbol 1st row", new Element(byId("bulkSepaPaymentTemplate_1_variableSymbol")));
        elementMap.put("Specific symbol 1st row", new Element(byId("bulkSepaPaymentTemplate_1_specificSymbol")));
        elementMap.put("Constant symbol 1st row", new Element(byId("bulkSepaPaymentTemplate_1_constantSymbol")));
        elementMap.put("Variable symbol 7th row", new Element(byId("bulkSepaPaymentTemplate_7_variableSymbol")));
        elementMap.put("Specific symbol 7th row", new Element(byId("bulkSepaPaymentTemplate_7_specificSymbol")));
        elementMap.put("Constant symbol 7th row", new Element(byId("bulkSepaPaymentTemplate_7_constantSymbol")));
        elementMap.put("Payer reference", new Element(byId("bulkSepaPaymentTemplate_payersReference")));
        elementMap.put("Beneficary name", new Element(byId("bulkSepaPaymentTemplate_beneficiaryName")));

        elementMap.put("Street", new Element(byId("sepaPayment_street")));
        elementMap.put("House number", new Element(byId("sepaPayment_houseNumber")));
        elementMap.put("City", new Element(byId("sepaPayment_city")));
        elementMap.put("Zip code", new Element(byId("sepaPayment_zipCode")));
        elementMap.put("Country", new CsobDropdown(byId("sepaPayment_country")));

        elementMap.put("Add a payment", new Element(byClassName("csob-icon-set-add-alt")));
        elementMap.put("Cancel payment", new Element(byClassName("csob-icon-set-remove-alt")));

        elementMap.put("Total amount", new Element(byId("bulkSepaPaymentTemplate_totalAmount")));
        elementMap.put("Due date", new CsobDropdown(byId("dueDay")));

        elementMap.put("Sign", new Element(byId("_formFooterSign")));
        elementMap.put("Back", new Element(byId("_formFooterCancel")));
    }
}