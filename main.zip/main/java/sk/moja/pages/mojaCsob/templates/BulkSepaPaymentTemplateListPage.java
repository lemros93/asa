package sk.moja.pages.mojaCsob.templates;

import lombok.Getter;
import org.openqa.selenium.By;
import sk.moja.elements.Element;

import java.util.List;
import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;
import static java.util.Arrays.asList;

public class BulkSepaPaymentTemplateListPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();
    @Getter
    private static final TreeMap<String, List<By>> combinedElementsMap = new TreeMap<>();

    static{
        elementMap.put("Sepa payment templates", new Element(byId("sepaPaymentTemplateList")));
        elementMap.put("Bulk sepa payment templates", new Element(byId("bulkSepaPaymentTemplateList")));
        elementMap.put("Foreign payment templates", new Element(byId("foreignPaymentTemplateList")));

        elementMap.put("Enter a search term", new Element(byId("searchInput")));
        elementMap.put("Advanced search", new Element(byClassName("show-more")));
        elementMap.put("Create a template", new Element(byText("Vytvoriť šablónu")));

        combinedElementsMap.put("List of templates", asList(
                byXpath("//ib-bulk-sepa-payment-template-table-row"),
                byXpath("//ib-bulk-sepa-payment-template-table"),
                byClassName("message")));
        elementMap.put("Edit template", new Element(byClassName("csob-icon-set-edit")));
        elementMap.put("Remove template", new Element(byClassName("csob-icon-set-trash-alt")));
        elementMap.put("Payment", new Element(byClassName("csob-icon-set-payment")));

        elementMap.put("Left arrow", new Element(byClassName("csob-icon-set-keyboard-arrow-left-alt2")));
        elementMap.put("Right arrow", new Element(byClassName("csob-icon-set-keyboard-arrow-right-alt2")));
        elementMap.put("Paging", new Element(byXpath("//csob-paging")));
        elementMap.put("Page size", new Element(byClassName("csob-table-item-container")));
    }
}