package sk.moja.pages.mojaCsob.templates;

import lombok.Getter;
import sk.moja.elements.CsobDropdown;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class ForeignPaymentTemplatesPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Name", new Element(byId("foreignTemplateDetail_name")));
        elementMap.put("Payer reference", new Element(byId("foreignTemplateDetail_payersReference")));
        elementMap.put("Receiver IBAN", new Element(byId("foreignTemplateDetail_accountNumber_iban")));
        elementMap.put("Amount", new Element(byId("foreignTemplateDetail_amount")));
        elementMap.put("Currency", new CsobDropdown(byAttribute("formcontrolname", "currency")));
        elementMap.put("Message", new Element(byId("foreignTemplateDetail_message")));
        elementMap.put("Due date", new CsobDropdown(byAttribute("formcontrolname", "dueDay")));
        elementMap.put("Bic", new Element(byId("foreignTemplateDetail_bic")));
        elementMap.put("Receiver name", new Element(byId("foreignTemplateDetailname")));
        elementMap.put("Street", new Element(byId("foreignTemplateDetail_street")));
        elementMap.put("House number", new Element(byId("foreignTemplateDetail_houseNumber")));
        elementMap.put("City", new Element(byId("foreignTemplateDetail_city")));
        elementMap.put("Zip code", new Element(byId("foreignTemplateDetail_zipCode")));
        elementMap.put("Country", new CsobDropdown(byId("foreignTemplateDetail_country")));
        elementMap.put("Type of expenses", new CsobDropdown(byId("foreignTemplateDetail_typeOfExpenses")));
        elementMap.put("Further instructions for the bank", new Element(byText("Ďalšie inštrukcie pre banku")));
        elementMap.put("Info for bank", new Element(byId("foreignTemplateDetail_infoForBank")));

        elementMap.put("Discard changes", new Element(byClassName("delete-data-hint")));

        elementMap.put("Sign", new Element(byId("_formFooterSign")));
        elementMap.put("Back", new Element(byId("_formFooterCancel")));
    }
}