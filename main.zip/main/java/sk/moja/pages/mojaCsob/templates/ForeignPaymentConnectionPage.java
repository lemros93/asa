package sk.moja.pages.mojaCsob.templates;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class ForeignPaymentConnectionPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Name", new Element(byId("foreignConnectionDetail_name")));
        elementMap.put("Receiver IBAN", new Element(byId("foreignConnectionDetail_accountNumber_iban")));
        elementMap.put("Bic", new Element(byId("foreignConnectionDetail_bic")));
        elementMap.put("Receiver bank address 1", new Element(byId("foreignConnectionDetail_receiverBankAddress1")));
        elementMap.put("Receiver bank address 2", new Element(byId("foreignConnectionDetail_receiverBankAddress2")));
        elementMap.put("Receiver bank address 3", new Element(byId("foreignConnectionDetail_receiverBankAddress3")));
        elementMap.put("Receiver address 1", new Element(byId("foreignConnectionDetail_receiverAddress1")));
        elementMap.put("Receiver address 2", new Element(byId("foreignConnectionDetail_receiverAddress2")));
        elementMap.put("Receiver address 3", new Element(byId("foreignConnectionDetail_receiverAddress3")));
        elementMap.put("Receiver address 4", new Element(byId("foreignConnectionDetail_receiverAddress4")));

        elementMap.put("Sign", new Element(byId("_formFooterSign")));
        elementMap.put("Back", new Element(byId("_formFooterCancel")));

        elementMap.put("Discard changes", new Element(byClassName("delete-data-hint")));
    }
}