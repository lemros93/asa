package sk.moja.pages.mojaCsob;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class HeaderPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Logout", new Element(byText("Odhlásiť")));
        elementMap.put("Logo", new Element(byClassName("csob-logo")));
        elementMap.put("Top menu", new Element(byXpath("//ib-main-menu")));
        elementMap.put("My products", new Element(byText("Moje produkty")));
        elementMap.put("Payments and transactions", new Element(byText("Platby a výpisy")));
        elementMap.put("New payment", new Element(byText("Nová platba")));
        elementMap.put("Online products", new Element(byXpath("//p-megamenu/*//li//*[contains(text(), 'Online produkty')]")));
        elementMap.put("Settings", new Element(byText("Nastavenia")));
        elementMap.put("My profile", new Element(byText("Môj profil")));
        elementMap.put("Change PIN", new Element(byClassName("p-menuitem-text")));

        elementMap.put("Individual clients", new Element(byText("Individuálni klienti")));
        elementMap.put("Companies", new Element(byText("Podnikatelia a Firmy")));
        elementMap.put("Private banking", new Element(byText("Privátne bankovníctvo")));
        elementMap.put("Moja CSOB", new Element(byText("Moja ČSOB")));
        elementMap.put("Contact us", new Element(byText("Napíšte nám")));

        elementMap.put("My offers", new Element(byXpath("//p-megamenu/*//li//*[contains(text(), 'Moje ponuky')]")));
        elementMap.put("Top menu- consumer loan", new Element(byXpath("//p-megamenu/*//li//*[contains(text(), 'Spotrebný úver')]")));
        elementMap.put("Top menu- loan refinanc", new Element(byXpath("//p-megamenu/*//li//*[contains(text(), 'Refinancovanie úverov')]")));
        elementMap.put("Top menu- credit card", new Element(byXpath("//p-megamenu/*//li//*[contains(text(), 'Kreditná karta')]")));
        elementMap.put("Top menu- overdraft", new Element(byXpath("//p-megamenu/*//li//*[contains(text(), 'Povolené prečerpanie bežného účtu')]")));
        elementMap.put("Top menu- mortgage loan", new Element(byXpath("//p-megamenu/*//li//*[contains(text(), 'Hypotekárny úver')]")));

    }
}