package sk.moja.pages.mojaCsob.consumer_loan;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class ConsumerLoanPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("KDL container", new Element(byClassName("kdl-container")));
        elementMap.put("Loan amount", new Element(byXpath("//csob-input-with-slider[@formcontrolname='amount']//input")));
        

    }
}