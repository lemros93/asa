package sk.moja.pages.mojaCsob.payments;

import lombok.Getter;
import sk.moja.elements.CsobDropdown;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class SepaBulkPaymentPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Payer", new CsobDropdown(byId("bulkSepaPayment_paymentProductDropdownId")));

        elementMap.put("Street", new Element(byId("inputIdPrefix_street")));
        elementMap.put("House number", new Element(byId("inputIdPrefix_houseNumber")));
        elementMap.put("City", new Element(byId("inputIdPrefix_city")));
        elementMap.put("Zip code", new Element(byId("inputIdPrefix_zipCode")));
        elementMap.put("Country", new CsobDropdown(byId("inputIdPrefix_country")));

        elementMap.put("Receiver 1", new CsobDropdown(byId("bulkSepaPayment_1_receiverDropdown")));
        elementMap.put("Receiver 2", new CsobDropdown(byId("bulkSepaPayment_2_receiverDropdown")));
        elementMap.put("Receiver 3", new CsobDropdown(byId("bulkSepaPayment_3_receiverDropdown")));
        elementMap.put("Receiver 4", new CsobDropdown(byId("bulkSepaPayment_4_receiverDropdown")));
        elementMap.put("Receiver IBAN", new Element(byId("bulkSepaPaymentTemplate_receiverIban")));
        elementMap.put("Receiver IBAN 1", new Element(byId("bulkSepaPayment_1_receiverIban")));
        elementMap.put("Receiver IBAN 2", new Element(byId("bulkSepaPayment_2_receiverIban")));
        elementMap.put("Receiver IBAN 3", new Element(byId("bulkSepaPayment_3_receiverIban")));
        elementMap.put("Receiver IBAN 4", new Element(byId("bulkSepaPayment_4_receiverIban")));
        elementMap.put("Receiver IBAN 5", new Element(byId("bulkSepaPayment_5_receiverIban")));
        elementMap.put("Receiver IBAN 6", new Element(byId("bulkSepaPayment_6_receiverIban")));
        elementMap.put("Receiver IBAN 7", new Element(byId("bulkSepaPayment_7_receiverIban")));
        elementMap.put("Receiver IBAN 8", new Element(byId("bulkSepaPayment_8_receiverIban")));
        elementMap.put("Receiver IBAN 9", new Element(byId("bulkSepaPayment_9_receiverIban")));
        elementMap.put("Receiver IBAN 10", new Element(byId("bulkSepaPayment_10_receiverIban")));
        elementMap.put("Receiver prefix number 1", new Element(byId("bulkSepaPayment_1_bban_prefixNumber")));
        elementMap.put("Receiver prefix number 2", new Element(byId("bulkSepaPayment_2_bban_prefixNumber")));
        elementMap.put("Receiver prefix number 3", new Element(byId("bulkSepaPayment_3_bban_prefixNumber")));
        elementMap.put("Receiver prefix number 4", new Element(byId("bulkSepaPayment_4_bban_prefixNumber")));
        elementMap.put("Receiver prefix number 5", new Element(byId("bulkSepaPayment_5_bban_prefixNumber")));
        elementMap.put("Receiver prefix number 6", new Element(byId("bulkSepaPayment_6_bban_prefixNumber")));
        elementMap.put("Receiver prefix number 7", new Element(byId("bulkSepaPayment_7_bban_prefixNumber")));
        elementMap.put("Receiver prefix number 8", new Element(byId("bulkSepaPayment_8_bban_prefixNumber")));
        elementMap.put("Receiver prefix number 9", new Element(byId("bulkSepaPayment_9_bban_prefixNumber")));
        elementMap.put("Receiver prefix number 10", new Element(byId("bulkSepaPayment_10_bban_prefixNumber")));
        elementMap.put("Receiver account number 1", new Element(byId("bulkSepaPayment_1_bban_ccountNumber")));
        elementMap.put("Receiver account number 2", new Element(byId("bulkSepaPayment_2_bban_ccountNumber")));
        elementMap.put("Receiver account number 3", new Element(byId("bulkSepaPayment_3_bban_ccountNumber")));
        elementMap.put("Receiver account number 4", new Element(byId("bulkSepaPayment_4_bban_ccountNumber")));
        elementMap.put("Receiver account number 5", new Element(byId("bulkSepaPayment_5_bban_ccountNumber")));
        elementMap.put("Receiver account number 6", new Element(byId("bulkSepaPayment_6_bban_ccountNumber")));
        elementMap.put("Receiver account number 7", new Element(byId("bulkSepaPayment_7_bban_ccountNumber")));
        elementMap.put("Receiver account number 8", new Element(byId("bulkSepaPayment_8_bban_ccountNumber")));
        elementMap.put("Receiver account number 9", new Element(byId("bulkSepaPayment_9_bban_ccountNumber")));
        elementMap.put("Receiver account number 10", new Element(byId("bulkSepaPayment_10_bban_ccountNumber")));

        elementMap.put("Amount 1", new Element(byId("bulkSepaPayment_1_amount")));
        elementMap.put("Amount 2", new Element(byId("bulkSepaPayment_2_amount")));
        elementMap.put("Amount 3", new Element(byId("bulkSepaPayment_3_amount")));
        elementMap.put("Amount 4", new Element(byId("bulkSepaPayment_4_amount")));
        elementMap.put("Amount 5", new Element(byId("bulkSepaPayment_5_amount")));
        elementMap.put("Amount 6", new Element(byId("bulkSepaPayment_6_amount")));
        elementMap.put("Amount 7", new Element(byId("bulkSepaPayment_7_amount")));
        elementMap.put("Amount 8", new Element(byId("bulkSepaPayment_8_amount")));
        elementMap.put("Amount 9", new Element(byId("bulkSepaPayment_9_amount")));
        elementMap.put("Amount 10", new Element(byId("bulkSepaPayment_10_amount")));
        elementMap.put("Message 1", new Element(byId("bulkSepaPayment_1_message")));
        elementMap.put("Message 2", new Element(byId("bulkSepaPayment_2_message")));
        elementMap.put("Message 3", new Element(byId("bulkSepaPayment_3_message")));
        elementMap.put("Message 4", new Element(byId("bulkSepaPayment_4_message")));
        elementMap.put("Message 5", new Element(byId("bulkSepaPayment_5_message")));
        elementMap.put("Message 6", new Element(byId("bulkSepaPayment_6_message")));
        elementMap.put("Message 7", new Element(byId("bulkSepaPayment_7_message")));
        elementMap.put("Message 8", new Element(byId("bulkSepaPayment_8_message")));
        elementMap.put("Message 9", new Element(byId("bulkSepaPayment_9_message")));
        elementMap.put("Message 10", new Element(byId("bulkSepaPayment_10_message")));

        elementMap.put("Variable symbol 1", new Element(byId("bulkSepaPayment_1_variableSymbol")));
        elementMap.put("Variable symbol 2", new Element(byId("bulkSepaPayment_2_variableSymbol")));
        elementMap.put("Variable symbol 3", new Element(byId("bulkSepaPayment_3_variableSymbol")));
        elementMap.put("Variable symbol 4", new Element(byId("bulkSepaPayment_4_variableSymbol")));
        elementMap.put("Variable symbol 5", new Element(byId("bulkSepaPayment_5_variableSymbol")));
        elementMap.put("Variable symbol 6", new Element(byId("bulkSepaPayment_6_variableSymbol")));
        elementMap.put("Variable symbol 7", new Element(byId("bulkSepaPayment_7_variableSymbol")));
        elementMap.put("Variable symbol 8", new Element(byId("bulkSepaPayment_8_variableSymbol")));
        elementMap.put("Variable symbol 9", new Element(byId("bulkSepaPayment_9_variableSymbol")));
        elementMap.put("Variable symbol 10", new Element(byId("bulkSepaPayment_10_variableSymbol")));
        elementMap.put("Specific symbol 1", new Element(byId("bulkSepaPayment_1_specificSymbol")));
        elementMap.put("Specific symbol 2", new Element(byId("bulkSepaPayment_2_specificSymbol")));
        elementMap.put("Specific symbol 3", new Element(byId("bulkSepaPayment_3_specificSymbol")));
        elementMap.put("Specific symbol 4", new Element(byId("bulkSepaPayment_4_specificSymbol")));
        elementMap.put("Specific symbol 5", new Element(byId("bulkSepaPayment_5_specificSymbol")));
        elementMap.put("Specific symbol 6", new Element(byId("bulkSepaPayment_6_specificSymbol")));
        elementMap.put("Specific symbol 7", new Element(byId("bulkSepaPayment_7_specificSymbol")));
        elementMap.put("Specific symbol 8", new Element(byId("bulkSepaPayment_8_specificSymbol")));
        elementMap.put("Specific symbol 9", new Element(byId("bulkSepaPayment_9_specificSymbol")));
        elementMap.put("Specific symbol 10", new Element(byId("bulkSepaPayment_10_specificSymbol")));
        elementMap.put("Constant symbol 1", new Element(byId("bulkSepaPayment_1_constantSymbol")));
        elementMap.put("Constant symbol 2", new Element(byId("bulkSepaPayment_2_constantSymbol")));
        elementMap.put("Constant symbol 3", new Element(byId("bulkSepaPayment_3_constantSymbol")));
        elementMap.put("Constant symbol 4", new Element(byId("bulkSepaPayment_4_constantSymbol")));
        elementMap.put("Constant symbol 5", new Element(byId("bulkSepaPayment_5_constantSymbol")));
        elementMap.put("Constant symbol 6", new Element(byId("bulkSepaPayment_6_constantSymbol")));
        elementMap.put("Constant symbol 7", new Element(byId("bulkSepaPayment_7_constantSymbol")));
        elementMap.put("Constant symbol 8", new Element(byId("bulkSepaPayment_8_constantSymbol")));
        elementMap.put("Constant symbol 9", new Element(byId("bulkSepaPayment_9_constantSymbol")));
        elementMap.put("Constant symbol 10", new Element(byId("bulkSepaPayment_10_constantSymbol")));
        elementMap.put("Payer reference 1", new Element(byId("bulkSepaPayment_1_payersReference")));
        elementMap.put("Payer reference 2", new Element(byId("bulkSepaPayment_2_payersReference")));
        elementMap.put("Payer reference 3", new Element(byId("bulkSepaPayment_3_payersReference")));
        elementMap.put("Payer reference 4", new Element(byId("bulkSepaPayment_4_payersReference")));
        elementMap.put("Payer reference 5", new Element(byId("bulkSepaPayment_5_payersReference")));
        elementMap.put("Payer reference 6", new Element(byId("bulkSepaPayment_6_payersReference")));
        elementMap.put("Payer reference 7", new Element(byId("bulkSepaPayment_7_payersReference")));
        elementMap.put("Payer reference 8", new Element(byId("bulkSepaPayment_8_payersReference")));
        elementMap.put("Payer reference 9", new Element(byId("bulkSepaPayment_9_payersReference")));
        elementMap.put("Payer reference 10", new Element(byId("bulkSepaPayment_10_payersReference")));
        elementMap.put("Beneficary name 1", new Element(byId("bulkSepaPayment_1_beneficiaryName")));
        elementMap.put("Beneficary name 2", new Element(byId("bulkSepaPayment_2_beneficiaryName")));
        elementMap.put("Beneficary name 3", new Element(byId("bulkSepaPayment_3_beneficiaryName")));
        elementMap.put("Beneficary name 4", new Element(byId("bulkSepaPayment_4_beneficiaryName")));
        elementMap.put("Beneficary name 5", new Element(byId("bulkSepaPayment_5_beneficiaryName")));
        elementMap.put("Beneficary name 6", new Element(byId("bulkSepaPayment_6_beneficiaryName")));
        elementMap.put("Beneficary name 7", new Element(byId("bulkSepaPayment_7_beneficiaryName")));
        elementMap.put("Beneficary name 8", new Element(byId("bulkSepaPayment_8_beneficiaryName")));
        elementMap.put("Beneficary name 9", new Element(byId("bulkSepaPayment_9_beneficiaryName")));
        elementMap.put("Beneficary name 10", new Element(byId("bulkSepaPayment_10_beneficiaryName")));

        elementMap.put("Add a payment", new Element(byClassName("csob-icon-set-add-alt")));
        elementMap.put("Cancel payment", new Element(byClassName("csob-icon-set-remove-alt")));

        elementMap.put("Total amount", new Element(byId("bulkSepaPayment_totalAmount")));
        elementMap.put("Due date", new Element(byId("bulkSepaPayment_dueDate")));

        elementMap.put("Edit beneficary name", new Element(byXpath("//div/a[.='Upraviť meno príjemcu']")));
        elementMap.put("Continue without editing", new Element(byXpath("//div/a[.='Pokračovať bez úprav']")));
        elementMap.put("Matching", new Element(byXpath("//div/a[.='Pokračovať']")));
        elementMap.put("IPA pay", new Element(byAttribute("inputid", "paymentProcessingRadio1")));
        elementMap.put("Sepa pay", new Element(byAttribute("inputid", "paymentProcessingRadio2")));

        elementMap.put("Back", new Element(byId("bulkSepaPaymentPage_formFooterCancel")));
        elementMap.put("Sign", new Element(byId("bulkSepaPaymentPage_formFooterSign")));
        elementMap.put("Authorization code", new Element(byId("authorizationCode")));
        elementMap.put("Edit", new Element(byId("bulkSepaPaymentPage_crontoSignatureCancel")));
        elementMap.put("Submit", new Element(byId("bulkSepaPaymentPage_crontoSignatureSubmit")));

        elementMap.put("Show cronto token", new Element(byId("bulkSepaPaymentPage_crontoSignatureSwitchToOnlineMode")));

        elementMap.put("Back to account", new Element(byText("Späť na účet.")));
        elementMap.put("New payment", new Element(byXpath("//div[@class='modal-content']//*/a[.='Nová platba']")));
        elementMap.put("Save as template", new Element(byText("Uložiť ako šablónu")));
        elementMap.put("Product detail", new Element(byXpath("//div[@class='modal-content']//*/a[.='Detail produktu']")));

        elementMap.put("Success message", new Element(byClassName("message-with-icon")));
    }
}