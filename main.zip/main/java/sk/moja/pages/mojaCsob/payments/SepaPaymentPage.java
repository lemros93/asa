package sk.moja.pages.mojaCsob.payments;

import lombok.Getter;
import sk.moja.elements.CsobDropdown;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class SepaPaymentPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Payer", new CsobDropdown(byId("sepaPayment_paymentProductDropdownId")));

        elementMap.put("Enter the original format", new Element(byId("changeReceiverInputMode")));
        elementMap.put("Enter IBAN", new Element(byId("changeReceiverInputMode")));
        elementMap.put("Receiver", new CsobDropdown(byId("sepaPayment_receiverDropdown")));
        elementMap.put("Receiver IBAN", new Element(byId("sepaPayment_receiverIban")));
        elementMap.put("Receiver prefix number", new Element(byId("sepaPayment_bban_prefixNumber")));
        elementMap.put("Receiver account number", new Element(byId("sepaPayment_bban_ccountNumber")));

        elementMap.put("Amount", new Element(byId("sepaPayment_amount")));
        elementMap.put("Message", new Element(byId("sepaPayment_message")));
        elementMap.put("Due date", new Element(byId("sepaPayment_dueDate")));

        elementMap.put("Prioritized payment", new Element(byAttribute("inputid", "prioritizedPayment")));

        elementMap.put("Discard changes", new Element(byClassName("delete-data-hint")));

        elementMap.put("Variable symbol", new Element(byId("sepaPayment_variableSymbol")));
        elementMap.put("Specific symbol", new Element(byId("sepaPayment_specificSymbol")));
        elementMap.put("Constant symbol", new Element(byId("sepaPayment_constantSymbol")));
        elementMap.put("Payer reference", new Element(byId("sepaPayment_payersReference")));
        elementMap.put("Beneficary name", new Element(byId("sepaPayment_beneficiaryName")));
        elementMap.put("Street", new Element(byId("sepaPayment_street")));
        elementMap.put("House number", new Element(byId("sepaPayment_houseNumber")));
        elementMap.put("City", new Element(byId("sepaPayment_city")));
        elementMap.put("Zip code", new Element(byId("sepaPayment_zipCode")));
        elementMap.put("Country", new CsobDropdown(byId("sepaPayment_country")));

        elementMap.put("Edit beneficary name", new Element(byXpath("//div/a[.='Upraviť meno príjemcu']")));
        elementMap.put("Continue without editing", new Element(byXpath("//div/a[.='Pokračovať bez úprav']")));
        elementMap.put("Matching", new Element(byXpath("//div/a[.='Pokračovať']")));
        elementMap.put("IPA pay", new Element(byAttribute("inputid", "paymentProcessingRadio1")));
        elementMap.put("Sepa pay", new Element(byAttribute("inputid", "paymentProcessingRadio2")));

        elementMap.put("Add a payment", new Element(byClassName("csob-icon-set-add-alt")));

        elementMap.put("Back", new Element(byId("sepaPaymentPage_formFooterCancel")));
        elementMap.put("Sign", new Element(byId("sepaPaymentPage_formFooterSign")));
        elementMap.put("Authorization code", new Element(byId("authorizationCode")));
        elementMap.put("Edit", new Element(byId("sepaPaymentPage_crontoSignatureCancel")));
        elementMap.put("Submit", new Element(byId("sepaPaymentPage_crontoSignatureSubmit")));
        elementMap.put("Edit token", new Element(byId("sepaPaymentPage_crontoSignatureCancel")));
        elementMap.put("Submit token", new Element(byId("sepaPaymentPage_crontoSignatureSubmit")));

        elementMap.put("Show cronto token", new Element(byId("sepaPaymentPage_crontoSignatureSwitchToOnlineMode")));

        elementMap.put("Back to account", new Element(byText("Späť na účet.")));
        elementMap.put("New payment", new Element(byXpath("//div[@class='modal-content']//*/a[.='Nová platba']")));
        elementMap.put("Create a standing order", new Element(byXpath("//div[@class='modal-content']//*/a[.='Vytvoriť trvalý príkaz']")));
        elementMap.put("Save as template", new Element(byXpath("//div[@class='modal-content']//*/a[.='Uložiť ako šablónu']")));

        elementMap.put("Success message", new Element(byClassName("message-with-icon")));
    }
}