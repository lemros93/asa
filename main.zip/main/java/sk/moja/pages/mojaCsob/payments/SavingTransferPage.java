package sk.moja.pages.mojaCsob.payments;

import lombok.Getter;
import sk.moja.elements.CsobDropdown;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class SavingTransferPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Payer", new CsobDropdown(byId("payerProduct_paymentProductDropdownId")));
        elementMap.put("Receiver", new CsobDropdown(byId("receiverProduct_paymentProductDropdownId")));
        elementMap.put("Amount", new Element(byId("amount")));
        elementMap.put("Fee", new Element(byId("fee")));
        elementMap.put("Message", new Element(byId("message")));
        elementMap.put("Due date", new Element(byId("savingsTransfer_dueDate")));

        elementMap.put("Notice savings transfer", new Element(byId("noticeSavingsTransferForm")));
        elementMap.put("Immediate savings transfer", new Element(byId("immediateSavingsTransferForm")));

        elementMap.put("Discard changes", new Element(byClassName("delete-data-hint")));

        elementMap.put("Sign", new Element(byId("savingsTransferPage_formFooterSign")));
        elementMap.put("Back", new Element(byId("savingsTransferPage_formFooterCancel")));
        elementMap.put("Authorization code", new Element(byId("authorizationCode")));
        elementMap.put("Edit", new Element(byId("savingsTransferPage_crontoSignatureCancel")));
        elementMap.put("Submit", new Element(byId("savingsTransferPage_crontoSignatureSubmit")));

        elementMap.put("Show cronto token", new Element(byId("savingsTransferPage_crontoSignatureSwitchToOnlineMode")));
    }
}