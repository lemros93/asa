package sk.moja.pages.mojaCsob.payments;

import lombok.Getter;
import sk.moja.elements.CsobDropdown;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class StandingOrderPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Name", new Element(byId("standingOrder_name")));
        elementMap.put("Payer", new CsobDropdown(byId("standingOrder_paymentProductDropdownId")));
        elementMap.put("Enter the original format", new Element(byText("Zadať pôvodný formát")));
        elementMap.put("Enter IBAN", new Element(byText("Zadať IBAN")));
        elementMap.put("Receiver IBAN", new Element(byId("standingOrder_receiverIban")));
        elementMap.put("Receiver prefix number", new Element(byId("standingOrder_bban_prefixNumber")));
        elementMap.put("Receiver account number", new Element(byId("standingOrder_bban_accountNumber")));
        elementMap.put("Amount", new Element(byId("standingOrder_paymentAmount")));
        elementMap.put("Message", new Element(byId("createStandingOrder_message")));
        elementMap.put("Due date", new Element(byId("standingOrder_dueDate")));
        elementMap.put("Frequency", new CsobDropdown(byAttribute("formcontrolname", "frequency")));
        elementMap.put("Last payment date", new Element(byId("standingOrder_lastPaymentDate")));

        elementMap.put("Discard changes", new Element(byClassName("delete-data-hint")));

        elementMap.put("Variable symbol", new Element(byId("createStandingOrder_variableSymbol")));
        elementMap.put("Specific symbol", new Element(byId("createStandingOrder_specificSymbol")));
        elementMap.put("Constant symbol", new Element(byId("createStandingOrder_constantSymbol")));
        elementMap.put("Payer reference", new Element(byId("createStandingOrder_payersReference")));
        elementMap.put("Beneficary name", new Element(byAttribute("formcontrolname", "beneficiaryName")));
        elementMap.put("Street", new Element(byId("standingOrder_street")));
        elementMap.put("House number", new Element(byId("standingOrder_houseNumber")));
        elementMap.put("City", new Element(byId("standingOrder_city")));
        elementMap.put("Zip code", new Element(byId("standingOrder_zipCode")));
        elementMap.put("Country", new CsobDropdown(byId("standingOrder_country")));

        elementMap.put("Edit beneficary name", new Element(byXpath("//div/a[.='Upraviť meno príjemcu']")));
        elementMap.put("Continue without editing", new Element(byXpath("//div/a[.='Pokračovať bez úprav']")));
        elementMap.put("Matching", new Element(byXpath("//div/a[.='Pokračovať']")));
        elementMap.put("IPA pay", new Element(byId("paymentProcessingRadio1")));
        elementMap.put("Sepa pay", new Element(byId("paymentProcessingRadio2")));


        elementMap.put("Sign", new Element(byId("standingOrderDetail_formFooterSign")));
        elementMap.put("Back", new Element(byId("standingOrderDetail_formFooterCancel")));
        elementMap.put("Authorization code", new Element(byId("authorizationCode")));
        elementMap.put("Edit", new Element(byId("standingOrderDetail_crontoSignatureCancel")));
        elementMap.put("Submit", new Element(byId("standingOrderDetail_crontoSignatureSubmit")));

        elementMap.put("Show cronto token", new Element(byId("standingOrderDetail_crontoSignatureSwitchToOnlineMode")));
    }
}