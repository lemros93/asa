package sk.moja.pages.mojaCsob.payments;

import lombok.Getter;
import sk.moja.elements.CsobDropdown;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class DirectDebitPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Name", new Element(byId("directDebitAuthorizationDetail_name")));
        elementMap.put("Payer", new CsobDropdown(byId("directDebitAuthorizationDetail_paymentProductDropdownId")));

        elementMap.put("Cid", new Element(byId("receiverCid")));
        elementMap.put("Limit type", new CsobDropdown(byId("limitTypes")));
        elementMap.put("Maximum amount", new Element(byId("maximumAmount")));
        elementMap.put("From date", new Element(byId("directDebitAuthorizationDetail_fromDate")));
        elementMap.put("To date", new Element(byId("directDebitAuthorizationDetail_toDate")));
        elementMap.put("Mandate reference", new Element(byId("mandateReference")));
        elementMap.put("Warning message", new Element(byClassName("text-danger")));

        elementMap.put("Discard changes", new Element(byClassName("delete-data-hint")));

        elementMap.put("Back", new Element(byId("directDebitAuthorizationPage_formFooterCancel")));
        elementMap.put("Sign", new Element(byId("directDebitAuthorizationPage_formFooterSign")));
        elementMap.put("Authorization code", new Element(byId("authorizationCode")));
        elementMap.put("Edit", new Element(byId("directDebitAuthorizationPage_crontoSignatureCancel")));
        elementMap.put("Submit", new Element(byId("directDebitAuthorizationPage_crontoSignatureSubmit")));

        elementMap.put("Show cronto token", new Element(byId("directDebitAuthorizationPage_crontoSignatureSwitchToOnlineMode")));
    }
}