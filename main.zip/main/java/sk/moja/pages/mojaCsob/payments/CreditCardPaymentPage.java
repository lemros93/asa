package sk.moja.pages.mojaCsob.payments;

import lombok.Getter;
import sk.moja.elements.CsobDropdown;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class CreditCardPaymentPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Payer", new CsobDropdown(byId("payerProduct_paymentProductDropdownId")));
        elementMap.put("Receiver", new CsobDropdown(byId("receiverProduct_paymentProductDropdownId")));
        elementMap.put("Repayment type", new CsobDropdown(byId("creditCardRepaymentTypeDropdown")));
        elementMap.put("Amount", new Element(byId("amount")));
        elementMap.put("Message", new Element(byId("message")));
        elementMap.put("Due date", new Element(byId("creditCardRepayment_dueDate")));

        elementMap.put("Info message", new Element(byClassName("alert-content")));

        elementMap.put("Sign", new Element(byId("creditCardRepaymentPage_formFooterSign")));
        elementMap.put("Back", new Element(byId("creditCardRepaymentPage_formFooterCancel")));
        elementMap.put("Authorization code", new Element(byId("authorizationCode")));
        elementMap.put("Edit", new Element(byId("creditCardRepaymentPage_crontoSignatureCancel")));
        elementMap.put("Submit", new Element(byId("creditCardRepaymentPage_crontoSignatureSubmit")));

        elementMap.put("Show cronto token", new Element(byId("creditCardRepaymentPage_crontoSignatureSwitchToOnlineMode")));
    }
}