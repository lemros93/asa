package sk.moja.pages.mojaCsob.payments;

import lombok.Getter;
import org.openqa.selenium.By;
import sk.moja.elements.CsobDropdown;
import sk.moja.elements.Element;

import java.util.List;
import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;
import static java.util.Arrays.asList;

public class StandingOrderListPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();
    @Getter
    private static final TreeMap<String, List<By>> combinedElementsMap = new TreeMap<>();

    static{
        elementMap.put("Enter a search term", new Element(byId("searchInput")));
        elementMap.put("Advanced search", new Element(byClassName("show-more")));
        elementMap.put("Products", new CsobDropdown(byId("product")));
        elementMap.put("Create a standing order", new Element(byText("Vytvoriť trvalý príkaz")));

        // TODO: recheck why 2 times defined the same xpath
        combinedElementsMap.put("Standing order list", asList(
                byXpath("//ib-standing-order-table"),
                byXpath("//ib-standing-order-table"),
                byClassName("message")));
        elementMap.put("Edit standing order", new Element(byClassName("csob-icon-set-edit")));
        elementMap.put("Remove standing order", new Element(byClassName("csob-icon-set-trash-alt")));

        elementMap.put("Left arrow", new Element(byClassName("csob-icon-set-keyboard-arrow-left-alt2")));
        elementMap.put("Right arrow", new Element(byClassName("csob-icon-set-keyboard-arrow-right-alt2")));
        elementMap.put("Paging", new Element(byXpath("//csob-paging")));
        elementMap.put("Page size", new Element(byClassName("csob-table-item-container")));
    }
}