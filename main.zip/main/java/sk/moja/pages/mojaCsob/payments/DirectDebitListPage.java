package sk.moja.pages.mojaCsob.payments;

import lombok.Getter;
import org.openqa.selenium.By;
import sk.moja.elements.CsobDropdown;
import sk.moja.elements.Element;

import java.util.List;
import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;
import static java.util.Arrays.asList;

public class DirectDebitListPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();
    @Getter
    private static final TreeMap<String, List<By>> combinedElementsMap = new TreeMap<>();

    static{
        elementMap.put("Enter a search term", new Element(byId("searchInput")));
        elementMap.put("Advanced search", new Element(byClassName("show-more")));
        elementMap.put("Products", new CsobDropdown(byId("product")));
        elementMap.put("Create a direct debit", new Element(byText("Nový súhlas s inkasom")));

        combinedElementsMap.put("List of Direct Debits", asList(
                byXpath("//ib-direct-debit-authorization-table-row"),
                byXpath("//ib-direct-debit-authorization-table"),
                byClassName("message")));
        elementMap.put("Edit direct debit", new Element(byClassName("csob-icon-set-edit")));
        elementMap.put("Remove direct debit", new Element(byClassName("csob-icon-set-trash-alt")));

        elementMap.put("Left arrow", new Element(byClassName("csob-icon-set-keyboard-arrow-left-alt2")));
        elementMap.put("Right arrow", new Element(byClassName("csob-icon-set-keyboard-arrow-right-alt2")));
        elementMap.put("Paging", new Element(byXpath("//csob-paging")));
        elementMap.put("Page size", new Element(byClassName("csob-table-item-container")));
    }
}