package sk.moja.pages.mojaCsob.payments;

import lombok.Getter;
import sk.moja.elements.CsobDropdown;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class ForeignPaymentPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Payer", new CsobDropdown(byId("foreignPayment_paymentProductDropdownId")));
        elementMap.put("Payer reference", new Element(byId("foreignPayment_payersReference")));

        elementMap.put("Receiver", new CsobDropdown(byId("foreignPayment_receiverDropdown")));
        elementMap.put("Receiver IBAN", new Element(byId("foreignPayment_accountNumber_iban")));

        elementMap.put("Amount", new Element(byId("foreignPayment_amount")));
        elementMap.put("Currency", new CsobDropdown(byAttribute("formcontrolname", "currency")));
        elementMap.put("Conversion info", new Element(byClassName("currency-conversion-hint")));

        elementMap.put("Message", new Element(byId("foreignPayment_message")));
        elementMap.put("Due date", new Element(byId("foreignPayment_dueDate")));
        elementMap.put("Prioritized payment", new Element(byAttribute("formcontrolname", "prioritized")));

        elementMap.put("Discard changes", new Element(byClassName("delete-data-hint")));

        elementMap.put("Bic", new Element(byId("foreignPayment_bic")));
        elementMap.put("Receiver name", new Element(byId("foreignPaymentname")));
        elementMap.put("Street", new Element(byId("foreignPayment_street")));
        elementMap.put("House number", new Element(byId("foreignPayment_houseNumber")));
        elementMap.put("City", new Element(byId("foreignPayment_city")));
        elementMap.put("Zip code", new Element(byId("foreignPayment_zipCode")));
        elementMap.put("Country", new CsobDropdown(byId("foreignPayment_country")));
        elementMap.put("Type of expenses", new CsobDropdown(byId("foreignPayment_typeOfExpenses")));

        elementMap.put("More bank instruction", new Element(byText("Ďalšie inštrukcie pre banku")));
        elementMap.put("Info for bank", new Element(byId("foreignPayment_infoForBank")));

        elementMap.put("Back", new Element(byId("foreignPaymentPage_formFooterCancel")));
        elementMap.put("Sign", new Element(byId("foreignPaymentPage_formFooterSign")));
        elementMap.put("Authorization code", new Element(byId("authorizationCode")));
        elementMap.put("Edit", new Element(byId("foreignPaymentPage_crontoSignatureCancel")));
        elementMap.put("Submit", new Element(byId("foreignPaymentPage_crontoSignatureSubmit")));

        elementMap.put("Show cronto token", new Element(byId("foreignPaymentPage_crontoSignatureSwitchToOnlineMode")));

        elementMap.put("Back to account", new Element(byText("Späť na účet.")));
        elementMap.put("New payment", new Element(byXpath("//footer//a[contains(text(), 'Nová platba')]")));
        elementMap.put("Save as template", new Element(byText("Uložiť ako šablónu")));

        elementMap.put("Success message", new Element(byClassName("message-with-icon")));
    }
}