package sk.moja.pages.mojaCsob;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

import static com.codeborne.selenide.Selectors.*;

public class ProductAvalabilityPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        elementMap.put("Product availability", new Element(byClassName("content-wrapper")));
        elementMap.put("Product availability - Back", new Element(byText("Späť")));
        elementMap.put("Product availability - Arranged a meeting", new Element(byText("Vyplniť kontaktný formulár")));
    }
}