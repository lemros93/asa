package sk.moja.pages;

import lombok.Getter;
import sk.moja.elements.Element;

import java.util.TreeMap;

public class AvokaLoginPage {

    @Getter
    private static final TreeMap<String, Element> elementMap = new TreeMap<>();

    static{
        
    }
}