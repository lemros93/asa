package sk.moja.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import sk.moja.elements.Element;
import sk.moja.pages.crm.*;
import sk.moja.pages.mojaCsob.*;
import sk.moja.pages.mojaCsob.consumer_loan.ConsumerLoanPage;
import sk.moja.pages.mojaCsob.mini_loan.MiniLoanPage;
import sk.moja.pages.mojaCsob.payments.*;
import sk.moja.pages.mojaCsob.products.*;
import sk.moja.pages.mojaCsob.profile.*;
import sk.moja.pages.mojaCsob.publicPages.TransparentAccountsPage;
import sk.moja.pages.mojaCsob.sales.*;
import sk.moja.pages.mojaCsob.statements.DealsDetailPage;
import sk.moja.pages.mojaCsob.statements.DealsPage;
import sk.moja.pages.mojaCsob.statements.StatementsListPage;
import sk.moja.pages.mojaCsob.statements.StatementsPage;
import sk.moja.pages.mojaCsob.templates.*;


import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

public class Pages {
    private final TreeMap<String, List<By>> combinedElementsMap = new TreeMap<>();
    private final TreeMap<String, Element> elementMap = new TreeMap<>();

    public Pages(String type) {
        String product = type.toUpperCase().replace(" ", "_");
        putPageObjectsIntoMaps(LoginPage.class);
        putPageObjectsIntoMaps(HeaderPage.class);
        putPageObjectsIntoMaps(GeneralElementPage.class);
        putPageObjectsIntoMaps(ProductAvalabilityPage.class);
        switch (product) {
            case "CONSUMER_LOAN":
                putPageObjectsIntoMaps(ConsumerLoanPage.class);
                putPageObjectsIntoMaps(OfferpointPage.class);
                break;
            case "MINI_LOAN":
                putPageObjectsIntoMaps(DashboardPage.class);
                putPageObjectsIntoMaps(MiniLoanPage.class);
                putPageObjectsIntoMaps(OfferpointPage.class);
                break;
            case "SEPA_PAYMENT":
                putPageObjectsIntoMaps(DashboardPage.class);
                putPageObjectsIntoMaps(SepaPaymentPage.class);
                break;
            case "BULK_SEPA_PAYMENT":
                putPageObjectsIntoMaps(DashboardPage.class);
                putPageObjectsIntoMaps(SepaBulkPaymentPage.class);
                break;
            case "FOREIGN_PAYMENT":
                putPageObjectsIntoMaps(DashboardPage.class);
                putPageObjectsIntoMaps(ForeignPaymentPage.class);
                break;
            case "DASHBOARD":
                putPageObjectsIntoMaps(DashboardPage.class);
                break;
            case "PRODUCT_DETAIL":
                putPageObjectsIntoMaps(ProductDetailPage.class);
                break;
            case "SEPA_PAYMENT_TEMPLATE":
                putPageObjectsIntoMaps(SepaPaymentTemplatesAndConnectionListPage.class);
                putPageObjectsIntoMaps(SepaPaymentTemplatesPage.class);
                break;
            case "SEPA_BANK_CONNECTION":
                putPageObjectsIntoMaps(SepaPaymentTemplatesAndConnectionListPage.class);
                putPageObjectsIntoMaps(SepaPaymentConnectionPage.class);
                break;
            case "FOREIGN_PAYMENT_TEMPLATE":
                putPageObjectsIntoMaps(ForeignPaymentTemplateAndConnectionListPage.class);
                putPageObjectsIntoMaps(ForeignPaymentTemplatesPage.class);
                break;
            case "FOREIGN_BANK_CONNECTION":
                putPageObjectsIntoMaps(ForeignPaymentTemplateAndConnectionListPage.class);
                putPageObjectsIntoMaps(ForeignPaymentConnectionPage.class);
                break;
            case "CARDS":
                putPageObjectsIntoMaps(CardPage.class);
                break;
            case "DISPLAY_PIN":
                putPageObjectsIntoMaps(CardPage.class);
                putPageObjectsIntoMaps(DisplayPinPage.class);
                break;
            case "BLOCK_CARD":
                putPageObjectsIntoMaps(CardPage.class);
                putPageObjectsIntoMaps(BlockCardPage.class);
                break;
            case "AVOKA":
                putPageObjectsIntoMaps(AvokaLoginPage.class);
                break;
            case "UNBLOCK_CARD":
                putPageObjectsIntoMaps(CardPage.class);
                putPageObjectsIntoMaps(UnlockCardPage.class);
                break;
            case "CARD_LIMIT":
                putPageObjectsIntoMaps(CardPage.class);
                putPageObjectsIntoMaps(CardLimitPage.class);
                break;
            case "INTERNET_CARD_LIMIT":
                putPageObjectsIntoMaps(CardPage.class);
                putPageObjectsIntoMaps(CardChangeSecurePaymentPage.class);
                break;
            case "CREDIT_CARD_PAYMENT":
                putPageObjectsIntoMaps(CreditCardPaymentPage.class);
                break;
            case "SAVING_TRANSFER":
                putPageObjectsIntoMaps(SavingTransferPage.class);
                break;
            case "STANDING_ORDER":
                putPageObjectsIntoMaps(StandingOrderListPage.class);
                putPageObjectsIntoMaps(StandingOrderPage.class);
                break;
            case "DIRECT_DEBIT":
                putPageObjectsIntoMaps(DirectDebitListPage.class);
                putPageObjectsIntoMaps(DirectDebitPage.class);
                break;
            case "BULK_SEPA_PAYMENT_TEMPLATE":
                putPageObjectsIntoMaps(BulkSepaPaymentTemplateListPage.class);
                putPageObjectsIntoMaps(BulkSepaPaymentTemplatePage.class);
                break;
            case "STATEMENTS":
                putPageObjectsIntoMaps(StatementsListPage.class);
                putPageObjectsIntoMaps(StatementsPage.class);
                break;
            case "DEALS":
                putPageObjectsIntoMaps(DealsDetailPage.class);
                putPageObjectsIntoMaps(DealsPage.class);
                break;
            case "CREDIT_CARD":
                putPageObjectsIntoMaps(OfferCreditCardPage.class);
                putPageObjectsIntoMaps(OfferpointPage.class);
                break;
            case "LOAN":
                putPageObjectsIntoMaps(LoanPage.class);
                putPageObjectsIntoMaps(OfferpointPage.class);
                break;
            case "OVERDRAFT":
                putPageObjectsIntoMaps(OverdraftPage.class);
                break;
            case "MORTGAGE_LOAN":
                putPageObjectsIntoMaps(MortgageLoanCamundaPage.class);
                putPageObjectsIntoMaps(OfferpointPage.class);
            case "SAVING_ACCOUNT":
                putPageObjectsIntoMaps(SavingAccountPage.class);
                break;
            case "PIN_CHANGE":
                putPageObjectsIntoMaps(PinChangePage.class);
                break;
            case "USER_DETAIL":
                putPageObjectsIntoMaps(UserDetailPage.class);
                break;
            case "AMENDMENTS":
                putPageObjectsIntoMaps(AvokaAmendmentsPage.class);
                break;
            case "CONTRACTS":
                putPageObjectsIntoMaps(ContractsPage.class);
                break;
            case "PRODUCT_ORDER":
                putPageObjectsIntoMaps(ProductOrderPage.class);
                break;
            case "NOTIFICATIONS":
                putPageObjectsIntoMaps(NotificationsPage.class);
                break;
            case "SERVICE_REQUEST", "SERVICE_REQUEST_FOREIGNER_ID_UPLOAD_DEEPLINK":
                putPageObjectsIntoMaps(ServiceRequestPage.class);
                break;
            case "CRM":
                clearMapObjects();
                putPageObjectsIntoMaps(CrmCustomerPage.class);
                putPageObjectsIntoMaps(CrmDashboardPage.class);
                putPageObjectsIntoMaps(CrmLandingPage.class);
                putPageObjectsIntoMaps(CrmSearchPage.class);
                putPageObjectsIntoMaps(CrmServiceRequestsPage.class);
                putPageObjectsIntoMaps(CrmOpportunityPage.class);
                break;
            case "OFFER_SMART_ACCOUNTS":
                putPageObjectsIntoMaps(OfferpointPage.class);
                putPageObjectsIntoMaps(OfferSmartAccounts.class);
                break;
            case "OFFERPOINT":
                putPageObjectsIntoMaps(OfferpointPage.class);
                break;
            case "SALES":
                putPageObjectsIntoMaps(OverdraftPage.class);
                putPageObjectsIntoMaps(SalesPage.class);
                break;
            case "TRANSPARENT_ACCOUNTS":
                putPageObjectsIntoMaps(TransparentAccountsPage.class);
                break;
            default:
                break;
        }
    }

    private void putPageObjectsIntoMaps(Class<?> page) {

        try {
            Method getElementMap = null;
            Method getCombinedElementsMap = null;

            try {
                getElementMap = page.getMethod("getElementMap");
            } catch (NoSuchMethodException e) {
                // method does not exist, just skip
            }

            if (getElementMap != null) {
                @SuppressWarnings("unchecked")
                TreeMap<String, Element> emap = (TreeMap<String, Element>) getElementMap.invoke(null);
                elementMap.putAll(emap);
            }

            try {
                getCombinedElementsMap = page.getMethod("getCombinedElementsMap");
            } catch (NoSuchMethodException e) {
                // method does not exist, just skip
            }

            if (getCombinedElementsMap != null) {
                @SuppressWarnings("unchecked")
                TreeMap<String, List<By>> emap = (TreeMap<String, List<By>>) getCombinedElementsMap.invoke(null);
                combinedElementsMap.putAll(emap);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void clearMapObjects() {
        elementMap.clear();
        combinedElementsMap.clear();
    }

    public List<By> getParameterList(String elementName) {
        List<By> parameterList = new ArrayList<>();

        if (elementMap.containsKey(elementName)) {
            Element element = elementMap.get(elementName);
            parameterList.addAll(getByObjectsForElement(element));
        } else if (combinedElementsMap.containsKey(elementName)) {
            parameterList.addAll(combinedElementsMap.get(elementName));
        } else {
            throw new NoSuchElementException("No element found in the maps of elements for the provided key: " + elementName);
        }

        return parameterList;
    }

    public List<By> getByObjectsForElement(Object element) {
        List<By> parameterList = new ArrayList<>();
        List<Class<?>> classHierarchy = new ArrayList<>();
        Class<?> currentClass = element.getClass();

        while (currentClass != null && currentClass != Object.class) {
            classHierarchy.add(0, currentClass);
            currentClass = currentClass.getSuperclass();
        }

        for (Class<?> clazz : classHierarchy) {
            Field[] fields = clazz.getDeclaredFields();

            for (Field field : fields) {
                if (Modifier.isStatic(field.getModifiers())){
                    continue;
                }

                if (By.class.isAssignableFrom(field.getType())) {
                    field.setAccessible(true);
                    try {
                        By value = (By) field.get(element);
                        if(value != null) {
                            parameterList.add(value);
                        }

                    } catch (IllegalAccessException exception) {
                        throw new RuntimeException("Failed to access field: " + field.getName(), exception);
                    }
                }
            }
        }

        return parameterList;
    }
}