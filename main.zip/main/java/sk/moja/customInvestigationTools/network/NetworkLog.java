package sk.moja.customInvestigationTools.network;

import lombok.Getter;

@Getter
public class NetworkLog {

    private String url;
    private String method;
    private int status;
    private String requestBody;
    private String responseBody;
    private String mimeType;

    public void setUrl(String url) {
        this.url = url;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public void setRequestBody(String requestBody) {
        this.requestBody = requestBody;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    @Override
    public String toString() {
        return "NetworkLog{" +
                "url='" + url + '\'' +
                ", method='" + method + '\'' +
                ", status=" + status +
                ", mimeType='" + mimeType + '\'' +
                '}';
    }
}