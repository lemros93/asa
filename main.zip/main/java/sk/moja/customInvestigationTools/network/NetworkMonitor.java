package sk.moja.customInvestigationTools.network;

import com.codeborne.selenide.WebDriverRunner;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.HasDevTools;
import org.openqa.selenium.devtools.v147.network.Network;
import org.openqa.selenium.devtools.v147.network.model.RequestId;
import org.openqa.selenium.edge.EdgeDriver;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Base64;

public class NetworkMonitor {

    private final Map<RequestId, NetworkLog> logs = new ConcurrentHashMap<>();
    private DevTools devTools;

    public void startMonitoring() {

        EdgeDriver driver = (EdgeDriver) WebDriverRunner.getWebDriver();
        devTools = ((HasDevTools) driver).getDevTools();
        devTools.createSession();

        devTools.send(Network.enable(
            Optional.empty(),
            Optional.empty(),
            Optional.empty(),
            Optional.empty(),
            Optional.empty()
        ));

        devTools.addListener(Network.requestWillBeSent(), request -> {

            NetworkLog log = new NetworkLog();
            log.setUrl(request.getRequest().getUrl());
            log.setMethod(request.getRequest().getMethod());

            logs.put(request.getRequestId(), log);

            try {
                String postData = devTools.send(
                        Network.getRequestPostData(request.getRequestId())
                ).getPostData();

                log.setRequestBody(postData);

            } catch (Exception ignored) {
                log.setRequestBody(null);
            }
        });

        devTools.addListener(Network.responseReceived(), response -> {

            NetworkLog log = logs.get(response.getRequestId());

            if (log != null) {
                log.setStatus(response.getResponse().getStatus());
                log.setMimeType(response.getResponse().getMimeType());
            }
        });

        devTools.addListener(Network.loadingFinished(), finished -> {

            NetworkLog log = logs.get(finished.getRequestId());

            if (log != null) {
                try {
                    Network.GetResponseBodyResponse bodyResponse =
                            devTools.send(Network.getResponseBody(finished.getRequestId()));

                    String body = bodyResponse.getBody();

                    if (bodyResponse.getBase64Encoded()) {
                        body = new String(Base64.getDecoder().decode(body));
                    }

                    log.setResponseBody(body);

                } catch (Exception e) {
                    log.setResponseBody("UNABLE_TO_READ_BODY: " + e.getMessage());
                }
            }
        });

        devTools.addListener(Network.loadingFailed(), failed -> {

            NetworkLog log = logs.get(failed.getRequestId());

            if (log != null) {
                log.setResponseBody("REQUEST_FAILED: " + failed.getErrorText());
            }
        });
    }

    public List<NetworkLog> getLogs() {
        return new ArrayList<>(logs.values());
    }

    public void clearLogs() {
        logs.clear();
    }

    public void stopMonitoring() {
        if (devTools != null) {
            devTools.disconnectSession();
        }
    }
}
