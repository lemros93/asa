package sk.moja.interfaces;

import com.codeborne.selenide.Configuration;
import com.intellij.uiDesigner.core.GridConstraints;
import com.intellij.uiDesigner.core.GridLayoutManager;
import sk.moja.enumerators.*;
import sk.moja.runners.Runner;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultCaret;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;
import java.awt.*;
import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static javax.swing.UIManager.getSystemLookAndFeelClassName;

public class Gui extends JFrame {
    private JPanel mainPanel;
    private JComboBox<String> domainsComboBox;
    public static JProgressBar featureProgressBar;
    public static JProgressBar scenarioProgressBar;
    private JButton startButton;
    private JButton stopButton;
    private JButton chooseFeatureButton;
    private JButton deleteFeatureButton;
    private JButton chooseDriverButton;
    private JButton choosePropertyButton;
    private JList<String> scenariosList;
    private JComboBox<String> browserComboBox;
    private JComboBox<String> browserSizeComboBox;
    private JComboBox<String> testTypeComboBox;
    private JCheckBox headlessCheckBox;
    private JCheckBox holdBrowserOpenCheckBox;
    private JCheckBox dryRunCheckBox;
    private JCheckBox extractScenariosNameCheckBox;
    private JComboBox<String> projectComboBox;
    private JComboBox<String> screenshotComboBox;
    private JComboBox<String> emptyComboBox;
    private JFileChooser chooser;
    DefaultListModel<String> defaultListModel = new DefaultListModel<>();

    public static JTextPane vypisTextArea;
    public static String textAreaText = "";

    private String driverPath;
    private String propertyPath;

    private static Runner runner;

    public Gui() {

        initialize();

        add(mainPanel);
        setTitle("E2E Testing Automation");
        setSize(1300, 700);
        vypisTextArea.setContentType("text/html");
        vypisTextArea.setEditable(false);
        featureProgressBar.setStringPainted(true);
        scenarioProgressBar.setStringPainted(true);
        projectComboBox.addItem("MojaCsob");
        emptyComboBox.addItem("placeholder text 1");
        emptyComboBox.addItem("placeholder text 2");

        setScreenshot();
        setDomains();
        setBrowsers();
        setBrowserSize();
        setTag();

        chooseFeatureButton.addActionListener(e -> {
            setFileChooser("features", "./src/test/resources/features");

            FileNameExtensionFilter filter = new FileNameExtensionFilter("FEATURES", "feature");
            chooser.setFileFilter(filter);
            chooser.setMultiSelectionEnabled(true);
            chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);

            if (chooser.showOpenDialog(Gui.this) == JFileChooser.APPROVE_OPTION) {
                File[] files = chooser.getSelectedFiles();
                scenariosList.setModel(defaultListModel);
                for (File file : files) {
                    if (file.isDirectory()) {
                        getFeaturesFromDirectory(file);
                    } else {
                        defaultListModel.addElement(file.getAbsolutePath());
                    }
                }
            }
        });

        chooseDriverButton.addActionListener(e -> {
            setFileChooser("drivers", "./src/test/resources/drivers/win/tda");

            if (chooser.showOpenDialog(Gui.this) == JFileChooser.APPROVE_OPTION) {
                File file = chooser.getSelectedFile();
                driverPath = file.getAbsolutePath();
            }
        });

        choosePropertyButton.addActionListener(e -> {
            setFileChooser("properties", "./src/test/resources/properties");

            FileNameExtensionFilter filter = new FileNameExtensionFilter("Property", "properties");
            chooser.setFileFilter(filter);
            chooser.setMultiSelectionEnabled(true);
            if (chooser.showOpenDialog(Gui.this) == JFileChooser.APPROVE_OPTION) {
                File file = chooser.getSelectedFile();
                propertyPath = file.getAbsolutePath();
            }
        });

        deleteFeatureButton.addActionListener(e -> {
            int minIndex = scenariosList.getMinSelectionIndex();
            int maxIndex = scenariosList.getMaxSelectionIndex();

            if (minIndex != -1 || maxIndex != -1) {
                defaultListModel.removeRange(minIndex, maxIndex);
            }
        });
        startButton.addActionListener(e -> {
            boolean startRunner = true;
            String message = "";
            clearLogTextArea();
            ListModel<String> listModel = scenariosList.getModel();
            featureProgressBar.setValue(0);
            featureProgressBar.setMaximum(listModel.getSize());

            scenarioProgressBar.setValue(0);
            String domain = Domains.valueOf(Objects.requireNonNull(domainsComboBox.getSelectedItem()).toString()).value;
            String browser = Browser.valueOf(Objects.requireNonNull(browserComboBox.getSelectedItem()).toString()).value;
            String browserSize = Objects.requireNonNull(browserSizeComboBox.getSelectedItem()).toString();
            String testType = Objects.requireNonNull(testTypeComboBox.getSelectedItem()).toString().replace(" ", "");

            List<String> listOfFeature = new ArrayList<>();
            if (listModel.getSize() > 0) {
                for (int i = 0; i < listModel.getSize(); i++) {
                    listOfFeature.add(listModel.getElementAt(i));
                }
                chooseFeatureButton.setBackground(Color.GRAY);
            } else {
                startRunner = false;
                chooseFeatureButton.setBackground(Color.red);
                message += "<p style=\"color:red; padding-left: 4em;\"><b>No Feature file selected</b></p>";

            }

            if (driverPath == null) {
                startRunner = false;
                chooseDriverButton.setBackground(Color.red);
                message += "<p style=\"color:red; padding-left: 4em;\"><b>No Driver file selected</b></p>";
            } else {
                chooseDriverButton.setBackground(Color.GRAY);
            }

            if (propertyPath == null) {
                startRunner = false;
                choosePropertyButton.setBackground(Color.red);
                message += "<p style=\"color:red; padding-left: 4em;\"><b>No Property file selected</b></p>";
            } else {
                choosePropertyButton.setBackground(Color.GRAY);
            }

            Configuration.headless = headlessCheckBox.isSelected();
            CustomProperties.setScreenshotType(Screenshots.valueOf(Objects.requireNonNull(screenshotComboBox.getSelectedItem()).toString()).value);
            Boolean dryRun = dryRunCheckBox.isSelected();
            Boolean extractScenariosName = extractScenariosNameCheckBox.isSelected();

            if (startRunner) {
                message += "<p style=\"padding-left: 4em;\"><b>----------------------------------------------------------------------------------------</b></p>";
                message += "<p style=\"padding-left: 4em;\"><b>Configuration</b></p>";
                message += "<p style=\"padding-left: 4em;\"><b>Domain: " + domain + "</b></p>";
                message += "<p style=\"padding-left: 4em;\"><b>Browser: " + browser + "</b></p>";
                message += "<p style=\"padding-left: 4em;\"><b>Browser size: " + browserSize + "</b></p>";
                message += "<p style=\"padding-left: 4em;\"><b>Driver: " + driverPath + "</b></p>";
                message += "<p style=\"padding-left: 4em;\"><b>property: " + propertyPath + "</b></p>";

                message += "<p style=\"padding-left: 4em;\"><b>Enables the ability to run the browser in headless mode: " + Configuration.headless + "</b></p>";
                message += "<p style=\"padding-left: 4em;\"><b>Dry run: " + dryRun + "</b></p>";
                message += "<p style=\"padding-left: 4em;\"><b>----------------------------------------------------------------------------------------</b></p>";

                updateLogTextArea(message);
                runner = new Runner(domain, browser, browserSize, driverPath, propertyPath, listOfFeature, "localGui", testType, dryRun, extractScenariosName);
                runner.start();
            } else {
                updateLogTextArea(message);
            }
        });
        stopButton.addActionListener(e -> runner.stop());
    }

    private void setFileChooser(String folderName, String folderPath) {
        File f1 = new File(folderName);
        if (f1.exists())
            chooser = new JFileChooser(folderName);
        else
            chooser = new JFileChooser(folderPath);
    }

    private void getFeaturesFromDirectory(File file) {

        FileFilter fileFilter = pathname -> pathname.getAbsolutePath().endsWith(".feature") || pathname.isDirectory();
        for (File f : Objects.requireNonNull(file.listFiles(fileFilter))) {
            if (f.isDirectory()) {
                getFeaturesFromDirectory(f);
            } else {
                defaultListModel.addElement(f.getAbsolutePath());
            }
        }
    }

    private void initialize() {
        final JPanel panel1 = new JPanel();
        panel1.setLayout(new GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1));
        mainPanel = new JPanel();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        mainPanel.setLayout(new GridLayoutManager(8, 8, new Insets(10, 10, 10, 10), -1, -1));
        panel1.add(mainPanel, new GridConstraints(0, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        JLabel scenarioListLabel = new JLabel();
        scenarioListLabel.setText("List of features");
        mainPanel.add(scenarioListLabel, new GridConstraints(0, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        JLabel logTextAreaLabel = new JLabel();
        logTextAreaLabel.setText("Logs");
        mainPanel.add(logTextAreaLabel, new GridConstraints(0, 3, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        featureProgressBar = new JProgressBar();
        mainPanel.add(featureProgressBar, new GridConstraints(5, 1, 1, 3, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_WANT_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        scenarioProgressBar = new JProgressBar();
        mainPanel.add(scenarioProgressBar, new GridConstraints(6, 1, 1, 3, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_WANT_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        scenariosList = new JList<>();
        final DefaultListModel<String> defaultListModel1 = new DefaultListModel<>();
        scenariosList.setModel(defaultListModel1);

        JScrollPane scenarioListScroll = new JScrollPane(scenariosList, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        mainPanel.add(scenarioListScroll, new GridConstraints(1, 0, 1, 3, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_BOTH, GridConstraints.SIZEPOLICY_WANT_GROW, GridConstraints.SIZEPOLICY_WANT_GROW, null, new Dimension(225, 300), null, 0, false));
        JLabel domainsComboBoxLabel = new JLabel();
        domainsComboBoxLabel.setText("Enviroment");
        mainPanel.add(domainsComboBoxLabel, new GridConstraints(3, 2, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        domainsComboBox = new JComboBox<>();
        final DefaultComboBoxModel<String> defaultComboBoxModel1 = new DefaultComboBoxModel<>();
        domainsComboBox.setModel(defaultComboBoxModel1);
        mainPanel.add(domainsComboBox, new GridConstraints(3, 3, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        deleteFeatureButton = new JButton();
        deleteFeatureButton.setText("Remove feature file");
        mainPanel.add(deleteFeatureButton, new GridConstraints(2, 1, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        JLabel browserComboBoxLabel = new JLabel();
        browserComboBoxLabel.setText("Browser");
        mainPanel.add(browserComboBoxLabel, new GridConstraints(4, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        browserComboBox = new JComboBox<>();
        mainPanel.add(browserComboBox, new GridConstraints(4, 1, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        chooseFeatureButton = new JButton();
        chooseFeatureButton.setText("Choose feature file");
        mainPanel.add(chooseFeatureButton, new GridConstraints(2, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JLabel label1 = new JLabel();
        label1.setText("Scenario progress bar");
        mainPanel.add(label1, new GridConstraints(5, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JLabel label2 = new JLabel();
        label2.setText("Feature progress bar");
        mainPanel.add(label2, new GridConstraints(6, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        vypisTextArea = new JTextPane();
        JScrollPane vypisTextAreaScroll = new JScrollPane(vypisTextArea, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        DefaultCaret caret = (DefaultCaret) vypisTextArea.getCaret();
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
        mainPanel.add(vypisTextAreaScroll, new GridConstraints(1, 3, 1, 5, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_BOTH, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_CAN_GROW, null, new Dimension(375, 300), null, 0, false));
        chooseDriverButton = new JButton();
        chooseDriverButton.setText("Choose driver file");
        mainPanel.add(chooseDriverButton, new GridConstraints(2, 3, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        choosePropertyButton = new JButton();
        choosePropertyButton.setText("Choose property file");
        mainPanel.add(choosePropertyButton, new GridConstraints(2, 4, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        startButton = new JButton();
        startButton.setText("Start              ");
        mainPanel.add(startButton, new GridConstraints(2, 6, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        stopButton = new JButton();
        stopButton.setHideActionText(true);
        stopButton.setText("Stop");
        mainPanel.add(stopButton, new GridConstraints(2, 7, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        headlessCheckBox = new JCheckBox();
        headlessCheckBox.setText("Headless");
        mainPanel.add(headlessCheckBox, new GridConstraints(7, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        JCheckBox startMaximizedCheckBox = new JCheckBox();
        startMaximizedCheckBox.setText("StartMaximized");
        mainPanel.add(startMaximizedCheckBox, new GridConstraints(7, 1, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        holdBrowserOpenCheckBox = new JCheckBox();
        holdBrowserOpenCheckBox.setText("HoldBrowserOpen");
        mainPanel.add(holdBrowserOpenCheckBox, new GridConstraints(7, 2, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        dryRunCheckBox = new JCheckBox();
        dryRunCheckBox.setText("DryRun");
        mainPanel.add(dryRunCheckBox, new GridConstraints(7, 3, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        extractScenariosNameCheckBox = new JCheckBox();
        extractScenariosNameCheckBox.setText("ExtractScenariosName");
        mainPanel.add(extractScenariosNameCheckBox, new GridConstraints(7, 4, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        JLabel browserSizeComboBoxLabel = new JLabel();
        browserSizeComboBoxLabel.setText("Browser size");
        mainPanel.add(browserSizeComboBoxLabel, new GridConstraints(4, 2, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        browserSizeComboBox = new JComboBox<>();
        mainPanel.add(browserSizeComboBox, new GridConstraints(4, 3, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        JLabel projectComboBoxLabel = new JLabel();
        projectComboBoxLabel.setText("Project");
        mainPanel.add(projectComboBoxLabel, new GridConstraints(3, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        projectComboBox = new JComboBox<>();
        mainPanel.add(projectComboBox, new GridConstraints(3, 1, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        JLabel testTypeComboBoxLabel = new JLabel();
        testTypeComboBoxLabel.setText("Test type");
        mainPanel.add(testTypeComboBoxLabel, new GridConstraints(3, 4, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        testTypeComboBox = new JComboBox<>();
        mainPanel.add(testTypeComboBox, new GridConstraints(3, 5, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        JLabel screenshotComboBoxLabel = new JLabel();
        screenshotComboBoxLabel.setText("Screenshot");
        mainPanel.add(screenshotComboBoxLabel, new GridConstraints(4, 4, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        screenshotComboBox = new JComboBox<>();
        mainPanel.add(screenshotComboBox, new GridConstraints(4, 5, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        JLabel emptyComboBoxLabel = new JLabel();
        emptyComboBoxLabel.setText("placeholder");
        mainPanel.add(emptyComboBoxLabel, new GridConstraints(3, 6, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        emptyComboBox = new JComboBox<>();
        mainPanel.add(emptyComboBox, new GridConstraints(3, 7, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_HORIZONTAL, GridConstraints.SIZEPOLICY_CAN_GROW, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));

    }

    public static void updateLogTextArea(String text) {
        if (textAreaText != null && vypisTextArea != null) {
            textAreaText += text;

            HTMLDocument doc = (HTMLDocument) vypisTextArea.getDocument();
            HTMLEditorKit editorKit = (HTMLEditorKit) vypisTextArea.getEditorKit();

            try {
                editorKit.insertHTML(doc, doc.getLength(), text, 0, 0, null);
            } catch (IOException | BadLocationException e) {
                e.printStackTrace();
            }
        }
    }

    private static void clearLogTextArea() {
        vypisTextArea.setText("");
        textAreaText = "";
        HTMLDocument doc = (HTMLDocument) vypisTextArea.getDocument();
        HTMLEditorKit editorKit = (HTMLEditorKit) vypisTextArea.getEditorKit();
        try {
            editorKit.insertHTML(doc, doc.getLength(), textAreaText, 0, 0, null);
        } catch (IOException | BadLocationException e) {
            e.printStackTrace();
        }
    }

    private void setBrowsers() {
        Browser[] browserList = Browser.values();
        for (Browser browser : browserList)
            browserComboBox.addItem(browser.toString());
    }

    private void setScreenshot() {
        Screenshots[] browserList = Screenshots.values();
        for (Screenshots screenshot : browserList)
            screenshotComboBox.addItem(screenshot.toString());
    }

    private void setDomains() {
        Domains[] domainsList = Domains.values();
        for (Domains domain : domainsList)
            domainsComboBox.addItem(domain.toString());
    }

    private void setBrowserSize() {
        BrowserSize[] browserSizeList = BrowserSize.values();
        for (BrowserSize browserSize : browserSizeList)
            browserSizeComboBox.addItem(browserSize.value);
    }

    private void setTag() {
        TestType[] testTypesList = TestType.values();
        for (TestType testType : testTypesList)
            testTypeComboBox.addItem(testType.value);
    }

    public static void main(String[] args) throws ClassNotFoundException, UnsupportedLookAndFeelException, InstantiationException, IllegalAccessException {
        UIManager.setLookAndFeel(getSystemLookAndFeelClassName());
        SwingUtilities.invokeLater(() -> {
            Gui testGui2 = new Gui();
            testGui2.setVisible(true);
            testGui2.setExtendedState(testGui2.getExtendedState() | JFrame.MAXIMIZED_BOTH);
        });
    }
}
