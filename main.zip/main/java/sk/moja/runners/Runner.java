package sk.moja.runners;

import com.codeborne.selenide.Configuration;
import org.junit.platform.engine.CancellationToken;

import sk.moja.enumerators.CustomDates;
import sk.moja.enumerators.Drivers;
import sk.moja.utils.Functions;

import java.util.List;
import java.util.Map;

import static sk.moja.enumerators.CustomProperties.*;
import static sk.moja.logger.GuiFormatter.printError;
import static sk.moja.utils.PrepareData.*;

public class Runner implements Runnable {
    private volatile CancellationToken cancellationToken;
    private String localRunFrom;

    public Runner(String domain, String browser, String browserSize, String driverPath, String propertyPath, List<String> listOfFeature, String runFrom, String testType, Boolean dryRun, Boolean extractScenariosName) {
        Configuration.browser = browser;
        setRunner(domain, browserSize, driverPath, propertyPath, listOfFeature, runFrom, testType, browser, dryRun, extractScenariosName);
    }

    public Runner(String domain, String browser, String browserSize, String driverPath, String propertyPath, List<String> listOfFeature, String runFrom, String testType, String browserBinary, Boolean dryRun, Boolean extractScenariosName) {
        Configuration.browser = browser;
        setRunner(domain, browserSize, driverPath, propertyPath, listOfFeature, runFrom, testType, browser, dryRun, extractScenariosName);
    }

    private void setRunner(String domain, String browserSize, String driverPath, String propertyPath, List<String> listOfFeature, String runFrom, String testType, String browserName, Boolean dryRun, Boolean extractScenariosName) {
        System.out.println("[Config] domain: " + domain);
        System.out.println("[Config] browserSize: " + browserSize);
        System.out.println("[Config] driverPath: " + driverPath);
        System.out.println("[Config] propertyPath: " + propertyPath);
        System.out.println("[Config] listOfFeature: " + listOfFeature);
        System.out.println("[Config] runFrom: " + runFrom);
        System.out.println("[Config] testType: " + testType);
        System.out.println("[Config] browserName: " + browserName);
        System.out.println("[Config] dryRun: " + dryRun);
        System.out.println("[Config] extractScenariosName: " + extractScenariosName);

        setRunFrom(runFrom);
        setDestination();
        localRunFrom = getRunFrom();
        setDryRun(dryRun);
        setExtractScenariosName(extractScenariosName);

        setTestType(testType);

        makeTempFeatureCopies(listOfFeature);
        copyPropertyFile(propertyPath);
        setProperty();
        Configuration.browserSize = browserSize;
        Configuration.baseUrl = domain;

        String webdriverDriver = Drivers.valueOf(browserName.toUpperCase().replace(" ", "_")).value;

        System.setProperty(webdriverDriver, driverPath);

        CustomDates.setTimestamp();
        String timestamp = CustomDates.getTimestamp();
        String timestampFolderName = getDestination() + "/" + timestamp;

        setReportsFolder(timestampFolderName + "/reports/");
        setTimestampFolder(timestamp);
        Configuration.reportsFolder = timestampFolderName + "/files/";
        Configuration.downloadsFolder = timestampFolderName + "/downloads/";


        setBuildPlan(System.getenv("bamboo_planKey") + "-" + System.getenv("bamboo_buildNumber"));
        System.out.println("[Config] buildPlan: " + System.getenv("bamboo_planKey") + "-" + System.getenv("bamboo_buildNumber"));
        System.out.println("[Config] domain: " + Configuration.baseUrl);
        System.out.println("[Config] browser: " + Configuration.browser);
        System.out.println("[Config] browserSize: " + Configuration.browserSize);
        System.out.println("[Config] runFrom: " + getRunFrom());
    }

    public void start() {
        Thread testThread = new Thread(this);
        testThread.start();
    }

    public void stop() {
        if (cancellationToken != null) {
            cancellationToken.cancel();
        }
        Functions.closeBrowser();
    }

    @Override
    public void run() {
        cancellationToken = CancellationToken.create();
        try {
            if (getRunFrom().equals("localGui")) {
                CucumberLaunchSupport.execute(buildCucumberConfig(), cancellationToken);
            }
        } catch (Exception e) {
            if (localRunFrom.equals("localGui")) {
                printError(e);
            }
            e.printStackTrace();
        }
    }

    private Map<String, String> buildCucumberConfig() {
        String features = getDestination() + "/temp/features";
        String glue = "sk.moja.base,sk.moja.steps";

        if (getDryRun()) {
            return CucumberLaunchSupport.buildConfigParameters(features, glue, null,
                    "pretty,sk.moja.logger.GuiFormatter", true);
        }

        if (getTestType().equals("SmokeTest")) {
            return CucumberLaunchSupport.buildConfigParameters(features, glue, "@SmokeTest",
                    "pretty,sk.moja.events.GlobalEventHandler", false);
        }

        if (getTestType().equals("RegressionTest")) {
            String reportsBase = getDestination() + "/temp/reports/cucumber-report/";
            String plugin = "pretty,sk.moja.events.GlobalEventHandler,"
                    + "message:" + reportsBase + "cucumber-messages.ndjson,"
                    + "timeline:" + reportsBase + "timeline.txt";
            return CucumberLaunchSupport.buildConfigParameters(features, glue, "@Regress", plugin, false);
        }

        return CucumberLaunchSupport.buildConfigParameters(features, glue, null,
                "pretty,sk.moja.logger.GuiFormatter", false);
    }
}
