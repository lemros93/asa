package sk.moja.runners;

import org.junit.platform.engine.CancellationToken;
import org.junit.platform.launcher.Launcher;
import org.junit.platform.launcher.LauncherDiscoveryRequest;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherExecutionRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import org.junit.platform.launcher.listeners.TestExecutionSummary;

import java.util.LinkedHashMap;
import java.util.Map;

public class CucumberLaunchSupport {

    private CucumberLaunchSupport() {
    }

    public static Map<String, String> buildConfigParameters(String features, String glue, String tags, String plugin, boolean dryRun) {
        Map<String, String> params = new LinkedHashMap<>();
        params.put("cucumber.features", features);
        params.put("cucumber.glue", glue);
        if (tags != null && !tags.isBlank()) {
            params.put("cucumber.filter.tags", tags);
        }
        params.put("cucumber.plugin", plugin);
        if (dryRun) {
            params.put("cucumber.execution.dry-run", "true");
        }
        return params;
    }

    public static TestExecutionSummary execute(Map<String, String> configParameters, CancellationToken cancellationToken) {
        LauncherDiscoveryRequest discoveryRequest = LauncherDiscoveryRequestBuilder.request()
                .configurationParameters(configParameters)
                .build();

        Launcher launcher = LauncherFactory.create();
        SummaryGeneratingListener summaryListener = new SummaryGeneratingListener();

        launcher.execute(LauncherExecutionRequestBuilder.request(discoveryRequest)
                .cancellationToken(cancellationToken)
                .listeners(summaryListener)
                .build());

        return summaryListener.getSummary();
    }
}
