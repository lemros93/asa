package sk.moja.partialResults;

import io.cucumber.plugin.event.Status;

import java.util.Optional;

public class PartialResultRowParser {

    private static final String PARAMETER_SEPARATOR = ";";

    private static final int INDEX_SCENARIO_KEY = 0;
    private static final int INDEX_STEP_NAME = 1;
    private static final int INDEX_STATUS = 2;
    private static final int INDEX_PARTIAL_RESULT_KEY = 3;
    private static final int INDEX_PARTIAL_RESULT_VALUE = 4;
    private static final int INDEX_CREATION_TIMESTAMP = 5;
    private static final int INDEX_POSSIBLE_USAGE_TIMESTAMP = 6;

    public static Optional<PartialResultRow> parseRowFromLine(String line) {

        String[] parts = line.split(PARAMETER_SEPARATOR);

        if (parts.length <= INDEX_POSSIBLE_USAGE_TIMESTAMP) {
            return Optional.empty();
        }

        return Optional.of(
            new PartialResultRow(
                parts[INDEX_SCENARIO_KEY],
                parts[INDEX_STEP_NAME],
                Status.valueOf(parts[INDEX_STATUS]),
                parts[INDEX_PARTIAL_RESULT_KEY],
                normalize(parts[INDEX_PARTIAL_RESULT_VALUE]),
                parts[INDEX_CREATION_TIMESTAMP],
                parts[INDEX_POSSIBLE_USAGE_TIMESTAMP])
        );
    }

    private static String normalize(String value) {
        return "null".equals(value) ? null : value;
    }
}