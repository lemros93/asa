package sk.moja.partialResults;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class ErrorContext {

    private static final ConcurrentHashMap<String, List<AssertionError>> SCENARIO_LEVEL_ERRORS = new ConcurrentHashMap<>();
    private static final List<Throwable> RUN_LEVEL_ERRORS = Collections.synchronizedList(new ArrayList<>());

    public static void addScenarioLevelError(String scenarioId, AssertionError error) {
        SCENARIO_LEVEL_ERRORS.computeIfAbsent(scenarioId, key -> Collections.synchronizedList(new ArrayList<>())).add(error);
    }

    public static List<AssertionError> getScenarioLevelErrors(String scenarioId) {
        List<AssertionError> errors = SCENARIO_LEVEL_ERRORS.get(scenarioId);
        return errors == null ? Collections.emptyList() : new ArrayList<>(errors);
    }

    public static void clearScenarioLevelErrors(String scenarioId) {
        SCENARIO_LEVEL_ERRORS.remove(scenarioId);
    }

    public static void addRunLevelError(Throwable throwable) {
        RUN_LEVEL_ERRORS.add(throwable);
    }

    public static void clearRunLevelErrors() {
        RUN_LEVEL_ERRORS.clear();
    }

    public static void reportRunLevelErrorsIfExist() {
        if (RUN_LEVEL_ERRORS.isEmpty()) {
            return;
        }
        System.err.println();
        System.err.println("=============================");
        System.err.println("RUN SPECIFIC ERRORS OCCURRED:");
        System.err.println("=============================");
        for (Throwable error : RUN_LEVEL_ERRORS) {
            error.printStackTrace();
        }
    }
}