package sk.moja.partialResults;

import io.cucumber.plugin.event.Status;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class PartialResultsFileContent {

    private static final DateTimeFormatter TIMESTAMP_FORMAT = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    private static final PartialResultsFileContent partialResultsFileContentInstance = new PartialResultsFileContent();

    private final List<PartialResultRow> results = new CopyOnWriteArrayList<>();

    private PartialResultsFileContent() {}

    public static PartialResultsFileContent getPartialResultsFileContent() {
        return partialResultsFileContentInstance;
    }

    public void addResult(PartialResultRow result) {
        results.add(result);
    }

    public List<PartialResultRow> getAllResults() {
        return List.copyOf(results);
    }

    public void clearResults() {
        results.clear();
    }

    public static boolean dataForScenarioKeyAndParameterNameExists(String scenarioKey, String parameterName) {
        return PartialResultsFileContent.getPartialResultsFileContent()
            .getAllResults()
            .stream()
            .anyMatch(partialResultRow ->
                Objects.equals(partialResultRow.getScenarioKey(), scenarioKey) &&
                Objects.equals(partialResultRow.getPartialResultKey(), parameterName) &&
                partialResultRow.getStepStatus() == Status.PASSED &&
                partialResultRow.getPartialResultValue() != null
        );
    }

    public static boolean dataForScenarioKeyAndParameterNameHasProperTimeStamp(String scenarioKey, String parameterName) {
        LocalDateTime now = LocalDateTime.now();

        return PartialResultsFileContent.getPartialResultsFileContent()
            .getAllResults()
            .stream()
            .anyMatch(partialResultRow ->
                Objects.equals(partialResultRow.getScenarioKey(), scenarioKey) &&
                Objects.equals(partialResultRow.getPartialResultKey(), parameterName) &&
                partialResultRow.getStepStatus() == Status.PASSED &&
                partialResultRow.getPartialResultValue() != null &&
                partialResultRow.getPossibleUsageTimeStamp() != null &&
                LocalDateTime.parse(
                    partialResultRow.getPossibleUsageTimeStamp(),
                    TIMESTAMP_FORMAT
                ).isAfter(now)
            );
    }

    public static Optional<LocalDateTime> getPossibleUsageTime(String scenarioKey, String parameterName) {
        return PartialResultsFileContent.getPartialResultsFileContent()
            .getAllResults()
            .stream()
            .filter(partialResultRow ->
                Objects.equals(partialResultRow.getScenarioKey(), scenarioKey) &&
                Objects.equals(partialResultRow.getPartialResultKey(), parameterName) &&
                partialResultRow.getStepStatus() == Status.PASSED &&
                partialResultRow.getPartialResultValue() != null)
            .map(PartialResultRow::getPossibleUsageTimeStamp)
            .map(timestamp ->
                LocalDateTime.parse(timestamp, TIMESTAMP_FORMAT))
            .findFirst();
    }

    public static Optional<String> getPartialResultValue(String scenarioKey, String parameterName) {
        return PartialResultsFileContent.getPartialResultsFileContent()
            .getAllResults()
            .stream()
            .filter(partialResultRow ->
                Objects.equals(partialResultRow.getScenarioKey(), scenarioKey)
                    && Objects.equals(partialResultRow.getPartialResultKey(), parameterName)
                    && partialResultRow.getStepStatus() == Status.PASSED
                    && partialResultRow.getPartialResultValue() != null)
            .map(PartialResultRow::getPartialResultValue)
            .findFirst();
    }

    public static Optional<String> getPartialResultValue(List<String> scenarioKeys, String parameterName) {
        return PartialResultsFileContent.getPartialResultsFileContent()
            .getAllResults()
            .stream()
            .filter(partialResultRow ->
                scenarioKeys.contains(partialResultRow.getScenarioKey())
                    && Objects.equals(
                    partialResultRow.getPartialResultKey(),
                    parameterName)
                    && partialResultRow.getStepStatus() == Status.PASSED
                    && partialResultRow.getPartialResultValue() != null)
            .map(PartialResultRow::getPartialResultValue)
            .findFirst();
    }

    public void writePartialResultsFileContentIntoLog() {
        System.out.println("-----------------------");
        System.out.println("LOADED PARTIAL RESULTS:");
        System.out.println("-----------------------");

        for (PartialResultRow row : results) {
            row.writePartialResultRowIntoLog();
        }
    }
}