package sk.moja.partialResults;

import io.cucumber.plugin.event.Status;
import lombok.Getter;

public class PartialResultRow {
    @Getter
    String scenarioKey;
    @Getter
    String stepName;
    @Getter
    Status stepStatus;
    @Getter
    String partialResultKey;
    @Getter
    String partialResultValue;
    @Getter
    String creationTimeStamp;
    @Getter
    String possibleUsageTimeStamp;

    public PartialResultRow(String scenarioKey, String stepName, Status stepStatus, String partialResultKey, String partialResultValue, String creationTimeStamp, String possibleUsageTimeStamp) {
        this.scenarioKey = scenarioKey;
        this.stepName = stepName;
        this.stepStatus = stepStatus;
        this.partialResultKey = partialResultKey;
        this.partialResultValue = partialResultValue;
        this.creationTimeStamp = creationTimeStamp;
        this.possibleUsageTimeStamp = possibleUsageTimeStamp;
    }

    public void writePartialResultRowIntoLog(){
        System.out.println("----------------");
        System.out.println("Partial result:");
        System.out.println("Scenario key: " + scenarioKey);
        System.out.println("Step name: " + stepName);
        System.out.println("Step status: " + stepStatus);
        System.out.println("Partial result key: " + partialResultKey);
        System.out.println("Partial result value: " + partialResultValue);
        System.out.println("Creation timestamp: " + creationTimeStamp);
        System.out.println("Possible usage timestamp: " + possibleUsageTimeStamp);
        System.out.println("----------------");
    }
}