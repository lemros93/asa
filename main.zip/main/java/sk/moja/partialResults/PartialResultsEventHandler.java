package sk.moja.partialResults;

import io.cucumber.plugin.event.*;
import sk.moja.enumerators.UniqueValues;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static sk.moja.enumerators.CustomProperties.*;
import static sk.moja.logger.Scenario.getTestCaseKeysFromTestCaseScenarioLine;
import static sk.moja.partialResults.PartialResultRowParser.parseRowFromLine;
import static sk.moja.partialResults.PartialResultsFileContent.*;

public  class PartialResultsEventHandler {

    // Step related constants:
    private static final String STORE_RESULT_STEP_REGEX = ".*store result.*";
    private static final String READ_FROM_STORED_FILE_STEP_REGEX = ".*from stored file.*";
    private static final String STEP_PARAMETER_REGEX = "\"([^\"]+)\"";
    private static final int FIRST_PARAMETER_INDEX_IN_THE_STEP = 1;

    // Test run related constants and variables:
    private static final String PARTIAL_RESULTS_FILE_NAME = "partialResults.txt";
    private static final String PARTIAL_RESULTS_FOLDER_PATH = getDestination() + "/partialResults/";
    private static final String PARTIAL_RESULTS_FILE_PATH = PARTIAL_RESULTS_FOLDER_PATH + PARTIAL_RESULTS_FILE_NAME;
    private static final DateTimeFormatter TIMESTAMP_FORMAT_yyyyMMddHHmmss = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
    private static final String TAG_FOR_POSSIBLE_USAGE_IN_TWO_HOURS = "@inTwoHours";
    private static final String TAG_FOR_POSSIBLE_USAGE_IN_ONE_DAY = "@inOneDay";
    private static final int RECORD_RETENTION_DAYS = 7;
    private final List<PartialResultRow> scenarioPartialResultsToBeReported = new ArrayList<>();
    UniqueValues uniqueValues = new UniqueValues();

    public void collectCurrentFileContent(TestRunStarted event) {

        PartialResultsFileContent partialResultsFileContent = PartialResultsFileContent.getPartialResultsFileContent();
        partialResultsFileContent.clearResults();

        if (!PARTIAL_RESULTS_FILE_PATH.isBlank()) {
            File partialResultsFile = new File(PARTIAL_RESULTS_FILE_PATH);
            loadExistingRecords(partialResultsFile).forEach(partialResultsFileContent::addResult);
        }

        ErrorContext.reportRunLevelErrorsIfExist();
        ErrorContext.clearRunLevelErrors();

        partialResultsFileContent.writePartialResultsFileContentIntoLog();
    }

    public void checkScenarioPreconditions(TestCaseStarted event) {

        String currentScenarioId = event.getTestCase().getId().toString();
        String currentScenario = event.getTestCase().getName();
        List<String> currentScenarioKeys = getTestCaseKeysFromTestCaseScenarioLine(currentScenario);
        List<String> currentScenarioTags = event.getTestCase().getTags();
        List<String> currentScenarioSteps = new ArrayList<>();
        boolean containsStoreResultStep = false;
        boolean containsReadFromFileStep = false;

        for (TestStep testStep : event.getTestCase().getTestSteps()) {
            if (testStep instanceof PickleStepTestStep pickleStep) {
                String currentTestStep = pickleStep.getStep().getText();
                currentScenarioSteps.add(currentTestStep);

                if (isStoreResultStep(currentTestStep)) {
                    containsStoreResultStep = true;
                }

                if(isReadFromStoredFileStep(currentTestStep)) {
                    containsReadFromFileStep = true;
                }
            }
        }

        if (containsStoreResultStep) {
            boolean hasInOneDayTag = currentScenarioTags.contains(TAG_FOR_POSSIBLE_USAGE_IN_ONE_DAY);
            boolean hasInTwoHoursTag = currentScenarioTags.contains(TAG_FOR_POSSIBLE_USAGE_IN_TWO_HOURS);

            if (hasInOneDayTag == hasInTwoHoursTag) {
                fail(currentScenarioId,
                    "Your scenario doesn't contain information when can be file stored values used.\n" +
                    "Please define one (not two or none) of the following tags: "
                    + TAG_FOR_POSSIBLE_USAGE_IN_TWO_HOURS  + " or " + TAG_FOR_POSSIBLE_USAGE_IN_ONE_DAY
                    + " for your current scenario: " + currentScenario
                    + "\nCurrently defined tags are: " + currentScenarioTags);
            }
        }

        if(containsReadFromFileStep) {
            for (String step : currentScenarioSteps) {
                if(isReadFromStoredFileStep(step)) {
                    String parameterName = getFirstParameterOfTheStep(step);

                    boolean validationFailed = false;
                    Map<String, String> valuesByScenarioKey = new HashMap<>();

                    for(String scenarioKey : currentScenarioKeys) {
                        boolean dataExists = dataForScenarioKeyAndParameterNameExists(scenarioKey, parameterName);
                        boolean possibleUsageTimeStampIsHigherThanNow = dataForScenarioKeyAndParameterNameHasProperTimeStamp(scenarioKey, parameterName);

                        if (!dataExists) {
                            validationFailed = true;
                            fail(currentScenarioId, "Missing data for scenarioKey = " + scenarioKey + ", parameter name = " + parameterName);
                        } else if(possibleUsageTimeStampIsHigherThanNow) {
                            validationFailed = true;
                            fail(currentScenarioId,
                                "Possible usage time not reached yet for scenarioKey = " + scenarioKey + ", parameter name = " + parameterName +
                                ", you can use this data at following time: " + getPossibleUsageTime(scenarioKey, parameterName));
                        } else {
                            String value = getPartialResultValue(scenarioKey, parameterName).orElse(null);
                            valuesByScenarioKey.put(scenarioKey, value);
                        }
                    }

                    if (!validationFailed && valuesByScenarioKey.size() > 1) {

                        Set<String> uniquePartialResultsValues = new HashSet<>(valuesByScenarioKey.values());

                        if (uniquePartialResultsValues.size() > 1) {
                            fail(currentScenarioId,
                                "Stored values are not consistent for parameter '" + parameterName
                                + "'. Values found: " + valuesByScenarioKey);
                        }
                    }
                }
            }
        }
    }

    public void getValueFromStoredFile(TestStepStarted event) {
        if(event.getTestStep() instanceof PickleStepTestStep testStep) {

            String currentTestStep = testStep.getStep().getText();

            if (isReadFromStoredFileStep(currentTestStep)) {
                List<String> currentScenarioKeys = getTestCaseKeysFromTestCaseScenarioLine(event.getTestCase().getName());
                String keyToBeFound = getFirstParameterOfTheStep(currentTestStep);
                String foundResult = getPartialResultValue(currentScenarioKeys, keyToBeFound).orElse("");

                uniqueValues.setProvidedValue(keyToBeFound, foundResult);
            }
        }
    }

    public void collectTestStepInfo (TestStepFinished event) {
        if(event.getTestStep() instanceof PickleStepTestStep testStep) {

            String currentTestStep = testStep.getStep().getText();

            if (isStoreResultStep(currentTestStep)) {
                List<String> currentScenarioKeys = getTestCaseKeysFromTestCaseScenarioLine(event.getTestCase().getName());
                List<String> currentScenarioTags = event.getTestCase().getTags();
                Status currentTestStepStatus = event.getResult().getStatus();
                String firstParameterOfTheStep = getFirstParameterOfTheStep(currentTestStep);

                String creationTimeStamp = LocalDateTime.now().format(TIMESTAMP_FORMAT_yyyyMMddHHmmss);
                String possibleUsageTimeStamp = getPossibleUsageTimestampForProvidedScenarioTags(currentScenarioTags);

                for (String scenarioKey : currentScenarioKeys) {
                    scenarioPartialResultsToBeReported.add(
                        new PartialResultRow(
                            scenarioKey,
                            currentTestStep,
                            currentTestStepStatus,
                            firstParameterOfTheStep,
                            uniqueValues.getUniqueIdentifierValue(firstParameterOfTheStep),
                            creationTimeStamp,
                            possibleUsageTimeStamp
                        )
                    );
                }
            }
        }
    }

    public void publishPartialResults(TestRunFinished event) {

        File partialResultsDir = new File(PARTIAL_RESULTS_FOLDER_PATH);

        if (!partialResultsDir.exists()) {
            partialResultsDir.mkdirs();
        }

        File partialResultsFile = new File(partialResultsDir, PARTIAL_RESULTS_FILE_NAME);

        if (!partialResultsFile.exists()) {
            try {
                partialResultsFile.createNewFile();
                System.out.println("File created: " + partialResultsFile.getAbsolutePath());
            } catch (IOException e) {
                fail(e);
            }
        }

        List<PartialResultRow> existingRecords = loadExistingRecords(partialResultsFile);
        List<PartialResultRow> mergedRecords = mergeRecords(existingRecords, scenarioPartialResultsToBeReported);
        saveRecordsToFile(partialResultsFile, mergedRecords);

        System.out.println("---------------------------------");
        System.out.println("PARTIAL RESULTS REPORTED TO FILE:");
        System.out.println("---------------------------------");
        for (PartialResultRow partialResultToBeReported : scenarioPartialResultsToBeReported) {
            partialResultToBeReported.writePartialResultRowIntoLog();
        }

        ErrorContext.reportRunLevelErrorsIfExist();
        ErrorContext.clearRunLevelErrors();
    }

    private boolean recordIsObsolete(PartialResultRow row) {

        if (row.getPossibleUsageTimeStamp() == null || row.getPossibleUsageTimeStamp().isBlank()) {
            return true;
        }

        LocalDateTime expirationDate = LocalDateTime.parse(row.getPossibleUsageTimeStamp(), TIMESTAMP_FORMAT_yyyyMMddHHmmss).plusDays(RECORD_RETENTION_DAYS);
        return expirationDate.isBefore(LocalDateTime.now());
    }

    private List<PartialResultRow> loadExistingRecords(File partialResultsFile) {

        List<PartialResultRow> result = new ArrayList<>();

        if (!partialResultsFile.exists()) {
            return result;
        }

        try {
            List<String> lines = Files.readAllLines(partialResultsFile.toPath());

            for (String line : lines) {
                parseRowFromLine(line).ifPresent(result::add);
            }
        } catch (IOException e) {
            fail(e);
        }

        return result;
    }

    private List<PartialResultRow> mergeRecords(List<PartialResultRow> existingRecords, List<PartialResultRow> newRecords) {

        Map<String, PartialResultRow> recordsByUniqueKey = new LinkedHashMap<>();

        for (PartialResultRow existingRecord : existingRecords) {
            if (recordIsObsolete(existingRecord)) {
                continue;
            }

            recordsByUniqueKey.put(buildUniqueKey(existingRecord), existingRecord);
        }

        for (PartialResultRow newRecord : newRecords) {
            recordsByUniqueKey.put(buildUniqueKey(newRecord), newRecord);
        }

        return new ArrayList<>(recordsByUniqueKey.values());
    }

    private String buildUniqueKey(PartialResultRow row) {
        return row.getScenarioKey() + "|" + row.getPartialResultKey();
    }

    private String returnRecordAsStringFileLine(PartialResultRow row) {
        return row.getScenarioKey() + ";" +
            row.getStepName() + ";" +
            row.getStepStatus() + ";" +
            row.getPartialResultKey() + ";" +
            row.getPartialResultValue() + ";" +
            row.getCreationTimeStamp() + ";" +
            row.getPossibleUsageTimeStamp();
    }

    private void saveRecordsToFile(File partialResultsFile, List<PartialResultRow> records) {

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(partialResultsFile, false))) {
            for (PartialResultRow row : records) {
                writer.write(returnRecordAsStringFileLine(row));
                writer.newLine();
            }
        } catch (IOException e) {
            fail(e);
        }
    }

    private String getFirstParameterOfTheStep(String step) {
        Pattern pattern = Pattern.compile(STEP_PARAMETER_REGEX);
        Matcher matcher = pattern.matcher(step);

        if (matcher.find()) {
            return matcher.group(FIRST_PARAMETER_INDEX_IN_THE_STEP);
        }

        return "";
    }

    private String getPossibleUsageTimestampForProvidedScenarioTags(List<String> scenarioTags) {
        if (scenarioTags.contains(TAG_FOR_POSSIBLE_USAGE_IN_TWO_HOURS))  {
            return LocalDateTime.now().plusHours(2).format(TIMESTAMP_FORMAT_yyyyMMddHHmmss);
        } else if (scenarioTags.contains(TAG_FOR_POSSIBLE_USAGE_IN_ONE_DAY)) {
            return LocalDateTime.now().plusDays(1).format(TIMESTAMP_FORMAT_yyyyMMddHHmmss);
        } else {
            return "";
        }
    }

    private void fail(String scenarioId, String message) {
        ErrorContext.addScenarioLevelError(scenarioId, new AssertionError(message));
    }

    private void fail(Throwable throwable) {
        ErrorContext.addRunLevelError(new AssertionError(throwable.getMessage(), throwable));
    }

    private boolean isStoreResultStep(String step) {
        return step.toLowerCase().matches(STORE_RESULT_STEP_REGEX);
    }

    private boolean isReadFromStoredFileStep(String step) {
        return step.toLowerCase().matches(READ_FROM_STORED_FILE_STEP_REGEX);
    }
}