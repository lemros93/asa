package sk.moja.base;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import org.openqa.selenium.WebDriver;
import sk.moja.enumerators.*;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static java.lang.Boolean.parseBoolean;
import static sk.moja.enumerators.CustomProperties.*;
import static sk.moja.utils.PrepareData.*;
import static sk.moja.utils.StepContext.*;

import com.codeborne.selenide.WebDriverRunner;
import io.cucumber.java.Scenario;
import sk.moja.logger.JiraReporter;
import sk.moja.utils.Screenshot;
import sk.moja.utils.StepContext;

import com.assertthat.selenium_shutterbug.core.Capture;

public class TestBase {
    static {
        Configuration.timeout = 40000;
        Configuration.pageLoadTimeout = 40000;
        Configuration.savePageSource = false;
        Configuration.screenshots = false;
        System.out.println("TestBase: ");
    }

    private static final ThreadLocal<Integer> counter = ThreadLocal.withInitial(() -> 1);

    @Before
    public void resetCounter() {
        counter.set(1);
    }


    @Before
    public void before() {
        if(WebDriverRunner.hasWebDriverStarted()){
            String folder = WebDriverRunner.driver().browserDownloadsFolder().getPath();
            StepContext.setDownloadFolder(folder);
        }
    }

    @AfterStep
    public void takeScreenshotAfterEachStep(Scenario scenario) {
        if (WebDriverRunner.hasWebDriverStarted()) {
            String uriString = scenario.getUri().toString();
            String featureName = uriString.substring(uriString.lastIndexOf("/") + 1).replace(".feature", "");
            String scenarioName = String.format("%04d_%s", scenario.getLine(), unifyString(scenario.getName()));
            String stepCleanName = unifyString(getCurrentStepName());
            String stepStatus = getCurrentStepStatus();
            int stepNum = counter.get();
            String screenshotName = String.format("%02d_%s", stepNum, stepCleanName);
            String relativeAllFolder = "all/" + featureName + "/" + scenarioName + "/";
            String relativeFailedFolder = "failed/" + featureName + "/" + scenarioName + "/";
            String allTestLocation = Configuration.reportsFolder + relativeAllFolder;
            String failedTestLocation = Configuration.reportsFolder + relativeFailedFolder;
            if (!stepStatus.equalsIgnoreCase(Constants.SKIPPED) && !getScreenshotType().equals("DISABLED") && !stepCleanName.contains("close_browser") || stepStatus.equals("FAILED") && !stepCleanName.contains("close_browser")) {
                WebDriver driver = WebDriverRunner.getWebDriver();
                if (!driver.toString().contains("(null)")) {
                    if (getScreenshotType().equals("FULLSCREEN")) {
                        File allTestDir = new File(allTestLocation);
                        if (!allTestDir.exists()) {
                            allTestDir.mkdirs();
                        }
                        new Screenshot(driver, allTestLocation, screenshotName).createScreenshot(Capture.FULL);
                        StepContext.setScreenshotPath(allTestLocation+screenshotName);
                    } else if (getScreenshotType().equals("ELEMENT")) {
                        Selenide.screenshot(allTestLocation + screenshotName);
                        StepContext.setScreenshotPath(allTestLocation+screenshotName);
                    }
                    if (stepStatus.equals("FAILED")) {
                        File failedTestDir = new File(failedTestLocation);
                        if (!failedTestDir.exists()) {
                            failedTestDir.mkdirs();
                        }
                        new Screenshot(driver, failedTestLocation, screenshotName).createScreenshot(Capture.FULL);
                        StepContext.setFailedScreenshotPath(failedTestLocation+screenshotName);
                        JiraReporter.failedStepsScreenshotPaths.add(failedTestLocation+screenshotName);
                    }
                }

            }

            counter.set(stepNum + 1);
        }
    }

    private String unifyString(String string) {
        return string.replaceAll("[^a-zA-Z0-9]", "_").replaceAll("_+", "_").replaceAll("^_+|_+$", "");
    }

    public static void setUp() {
        String runFrom = System.getProperty("runFrom");
        System.out.println("runFrom: " + runFrom);
        if (runFrom != null && !runFrom.equals("localGui")) {
            System.out.println("ifsetuptestbase");
            List<String> listOfFeature = new ArrayList<>();
            String domain = System.getProperty("baseUrl");
            String browserName = Browser.valueOf(System.getProperty("browser").toUpperCase()).value;
            String browserSize = System.getProperty("browserSize").toLowerCase();
            String driverPath = System.getProperty("webDriverLocation");
            String propertyPath = System.getProperty("propertyFileLocation");
            String testType = System.getProperty("testType");
            String browserBinary = System.getProperty("browserBinary");
            Configuration.headless = parseBoolean(System.getProperty("headless"));
            Collections.addAll(listOfFeature, System.getProperty("feature"));
            setScreenshotType(Screenshots.valueOf(System.getProperty("screenCapture").toUpperCase()).value);
            System.out.println("[Config] domain: " + domain);
            System.out.println("[Config] browserSize: " + browserSize);
            System.out.println("[Config] driverPath: " + driverPath);
            System.out.println("[Config] propertyPath: " + propertyPath);
            System.out.println("[Config] listOfFeature: " + listOfFeature);
            System.out.println("[Config] runFrom: " + runFrom);
            System.out.println("[Config] testType: " + testType);
            System.out.println("[Config] browserName: " + browserName);

            setRunFrom(runFrom);

            Configuration.browser = browserName;
            if (getRunFrom().equals("server")) {
                Configuration.browserBinary = browserBinary;
                System.out.println("[Config] browserBinary: " + Configuration.browserBinary);

            }

            setDestination();
            setTestType(testType);

            setProperty();
            Configuration.browserSize = browserSize;
            Configuration.baseUrl = domain;
            String webdriverDriver = Drivers.valueOf(browserName.toUpperCase().replace(" ", "_")).value;

            File webDr = new File(driverPath);
            System.setProperty(webdriverDriver, webDr.getAbsolutePath());

            CustomDates.setTimestamp();
            String timestamp = CustomDates.getTimestamp();
            if(getRunFrom().equals("server")) {
                timestamp = System.getProperty("timestamp");
            }
            String timestampFolderName = getDestination() + "/" + timestamp;

            setReportsFolder(timestampFolderName + "/reports/");
            setTimestampFolder(timestamp);
            Configuration.reportsFolder = timestampFolderName + "/files/";

            setBuildPlan(System.getenv("bamboo_planKey") + "-" + System.getenv("bamboo_buildNumber"));
            System.out.println("[Config] buildPlan: " + System.getenv("bamboo_planKey") + "-" + System.getenv("bamboo_buildNumber"));
            System.out.println("[Config] domain: " + Configuration.baseUrl);
            System.out.println("[Config] browser: " + Configuration.browser);
            System.out.println("[Config] browser webdriver: " + System.getProperty(webdriverDriver));
            System.out.println("[Config] browserSize: " + Configuration.browserSize);
            System.out.println("[Config] runFrom: " + getRunFrom());
            System.out.println("[Config] webdriverLogsEnabled: " + Configuration.webdriverLogsEnabled);

            if (getRunFrom().equals("server")) {
                setProxy();
                //Configuration.browserCapabilities = new EdgeOptions().addArguments("--no-sandbox");
            }
            Configuration.webdriverLogsEnabled = true;

        }

    }

}
