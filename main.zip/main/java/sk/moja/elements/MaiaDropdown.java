package sk.moja.elements;

import org.openqa.selenium.By;

import static com.codeborne.selenide.Selectors.byCssSelector;

public class MaiaDropdown extends Dropdown {

    private static final By ulIdentifier = byCssSelector("maia-select-options");
    private static final By liIdentifier = byCssSelector("maia-option");

    public MaiaDropdown(By dropdownIdentifier) {
        super(dropdownIdentifier, ulIdentifier, liIdentifier);
    }
}