package sk.moja.elements;

import lombok.Getter;
import org.openqa.selenium.By;

public class Element {

    @Getter
    private final By elementIdentifier;

    public Element(By elementIdentifier) {
        this.elementIdentifier = elementIdentifier;
    }
}