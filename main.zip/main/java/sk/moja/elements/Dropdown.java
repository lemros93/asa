package sk.moja.elements;

import lombok.Getter;
import org.openqa.selenium.By;

public class Dropdown extends Element{

    @Getter
    private final By ulIdentifier;
    @Getter
    private final By liIdentifier;

    public Dropdown(By dropdownIdentifier, By ulIdentifier, By liIdentifier) {
        super(dropdownIdentifier);
        this.ulIdentifier = ulIdentifier;
        this.liIdentifier = liIdentifier;
    }
}