package sk.moja.elements;

import org.openqa.selenium.By;

public class MultipleSelectionMaiaDropdown extends MaiaDropdown {

    public MultipleSelectionMaiaDropdown(By dropdownIdentifier) {
        super(dropdownIdentifier);
    }
}