package sk.moja.elements;

import com.codeborne.selenide.selector.ByAttribute;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selectors.byCssSelector;

public class CsobDropdown extends Dropdown {

    private static final By ulIdentifier = byCssSelector("ul.item-list");
    private static final By liIdentifier = byCssSelector("li");

    public CsobDropdown(By dropdownIdentifier) {
        super(
                getClickablePartOfCsobDropdown(getCsobDropdownXpath(dropdownIdentifier)),
                ulIdentifier,
                liIdentifier);
    }

    private static String getCsobDropdownXpath(By dropdownIdentifier) {
        String byString = dropdownIdentifier.toString();

        if (dropdownIdentifier instanceof By.ByXPath) {
            return byString.replace("By.xpath: ", "").trim();
        } else if (dropdownIdentifier instanceof By.ById) {
            String id = byString.replace("By.id: ", "").trim();
            return "//*[@id='" + id + "']";
        } else if (dropdownIdentifier instanceof ByAttribute) {
            String attribute = byString
                    .replace("By.attribute: [", "")
                    .replace("By.cssSelector: [", "")
                    .replace("]", "");
            String attributeParts[] = attribute.split("=", 2 );
            if (attributeParts.length == 2) {
                String attributeName = attributeParts[0].replace("\"", "");
                String attributeValue = attributeParts[1].replace("\"", "");
                return "//*[@" + attributeName + "='" + attributeValue + "']";
            } else {
                throw new IllegalArgumentException("Invalid ByAttribute string: " + byString);
            }
        } else {
            throw new UnsupportedOperationException("Unsupported By type: " + byString.getClass());
        }
    }

    private static By getClickablePartOfCsobDropdown(String dropdownXpath) {
        if (dropdownXpath.contains("formcontrolname")) {
            return By.xpath(dropdownXpath);
        }
        return By.xpath(dropdownXpath + "/../..");
    }
}