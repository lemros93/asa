package sk.moja.elements;

import org.openqa.selenium.By;

import static com.codeborne.selenide.Selectors.*;

public class MaiaSlider extends Slider {

    private static final By sliderTypeIdentifier = byXpath("//maia-slider");
    private static final By sliderMinimum = byClassName("maia-slider__tag--min");
    private static final By sliderMaximum = byClassName("maia-slider__tag--max");
    private static final By sliderBar = byClassName("maia-slider__bar");
    private static final By sliderThumb = byClassName("maia-thumb");

    public MaiaSlider(By sliderTextFieldIdentifier) {
        super(sliderTypeIdentifier, sliderMinimum, sliderMaximum, sliderBar, sliderThumb, sliderTextFieldIdentifier);
    }
}