package sk.moja.elements;

import lombok.Getter;
import org.openqa.selenium.By;

public class ListOfElementItems extends Element{

    @Getter
    private final By elementItemRow;

    public ListOfElementItems(By wholeElementIdentifier, By elementItemRow) {
        super(wholeElementIdentifier);
        this.elementItemRow = elementItemRow;
    }
}