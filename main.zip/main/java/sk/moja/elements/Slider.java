package sk.moja.elements;

import lombok.Getter;
import org.openqa.selenium.By;

public class Slider extends Element {

    @Getter
    private final By sliderMinimum;
    @Getter
    private final By sliderMaximum;
    @Getter
    private final By sliderBar;
    @Getter
    private final By sliderThumb;
    @Getter
    private final By sliderText;

    public Slider(By sliderTypeIdentifier, By sliderMinimum, By sliderMaximum, By sliderBar, By sliderThumb, By sliderTextFieldIdentifier) {
        super(sliderTypeIdentifier);
        this.sliderMinimum = sliderMinimum;
        this.sliderMaximum = sliderMaximum;
        this.sliderBar = sliderBar;
        this.sliderThumb = sliderThumb;
        this.sliderText = sliderTextFieldIdentifier;
    }
}